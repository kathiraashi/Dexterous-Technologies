<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>


  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Contact</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Contact</li>
				</ol>
			</div>

		</section><!-- #page-title end -->


	<?php if (isset($msg)){ ?>
	    <div class="style-msg successmsg">
			<div class="sb-msg"><i class="fa fa-check"></i> <?php echo $msg; ?> </div>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			</div>
       <?php } ?>



			<!-- Google Map
		============================================= -->
		<section id="" class="gmap slider-parallax"><iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15663.663973178687!2d76.9813718!3d11.0449251!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xed2789117e8f117!2sNihas+Technologies!5e0!3m2!1sen!2sin!4v1507090093746" width="100%" height="450" frameborder="0" style="border:0" allowfullscreen></iframe></section>

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<!-- Postcontent
					============================================= -->
					<div class="postcontent nobottommargin">

						<h3>Send us an Email</h3>

						<div>

							<form class="nobottommargin" action="<?=base_url()?>index.php/Index/contact_submit" onsubmit="return validateMyForm_1();" method="post">

								<div class="form-process"></div>

								<div class="col_one_third">
									<label>Name <small>*</small></label>
									<input type="text" name="name" value="" class="sm-form-control required"  />
								</div>

								<div class="col_one_third">
									<label>Email <small>*</small></label>
									<input type="email" name="email" value="" class="required email sm-form-control"  />
								</div>

								<div class="col_one_third col_last">
									<label>Phone</label>
									<input type="text" name="phone" value="" class="sm-form-control required"  />
								</div>

								<div class="clear"></div>

								<div class="col_full">
									<label>Subject <small>*</small></label>
									<input type="text" name="subject" value="" class="required sm-form-control"  />
								</div>


								<div class="clear"></div>

								<div class="col_full">
									<label>Message <small>*</small></label>
									<textarea class="required sm-form-control"  name="message" rows="6" cols="30" ></textarea>
								</div>

								<div class="col_full">
									<button class="button button-3d nomargin" type="submit" value="submit">Send Message</button>
								</div>

							</form>
						</div>

					</div><!-- .postcontent end -->

					<!-- Sidebar
					============================================= -->
					<div class="sidebar col_last nobottommargin">

						<address>
							No.15, 2nd St, Sri Lakshmi Nagar,<br>
							 Ganapathypudur,<br>
							  Coimbatore,<br>
							   Tamil Nadu 641006.
						</address>
						<abbr title="Phone Number"><strong>Phone:</strong></abbr> (+91) 98949 99741<br>
						<abbr title="Email Address"><strong>Email:</strong></abbr> info@nihastechnologies.com


						<div class="widget noborder notoppadding">

							<a href="#" class="social-icon si-small si-dark si-facebook">
								<i class="fa fa-facebook"></i>
								<i class="fa fa-facebook"></i>
							</a>

							<a href="#" class="social-icon si-small si-dark si-twitter">
							   <i class="fa fa-twitter"></i>
								<i class="fa fa-twitter"></i>
							</a>

							<a href="#" class="social-icon si-small si-dark si-yahoo">
								<i class="fa fa-instagram"></i>
								<i class="fa fa-instagram"></i>
							</a>


							<a href="#" class="social-icon si-small si-dark si-gplus">
								<i class="fa fa-google-plus"></i>
								<i class="fa fa-google-plus"></i>
							</a>

						</div>

					</div><!-- .sidebar end -->

				</div>

			</div>

		</section><!-- #content end -->

   <?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>



<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"839484a19a","applicationID":"5289971","transactionName":"ZQEDZxZUD0FZVkxfX1xLNEENGglGVVkXVVFcEgBAS1YOXExUW0IdWwoNWgpQT0JQRQ==","queueTime":0,"applicationTime":8,"atts":"SUYAEV5OHE8=","errorBeacon":"bam.nr-data.net","agent":""}</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".contact").addClass("current");

       $(".style-msg button.close").click(function(){
     	 window.location.href='<?=base_url()?>index.php/Index/contact';
       });


	 });
</script>

<script>
   function validateMyForm_1(){

       if($('input[name=name]').val() == ""){
              $('input[name=name]').addClass('red')
              return false;
        }else if($('input[name=email]').val() == ""){
              $('input[name=email]').addClass('red')
              return false;
        }else if($('input[name=phone]').val() == ""){
              $('input[name=phone]').addClass('red')
              return false;
        }else if($('input[name=subject]').val() == ""){
              $('input[name=subject]').addClass('red')
              return false;
        }else{

              return true;
      }
 }

 $('input').keyup(function(){
 	$(this).removeClass('red');
 })
</script>


</body>

</html>