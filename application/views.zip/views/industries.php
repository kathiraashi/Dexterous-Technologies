<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

 </head>

 <style type="text/css">
 	.pro_ul{
 		list-style-type: none;
 		margin: 0px;
 	}
 	.pro_li{
 		width: 100%;
 		padding: 5px 15px;
 	}
 	.pro_li a{
 		font-size: 16px; 
 		color: inherit;
 		width: 85%;
 	}

   .accordion.accordion-border .acc_content{
   	margin:0px;
   	padding:0px;
   }
   .red{
 		border:2px solid red !important;
 	}
 	td, th{
 	padding: 0;
    border: 1px solid gray;
    text-align: center;
 	}
 	.go_pro{
 		padding: 0px 4px;
 	}
 	.go_pro a{
 		font-size: 16px;
 		border-radius:19px;
 	}

 </style>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>
        

         		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Industries</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Industries</li>
				</ol>
			</div>

		</section><!-- #page-title end -->



		<!-- Content
		============================================= -->
		<section id="content">


	      <?php foreach ($industries as $industry ) {?>

		      <div class="container-fluid">
		      	<div class="row">
		      		<div class="col-sm-12" style="background-image: url(<?=base_url()?>assets/admin/images/<?=$industry->image?>);background-size: 100% 100%; height: 350px;">
		      			<center><h1 style="line-height: 300px;color: #ffffff"><?=$industry->name?></h1></center>
		      			
		      		</div>
		      	</div>
		      	<div class="row">
		      		<div class="col-sm-12" style="padding: 0% 5%;">
		      			<p> <?=$industry->description?></p>
		      		</div>
		      	</div>
		      </div>

           <?php } ?>

           <div class="container">
           	<h3>Products</h3>
           	<div class="row" style="margin-bottom: 30px;">
           		<div class="col-sm-12">
           			<?php foreach ($industry_products as $ind_product) { ?>
           			<span class="go_pro"><a href="<?=base_url()?>index.php/Index/go_product/<?=$ind_product->product_id?>" class="btn btn-primary btn-sm"> <?=$ind_product->product_name?></a></span>
           			<?php } ?>
           		</div>
           	</div>
           </div>

		</section><!-- #content end -->
<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".industries").addClass("current");
	 });
</script>


</body>

</html>