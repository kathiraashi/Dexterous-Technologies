		<!-- Footer
		============================================= -->
		<footer id="footer" class="dark">

			<!-- Copyrights
			============================================= -->
			<div id="copyrights">

				<div class="container clearfix">

					<div class="col_half">
						Copyrights &copy; 2017 All Rights Reserved by AASHI Technologies.<br>
						<div class="copyright-links"><a href="#">Terms of Use</a> / <a href="#">Privacy Policy</a></div>
					</div>

					<div class="col_half col_last tright">
						<div class="fright clearfix">
							<a href="https://www.facebook.com/nihastechnologiescbe" target="blanck" class="social-icon si-small si-borderless si-facebook">
								<i class="fa fa-facebook"></i>
								<i class="fa fa-facebook"></i>
							</a>

							<a href="https://twitter.com/Nihas_Tech" target="blanck" class="social-icon si-small si-borderless si-twitter">
								<i class="fa fa-twitter"></i>
								<i class="fa fa-twitter"></i>
							</a>

							<a href="https://in.linkedin.com/company/nihas-technologies" target="blanck" class="social-icon si-small si-borderless si-linkedin">
								<i class="fa fa-linkedin"></i>
								<i class="fa fa-linkedin"></i>
							</a>
						</div>

						<div class="clear"></div>

						<i class="fa fa-envelope-o"></i> info@nihastechnologies.com <span class="middot">&middot;</span> <i class="fa fa-phone"></i> +91 98949 99741
					</div>

				</div>

			</div><!-- #copyrights end -->

		</footer><!-- #footer end -->