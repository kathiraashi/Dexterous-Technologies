<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

 </head>
<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>


  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Videos</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Videos</li>
				</ol>
			</div>

		</section><!-- #page-title end -->


		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container-fluid clearfix">

               <div class="tabs side-tabs nobottommargin clearfix ui-tabs ui-widget ui-widget-content ui-corner-all row">
                           <!-- Sidebar
					============================================= -->
				<div class=" col-sm-4" style="width: 30%;">

					<ul class="tab-nav tab-nav2 clearfix ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist" style="width: 100%;">

					<?php
						$servername = "localhost";
						$username = "root";
						$password = "";
						$dbname = "nihas";
                        $conn = new mysqli($servername, $username, $password, $dbname);
						if ($conn->connect_error) {
						    die("Connection failed: " . $conn->connect_error);
						}    
						$sql = "SELECT * FROM videos ORDER BY id DESC";
						$result = $conn->query($sql);
						if ($result->num_rows > 0) {
						    while($row = $result->fetch_assoc()) { ?>

						    <li class="ui-state-default ui-corner-top">
						      <a href="#tabs-<?=$row["id"]?>" class="ui-tabs-anchor" style="padding: 10px 10px; line-height: 22px; font-size: 15px; font-weight: 500px;"> 
						      <?=$row["topic"]?> <br>

						      <span style="font-size: 13px; font-weight: 100 !important;">
                      <i class="fa fa-clock-o"></i>&nbsp;
                      <?php 
                        $myvalue = $row["time"];
                        $today = date('Y-m-d H:i:s');
                        $timeFirst  = strtotime($myvalue);
                        $timeSecond = strtotime($today);
                        $differenceInSeconds = $timeFirst - $timeSecond;
                        $diff=round(abs($timeFirst - $timeSecond));
                        $diffm= round(abs($timeFirst - $timeSecond) / 60,0 ) ;
                        $diffh= round(abs($timeFirst - $timeSecond) / 3600,0 ) ;
                        $diffd= round(abs($timeFirst - $timeSecond) / 86400,0 ) ;
                        if ( $diff <= 59) {
                        echo $diff." seconds ago";
                        }
                        if ( $diff >= 60 && $diff <= 3599 ) {
                        echo $diffm ." mins ago";
                        }
                        if ( $diff >= 3600 && $diff <= 86399 ) {
                        echo $diffh ." hours ago";
                        }
                        if ( $diff >= 86400) {
                        echo $diffd ." days ago";
                        }
                             ?>
                  </span>
                  						      </a>
						   </li>
						   <?php }
						} else {
						    echo "0 results";
						}
						?>
					 </ul>
					</div><!-- .sidebar end -->

							<!-- Postcontent
					============================================= -->
					<div class="col-sm-8  mr-0 ml-0">

							<div class="tab-container">

                          <?php 
							$sql = "SELECT * FROM videos ORDER BY id DESC";
							$result = $conn->query($sql);
							if ($result->num_rows > 0) {
						    while($row = $result->fetch_assoc()) { 
   	
                                 $iframe = $row["link"];
                                 if(stristr($iframe, 'www.youtu') !== false ) { $rows = str_replace("www.youtube.com/watch?v=","www.youtube.com/embed/", $row["link"]) ?>
                           
                               <div class="tab-content clearfix ui-tabs-panel ui-widget-content ui-corner-bottom" id="tabs-<?=$row["id"]?>"  style="display: none;">
                               <h4 style="text-transform: uppercase;margin-bottom: 3px;"> <?=$row["topic"]?></h4>
								    <center style="max-width: 700px;">
                                        <iframe width="300" height="200" src="<?= $rows?>" frameborder="0" allowfullscreen></iframe>
                                   </center>
                                   <p style="margin-top: 20px;font-size: 17px;">&emsp; &emsp; &emsp;<?=$row["description"]?></p>
							   </div>

							  

                         <?php } ?> 




						<?php }
							} else {
							    echo "0 results";
							}
						?>

							</div>

						</div>

					</div><!-- .postcontent end -->

					

				</div>

			</div>

		</section><!-- #content end -->
<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>



<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>
<script type="text/javascript">window.NREUM||(NREUM={});NREUM.info={"beacon":"bam.nr-data.net","licenseKey":"839484a19a","applicationID":"5289971","transactionName":"ZQEDZxZUD0FZVkxfX1xLNEENGglGVVkXVVFcEgBAS1YOXExUW0IdWwoNWgpQT0JQRQ==","queueTime":0,"applicationTime":8,"atts":"SUYAEV5OHE8=","errorBeacon":"bam.nr-data.net","agent":""}</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".resources").addClass("current");
	 });
</script>

</body>

</html>