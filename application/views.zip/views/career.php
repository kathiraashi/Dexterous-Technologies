<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>

  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Careers</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Careers</li>
				</ol>
			</div>

		</section><!-- #page-title end -->




	<?php if (isset($msg)){ ?>
	    <div class="style-msg successmsg">
			<div class="sb-msg"><i class="fa fa-check"></i> <?php echo $msg; ?> </div>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			</div>
       <?php } ?>





		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="col_three_fifth nobottommargin">

					<?php foreach ($careers as $career) { ?>

						<div class="fancy-title title-bottom-border">
							<h3><?=$career->name?></h3>
						</div>

						<p><?=$career->description?></p>

						<div class="accordion accordion-bg clearfix">

							<div class="acctitle"><i class="acc-closed fa fa-chevron-circle-down"></i><i class="acc-open fa fa-times-circle-o"></i>Responsibilities</div>
							<div class="acc_content clearfix">
							  <ul class="iconlist iconlist-color nobottommargin">

							<?php	$this->db->select("*")->from('career_responsibilities')
				                   ->where(array('career_id'=> $career->id))
				                   ->order_by("career_responsibilities.id desc");
				              $query = $this->db->get();
				              $responsibilities =$query->result();
				              
				              foreach($responsibilities as $responsibility){ ?>

									<li><i class="fa fa-check"></i> 
									&nbsp; &nbsp; <?=$responsibility->responsibilities?></li>
								<?php } ?>
								</ul>
							</div>

							<div class="acctitle"><i class="acc-closed fa fa-chevron-circle-down"></i><i class="acc-open fa fa-times-circle-o"></i>Requirements</div>
							<div class="acc_content clearfix">
								<ul class="iconlist iconlist-color nobottommargin">
									<?php	$this->db->select("*")->from('career_requirement')
				                   ->where(array('career_id'=> $career->id))
				                   ->order_by("career_requirement.id desc");
				              $query = $this->db->get();
				              $requirements =$query->result();
				              
				              foreach($requirements as $requirement){ ?>

									<li><i class="fa fa-check"></i> 
									&nbsp; &nbsp; <?=$requirement->requirement?></li>
								<?php } ?>
								</ul>
							</div>

							<div class="acctitle"><i class="acc-closed fa fa-chevron-circle-down"></i><i class="acc-open fa fa-times-circle-o"></i>Desired Candidate Profile</div>
							<div class="acc_content clearfix">
							  <ul class="iconlist iconlist-color nobottommargin">
									<?php	$this->db->select("*")->from('career_desired')
				                   ->where(array('career_id'=> $career->id))
				                   ->order_by("career_desired.id desc");
				              $query = $this->db->get();
				              $career_desireds =$query->result();
				              
				              foreach($career_desireds as $desired){ ?>

									<li><i class="fa fa-check"></i> 
									&nbsp; &nbsp; <?=$desired->career_desired_profile?></li>
								<?php } ?>
								</ul>
							</div>

						</div>

						<a href="#" data-scrollto="#job-apply" class="button button-3d button-black nomargin">Apply Now</a>

						<div class="divider divider-short"><i class="fa fa-star"></i></div>

                     <?php } ?>

					</div>



					<div class="col_two_fifth nobottommargin col_last">

						<div id="job-apply" class="heading-block highlight-me">
							<h2>Apply Now</h2>
							<span>And we'll get back to you within 48 hours.</span>
						</div>

						<div class="">
							<form action="<?=base_url()?>index.php/Index/job" onsubmit="return validateMyForm_1();" method="post" enctype="multipart/form-data">

								<div class="form-process"></div>

								<div class="col_half">
									<label>First Name <small>*</small></label>
									<input type="text"  name="fname"  class="sm-form-control required"  />
								</div>

								<div class="col_half col_last">
									<label>Last Name <small>*</small></label>
									<input type="text" name="lname" class="sm-form-control required"  />
								</div>

								<div class="col_half">
									<label for="template-jobform-age">Age <small>*</small></label>
									<input type="text" name="age"  class="sm-form-control required"  />
								</div>

								<div class="col_half col_last">
									<label>Gender <small>*</small></label>
									<select name="gender"  class="sm-form-control required">
                                     <option  value="Male">Male</option>
                                     <option  value="Female">Female</option>
									</select>
								</div>

								<div class="col_full">
									<label>Email <small>*</small></label>
									<input type="email" name="email"  class="required email sm-form-control"  />
								</div>


								<div class="col_full">
									<label>Phone Number <small>*</small></label>
									<input type="text"  name="phone" value="" class="required phone sm-form-control"  />
								</div>


								<div class="col_full">
									<label>Position <small>*</small></label>
									<select name="position" class="sm-form-control required">
                                     <option selected disabled value="blank">-- Select Position --</option>
									<?php foreach ($careers as $career) { ?>
                                      <option value="<?=$career->name?>"><?=$career->name?></option>
									 <?php } ?>
									</select>
								</div>

								<div class="col_full">
									<label>Yeras of Experience <small>*</small></label>
									<input type="text" name="experience" class="sm-form-control required"  />
								</div>

								<div class="col_full">
									<label >Commend <small>*</small></label>
									<textarea name="commend"  rows="6" tabindex="11" class="sm-form-control required"  ></textarea>
								</div>

								<div class="col_full">
								  <label>Attach Resume<small>*</small></label>
									<input type="file" name="resume" class="sm-form-control required" accept=".pdf, .docx, .doc"  />
								</div>

								<div class="col_full">
									<button class="button button-3d button-large btn-block nomargin" type="submit"> Send Application</button>
								</div>

							</form>

						</div>

					</div>



				</div>

			</div>

		</section><!-- #content end -->

    <?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".career").addClass("current");

        $(".style-msg button.close").click(function(){
     	 window.location.href='<?=base_url()?>index.php/Index/career';
       });
	 });
</script>

<script>
   function validateMyForm_1(){

       if($('input[name=fname]').val() == ""){
              $('input[name=fname]').addClass('red')
              return false;
        }else if($('input[name=lname]').val() == ""){
              $('input[name=lname]').addClass('red')
              return false;
        }else if($('input[name=age]').val() == ""){
              $('input[name=age]').addClass('red')
              return false;
        }else if($('input[name=email]').val() == ""){
              $('input[name=email]').addClass('red')
              return false;
        }else if($('input[name=phone]').val() == ""){
              $('input[name=phone]').addClass('red')
              return false;
        }else if($('input[name=experience]').val() == ""){
              $('input[name=experience]').addClass('red')
              return false;
        }else if($('input[name=resume]').val() == ""){
              $('input[name=resume]').addClass('red')
              return false;
        }else{

              return true;
      }
 }

 $('input').keyup(function(){
 	$(this).removeClass('red');
 })
</script>




<script> 

	$(".msg_close").click(function(){
	    $('.msg').hide();
	});

</script>

</body>

</html>