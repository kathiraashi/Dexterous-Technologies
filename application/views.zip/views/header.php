
		<!-- Top Bar
		============================================= -->
		<div id="top-bar">

			<div class="container clearfix">

				<div class="col_half nobottommargin">

					<!-- Top Links
					============================================= -->
					<div class="top-links">
						<ul>
							<li><a href="<?=base_url()?>index.php/Index/career">Career</a></li>
							<li><a href="<?=base_url()?>index.php/Index/videos">Videos</a></li>
							<li><a href="<?=base_url()?>index.php/Index/contact">Contact</a></li>
							<!-- <li><a href="#">Login</a> -->
								<div class="top-link-section">
									<form id="top-login" role="form">
										<div class="input-group" id="top-login-username">
											<span class="input-group-addon"><i class="icon-user"></i></span>
											<input type="email" class="form-control" placeholder="Email address" required="">
										</div>
										<div class="input-group" id="top-login-password">
											<span class="input-group-addon"><i class="icon-key"></i></span>
											<input type="password" class="form-control" placeholder="Password" required="">
										</div>
										<label class="checkbox">
										  <input type="checkbox" value="remember-me"> Remember me
										</label>
										<button class="btn btn-danger btn-block" type="submit">Sign in</button>
									</form>
								</div>
							</li>
						</ul>
					</div><!-- .top-links end -->

				</div>

				<div class="col_half fright col_last nobottommargin">

					<!-- Top Social
					============================================= -->
					<div id="top-social">
						<ul>
							<li>
								<a href="https://www.facebook.com/nihastechnologiescbe" target="blanck" class="si-facebook">
									<span class="ts-icon">
										<i class="fa fa-facebook"></i>
									</span>
									<span class="ts-text">Facebook</span>
								</a>
							</li>
							<li>
								<a href="https://twitter.com/Nihas_Tech" target="blanck" class="si-twitter">
									<span class="ts-icon">
										<i class="fa fa-twitter"></i>
									</span>
									<span class="ts-text">Twitter</span>
								</a>
							</li>
							<li>
								<a href="https://in.linkedin.com/company/nihas-technologies" target="blanck" class="si-linkedin">
									<span class="ts-icon">
										<i class="fa fa-linkedin"></i>
									</span>
									<span class="ts-text">Linkedin</span>
								</a>
							</li>
							<li>
								<a href="tel:+91 98949 99741" target="blanck" class="si-call">
									<span class="ts-icon">
										<i class="fa fa-phone"></i>
									</span>
									<span class="ts-text">+91 98949 99741</span>
								</a>
							</li>
							<li>
								<a href="mailto:info@nihastechnologies.com" class="si-email3">
									<span class="ts-icon">
										<i class="fa fa-envelope-o"></i>
									</span>
									<span class="ts-text">info@nihastechnologies.com</span>
								</a>
							</li>
						</ul>
					</div><!-- #top-social end -->
				</div>

			</div>

		</div><!-- #top-bar end -->

		<!-- Header
		============================================= -->
		<header id="header">

			<div id="header-wrap">

				<div class="container clearfix">

					<div id="primary-menu-trigger"><i class="icon-reorder"></i></div>

					<!-- Logo
					============================================= -->
					<div id="logo">
						<a href="<?=base_url()?>index.php" class="standard-logo" data-dark-logo="<?=base_url()?>assets/images/logo.jpg"><img src="<?=base_url()?>assets/images/logo.png" alt="NIHAS" style="padding: 5px 0px;"></a>
						<a href="<?=base_url()?>index.php" class="retina-logo" data-dark-logo="<?=base_url()?>assets/images/logo.jpg"><img src="<?=base_url()?>assets/images/logo.png" alt="NIHAS" style="padding: 5px 0px;"></a>
					</div><!-- #logo end -->

					<!-- Primary Navigation
					============================================= -->
					<nav id="primary-menu" class="sub-title">

						<ul>
							<li class="home"><a href="<?=base_url()?>index.php"><div>HOME</div></a>
							</li>
							<li class="about"><a href="<?=base_url()?>index.php/Index/about"><div>ABOUT US</div></a></li>

							<li class="products"><a href="#"><div>PRODUCTS</div></a>
								<ul>
									<li>
				                   	<a href="#">
				                   	  <div style="font-size: 15px;"> Software Solutions </div>
				                   	</a>
				                   	<ul>
				                   	 <?php	$this->db->select("*")->from('product_type')->where(array('category_id' =>"2"));
				                        $pro_query_1 = $this->db->get();
				                          $product_categories_1 =$pro_query_1->result();		
				                      foreach($product_categories_1 as $product_category_1){ ?>
				                      <li>
										<a href="<?=base_url()?>index.php/Index/products/<?=$product_category_1->id?>">
										 <div style="font-size: 15px;"><?=$product_category_1->name?></div>
										</a>
									  </li>	
                                     <?php }?>
				                   	</ul>
				                   </li>
				                   <li>
				                   	<a href="#">
				                   		<div style="font-size: 15px;"> Lab Equipments </div>
				                   	</a>
				                   	<ul>
				                   	 <?php	$this->db->select("*")->from('product_type')->where(array('category_id' =>"1"));
				                        $pro_query = $this->db->get();
				                          $product_categories =$pro_query->result();		
				                      foreach($product_categories as $product_category){ ?>
				                      <li>
										<a href="<?=base_url()?>index.php/Index/products/<?=$product_category->id?>">
										 <div style="font-size: 15px;"><?=$product_category->name?></div>
										</a>
									  </li>	
                                     <?php }?>
				                   	</ul>
				                   </li> 
								</ul>
							</li>



							<li class="industries"><a href="#"><div>INDUSTRIES</div></a>
								<ul>
									<?php	$this->db->select("*")->from('industries');
				                        $industry_query = $this->db->get();
				                          $industries_all =$industry_query->result();
				              
				                   foreach($industries_all as $industry_all){ ?>

									<li>
										<a href="<?=base_url()?>index.php/Index/industries/<?=$industry_all->id?>">
											<div style="font-size: 15px;"><?=$industry_all->name?></div>
										</a>
									</li>

                                     <?php }?>
								</ul>
							</li>

							<li class="services">
								<a href="#"><div>SUPPORT & SERVICES</div></a>
								<ul>
									<li>
										<a href="<?=base_url()?>index.php/Index/services">
											<div style="font-size: 15px;"> SERVICES </div>
										</a>
									</li>
									<li>
										<a href="<?=base_url()?>index.php/Index/support">
											<div style="font-size: 15px;"> CUSTOMER SUPPORT </div>
										</a>
									</li>
								</ul>
							</li>

							<li class="resources"><a href="#"><div>RESOURCES</div></a>
								<ul>
									<li>
										<a href="<?=base_url()?>index.php/Index/white_papers">
											<div style="font-size: 15px;">White Papers</div>
										</a>
									</li>
									<li>
										<a href="<?=base_url()?>index.php/Index/videos">
											<div style="font-size: 15px;">Videos</div>
										</a>
									</li>
									<li>
										<a href="<?=base_url()?>index.php/Index/case_studies">
											<div style="font-size: 15px;">Case Studies</div>
										</a>
									</li>
									<li>
										<a href="<?=base_url()?>index.php/Index/brochures">
											<div style="font-size: 15px;">Brochures</div>
										</a>
									</li>
									<li>
										<a href="<?=base_url()?>index.php/Index/draft_sight">
											<div style="font-size: 15px;">Draft Sight</div>
										</a>
									</li>
									<li>
										<a href="<?=base_url()?>index.php/Index/edrawing">
											<div style="font-size: 15px;">eDrawings</div>
										</a>
									</li>
								</ul>
							</li>


							<li class="events"><a href="<?=base_url()?>index.php/Index/events">EVENTS</a></li>
							
						</ul>



						<!-- Top Search
						============================================= -->
						<!-- <div id="top-search">
							<a href="#" id="top-search-trigger"><i class="fa fa-search"></i><i class="icon-line-cross"></i></a>
							<form action="" method="get">
								<input type="text" name="q" class="form-control" value="" placeholder="Type &amp; Hit Enter..">
							</form>
						</div> -->
						<!-- #top-search end -->

					</nav><!-- #primary-menu end -->

				</div>

			</div>

		</header><!-- #header end -->
