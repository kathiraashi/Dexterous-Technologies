<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
  <head>

	<meta charset="utf-8">

	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=2" />

	<meta name="tagline" content="Full Service Provider (FSP)" />

	<meta name="description" content="Nihas Technologies an authorized solidworks Reseller in Coimbatore Tamil Nadu.">

	<meta name="keywords" content="Solidworks Authorized Reseller in Coimbatore, Solidworks, solidworks, Solidworks Coimbatore, solidworks coimbatore, Solidworks Authorized Reseller in Tamilnadu, Solidworks Standard in Coimbatore Tamilnadu, Solidworks Professional in Coimbatore Tamilnadu, Solidworks Premium in Coimbatore Tamilnadu, Solidworks Electrical in Coimbatore Tamilnadu, Solidworks EPDM in Coimbatore Tamilnadu, Solidworks Simulation in Coimbatore Tamilnadu"/>

	<title>Solidworks Authorized Reseller in Coimbatore - Nihas Technologies</title>

	<link rel="canonical" href="http://www.nihastechnolohies.com/" />

	<meta property="og:locale" content="en_US" />

	<meta property="og:type" content="website" />

	<meta property="og:title" content="Solidworks Authorized Reseller in Coimbatore - Nihas Technologies" />

	<meta property="og:description" content="Nihas Technologies an authorized solidworks Reseller in Coimbatore Tamil Nadu." />

	<meta property="og:url" content="http://www.nihastechnolohies.com/" />

	<meta property="og:site_name" content="Nihas Technologies" />

    <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">

	<link href="http://fonts.googleapis.com/css?family=Lato:300,400,400italic,600,700|Raleway:300,400,500,600,700|Crete+Round:400italic" rel="stylesheet" type="text/css" />

	<link rel="stylesheet" href="<?=base_url()?>assets/custom_css/main.css" type="text/css" />
	<link rel="stylesheet" href="<?=base_url()?>assets/custom_css/swiper.css" type="text/css" />
	<script src="https://use.fontawesome.com/1e6ee5b8f4.js"></script>

	<script src='https://www.google.com/recaptcha/api.js'></script>

	<style type="text/css">
	 	.fbox-icon .fa{
	 		line-height: 64px !important;
	   }
	   .red{
	 		border:2px solid red !important;
	 	}
    </style>

  </head>