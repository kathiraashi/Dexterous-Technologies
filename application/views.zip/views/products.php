<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

 </head>

 <style type="text/css">
 	.pro_ul{
 		list-style-type: none;
 		margin: 0px;
 	}
 	.pro_li{
 		width: 100%;
 		padding: 5px 15px;
 	}
 	.pro_li a{
 		font-size: 16px; 
 		color: inherit;
 		width: 85%;
 	}

   .accordion.accordion-border .acc_content{
   	margin:0px;
   	padding:0px;
   }
   .red{
 		border:2px solid red !important;
 	}
 	td, th{
 		    padding: 0;
    border: 1px solid gray;
    text-align: center;
 	}

 </style>



<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>
        

         		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">
			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Products</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<?php $this->db->select("*")->from('product_type')->where(array('id' =>$product_type_id))->order_by("product_type.id desc");
				           $pro_query = $this->db->get();
				           $product_categories =$pro_query->result();		
				     foreach($product_categories as $product_category){ ?>
						<li class="active"><?=$product_category->category?></li>
						<li class="active"><?=$product_category->name?></li>
					<?php } ?>
				</ol>
			</div>
		</section><!-- #page-title end -->


	<?php if (isset($msg)){ ?>
	    <div class="style-msg successmsg">
			<div class="sb-msg"><i class="fa fa-check"></i> <?php echo $msg; ?> </div>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			</div>
       <?php } ?>




		<!-- Content
		============================================= -->
		<section id="content">

          <div class="container" style="padding: 50px 0px;">
			<div class="tabs side-tabs nobottommargin clearfix ui-tabs ui-widget ui-widget-content ui-corner-all" id="tab-6">

			  <ul class="tab-nav tab-nav2 clearfix ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist" style="width: 300px">
			  	<?php foreach ($products as $product ) {?>
				<li class="ui-state-default ui-corner-top" role="tab">
					<a href="#tabs-<?=$product->id?>" class="ui-tabs-anchor"><?=$product->name?> </a>
				</li>
				<?php } ?>
			  </ul>

			  <div class="tab-container">
               <?php foreach ($products as $product ) {?>
				<div class="tab-content clearfix ui-tabs-panel ui-widget-content ui-corner-bottom" id="tabs-<?=$product->id?>" role="tabpanel">
					<div class="row" style="margin-bottom: 20px; ">
						<div class="col-sm-12"><h3 style="margin-bottom: 5px"><?=$product->name?></h3></div>
						<div class="col-sm-12">
							<div class="" style="float: right;"> 
								<button data-toggle="modal" data-target="#contactFormModal" data-id="<?=$product->id?>" data-name="<?=$product->name?>" data-type="Demo" class="button button-3d nomargin get_pro"   value="">Get a Demo</button>
								<button data-toggle="modal" data-target="#contactFormModal" data-id="<?=$product->id?>" data-name="<?=$product->name?>" data-type="Quote" class="button button-3d nomargin get_pro" value="">Get a Quote</button>
								<button data-toggle="modal" data-target="#contactFormModal" data-id="<?=$product->id?>" data-name="<?=$product->name?>" data-type="Trial" class="button button-3d nomargin get_pro" value="">Get a Trial</button>
							</div>
						</div>
					</div>
					<div class="row">
						<div class="col-sm-7" style="padding: 10px;">
							<img src="<?=base_url()?>assets/admin/images/<?=$product->image?>" style="width: 100%;">
						</div>
						<p> <?=$product->description?></p>
					</div>				     
				</div>
              <?php } ?>
			  </div>
		    </div> 
          </div>







                  <div class="modal fade" id="contactFormModal" tabindex="-1" role="dialog" aria-labelledby="contactFormModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" style="color: gray;" data-dismiss="modal" aria-hidden="true">&times;</button>
										<h4 class="modal-title model_head">Request a quote</h4>
									</div>
									<div class="modal-body">

										<div class="">
											
											<form class="nobottommargin" id="quot_form"  action="<?=base_url()?>index.php/Index/product_request" onsubmit="return validateMyForm_1();" method="post">

												<div class="form-process"></div>

												<div class="col_half">
													<label> Name <small>*</small></label>
													<input type="text"  name="name"  class="sm-form-control required"  />
												</div>

												<div class="col_half col_last">
													<label >Designation </label>
													<input type="text" name="designation" value="" class=" sm-form-control" />
												</div>

												<div class="clear"></div>

												<div class="col_half">
													<label>Company Name</label>
													<input type="text" name="company" value="" class="required sm-form-control" />
												</div>

												<div class="col_half col_last">
													<label>Email</label><small>*</small>
													<input type="email" name="email" value="" class="required sm-form-control"  />
												</div>

												<div class="clear"></div>

												<input type="hidden" name="type" value="" id="get_type" />
												<input type="hidden" name="product_name" value="" id="get_product_name" />
												<input type="hidden" name="product_id" value="" id="get_product_id" />



												<div class="col_half">
													<label>Phone </label><small>*</small>
													<input type="text" name="phone" value="" class="required sm-form-control" />
												</div>

												<div class="col_half col_last">
													<label> Address <small>*</small></label>
													<textarea class="required sm-form-control" name="address" rows="3" cols="30"></textarea>
												</div>

												<div class="clear"></div>

												<div class="col_full">
													<label>Message <small>*</small></label>
													<textarea class="required sm-form-control" name="message" rows="5" cols="30"></textarea>
												</div>

												<div class="col_full hidden">
													<input type="text" id="template-contactform-botcheck" name="template-contactform-botcheck" value="" class="sm-form-control" />
												</div>

												<div class="col_full">
													<button class="button button-3d nomargin" type="submit" value="submit">Send Message</button>
												</div>

											</form>

										</div>


									</div>
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->



               



		</section><!-- #content end -->

		<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>


<script>
   function validateMyForm_1(){

       if($('input[name=name]').val() == ""){
              $('input[name=name]').addClass('red')
              return false;
        }else if($('input[name=email]').val() == ""){
              $('input[name=email]').addClass('red')
              return false;
        }else if($('input[name=phone]').val() == ""){
              $('input[name=phone]').addClass('red')
              return false;
        }else{

              return true;
      }
 }

 $('input').keyup(function(){
 	$(this).removeClass('red');
 })
</script>




<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".products").addClass("current");
	 });
</script>

 <script type="text/javascript">
 	$(document).ready(function(){
	 	$(".pro_li").mouseenter(function(){
	 		$(this).css("background-color","#f1f1f1");
	 		$(this).find('.pro_a').css("color","#0182C2");
	 	});
	 	$(".pro_li").mouseleave(function(){
	 		$(this).css("background-color","#ffffff");
	 		$(this).find('.pro_a').css("color","inherit");
	 	});
	 });
 </script>

  <script type="text/javascript">
 	$(document).ready(function(){
 		$(".pro_div").hide();
 		$(".pro_div.active").show();
	 	$(".pro_li").click(function(){
	 		$(".pro_div").hide();
	 		var id = $(this).find('.pro_a').attr("href");
	 		$(id).show();
	 	});
	 	
	 });
 </script>

  <script type="text/javascript">
 	$(document).ready(function(){
	 	$(".get_pro").click(function(){
	 		var id = $(this).attr('data-id');
	 		var name = $(this).attr('data-name');
	 		var type = $(this).attr('data-type');
	 		$('#get_type').val(type);
	 		$('#get_product_id').val(id);
	 		$('#get_product_name').val(name);
	 		if (type == "Demo") {
	 		  $('.model_head').text('Request a Demo')	
	 		}else if(type == "Quote"){
               $('.model_head').text('Request a Quote')
	 		}else{
	 			$('.model_head').text('Request a Trial')
	 		}
	 		
	 	});
     $(".style-msg button.close").click(function(){
     	 window.location.href='<?=base_url()?>index.php/Index/products/<?php echo $product_type_id?>';
     });

	 	
	 });
 </script>




<script>
	$( document ).ready(function() { 
          var path =  $(".pro_act_ty" ).first().next().find(".pro_act_a").first().attr( "data-path");
          var type = "#";
          var id = type+path;
           $(id).css('display','block');
      });
</script>


</body>

</html>