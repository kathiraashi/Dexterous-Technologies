<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

 </head>

 <style type="text/css">
 	td, th{
 		    padding: 0;
    border: 1px solid gray;
    text-align: center;
 	}
 </style>



<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>


  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Draft Sight</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Draft Sight</li>
				</ol>
			</div>

		</section><!-- #page-title end -->


<?php foreach ($draft_sight as $draft) { ?>
		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix" style="margin-top: -59px;">

					<div id="side-navigation" class="tabs custom-js">

						<div class=" col_last nobottommargin">

							<div id="snav-content1 row">
								<div class="col-sm-12">
								   <img class="img-responsive" style="height: 300px;width: 100%;" src="<?=base_url()?>assets/admin/images/<?=$draft->image?>" alt="">
								</div>
								
                               <div class="col-sm-12">
								<p style="text-align: justify;">
									<?=$draft->description?>
								</p>
							</div>
							<div class="row">
								<div class="col-sm-12">
									<a href="<?=base_url()?>assets/admin/files/<?=$draft->pdf?>" download class="btn btn-primary btn-sm pull-right" style=" font-size: 20px;"> Download <i class="fa fa-download" aria-hidden="true"></i></a>
								</div>
							</div>
							</div>

							</div>

					</div>

				</div>
			</div>

		</section><!-- #content end -->

		<?php } ?>

		<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".resources").addClass("current");
	 });
</script>

</body>

</html>