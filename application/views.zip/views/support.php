<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

 </head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>


  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Customer Support</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Customer Support</li>
				</ol>
			</div>

		</section><!-- #page-title end -->


			<?php if (isset($msg)){ ?>
	    <div class="style-msg successmsg">
			<div class="sb-msg"><i class="fa fa-check"></i> <?php echo $msg; ?> </div>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			</div>
       <?php } ?>


		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap">

				<div class="container clearfix">

					<div class="col_three_fifth nobottommargin">

						<div class="fancy-title" style="border-bottom: 2px solid silver">
							<h3><a>Software Soulution</a></h3>
						</div>

						<div class="col-sm-12" style="margin-bottom: 120px;">

							<h3 style="margin-bottom: 7px;"> Dhayanithi.M</h3>
							<p style="margin: 5px 0px;"> <b>Email:</b> dhayanithi@nihastechnologies.com</p>
							<p style="margin: 5px 0px;"> <b>Mobile:</b>+91 73388 21322</p>
							<p style="margin: 5px 0px;"> <b>Phone:</b>0422-438 9741</p>
							
						</div>

						

						<div class="fancy-title" style="border-bottom: 2px solid silver"> 
							<h3><a> Lab Equipments</a></h3>
						</div>

						<div class="col-sm-12">

							<h3 style="margin-bottom: 7px;"> Ilangovan.M</h3>
							<p style="margin: 5px 0px;"> <b>Email:</b> ilango@nihastechnologies.com</p>
							<p style="margin: 5px 0px;"> <b>Mobile:</b>+91 98949 99741</p>
							<p style="margin: 5px 0px;"> <b>Phone:</b>0422-438 9741</p>
							
						</div>

					</div>











                <div class="col_two_fifth nobottommargin col_last">

					<div class="tabs tabs-bb clearfix ui-tabs ui-widget ui-widget-content ui-corner-all" id="tab-9">

							<ul class="tab-nav clearfix ui-tabs-nav ui-helper-reset ui-helper-clearfix ui-widget-header ui-corner-all" role="tablist">

								<li style="width: 50%" class="ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tabs-34" aria-labelledby="ui-id-1" aria-selected="false" aria-expanded="false"><a href="#tabs-1" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-1"> <h4> Software Solution </h4> </a></li>

								<li style="width: 50%" class="hidden-phone ui-state-default ui-corner-top" role="tab" tabindex="-1" aria-controls="tabs-2" aria-labelledby="ui-id-2" aria-selected="false" aria-expanded="false"><a href="#tabs-2" class="ui-tabs-anchor" role="presentation" tabindex="-1" id="ui-id-2"> <h4> Lab Equipments </h4> </a></li>

							</ul>

							<div class="tab-container" style="padding-top: 0px;">

								<div class="tab-content clearfix ui-tabs-panel ui-widget-content ui-corner-bottom" id="tabs-1" aria-labelledby="ui-id-1" role="tabpanel" aria-hidden="true" style="display: none;">
									
									<div class="col_full nobottommargin">

										<div id="job-apply" class="heading-block highlight-me">
											<span>Message To Software Solution, Customer Support Team.</span>
										</div>

										<div class="">
											<form action="<?=base_url()?>index.php/Index/customer_support_submit" onsubmit="return validateMyForm_1();" method="post" enctype="multipart/form-data">

												<div class="form-process"></div>

												<div class="col_half">
													<label> Name <small>*</small></label>
													<input type="text"  name="name"  class="sm-form-control required"  />
												</div>

												<div class="col_half col_last">
													<label> Company <small>*</small></label>
													<input type="text" name="company" class="sm-form-control required"  />
												</div>

												<div class="col_half">
													<label> Phone  <small>*</small></label>
													<input type="text" name="phone"  class="sm-form-control required"  />
												</div>

												<div class="col_half col_last">
													<label>Email <small>*</small></label>
													<input type="email" name="email"  class="sm-form-control required"  />
												</div>
												<input type="text" name="type" value="Software Solution" style="display: none;">

												<div class="col_full">
													<label> Products <small>*</small></label>
													<select name="products" class="sm-form-control required">
													<option selected disabled value="">-- Select Software Solution Products --</option>

													<?php foreach($softwars as $softwar){ 
												 	$this->db->select("*")->from('products')->where(array('product_type_id' =>$softwar->id));
				                                   $pro_1 = $this->db->get();
				                                   $products_1 =$pro_1->result();		
				                                   foreach($products_1 as $product_1){ ?>

				                                      <option value="<?=$product_1->name?>"><?=$product_1->name?></option>

													 <?php } } ?>

													</select>
												</div>

												<div class="col_full">
													<label>Yeras of Purchase</label>
													<input type="text" name="purchase_year" class="sm-form-control "  />
												</div>

												<div class="col_full"> 
													<label>In Subscription</label>
													<select name="subscription" class="sm-form-control">
                                                     <option value="Yes"> Yes</option>
                                                     <option value="No"> No </option>
													</select>
											    </div>

												<div class="col_full">
													<label > Message <small>*</small></label>
													<textarea name="message"  rows="6" tabindex="11" class="sm-form-control required"  ></textarea>
												</div>

												<div class="col_full">
													<button class="button button-3d button-large btn-block nomargin" type="submit"> Send Message</button>
												</div>

											</form>

										</div>

									</div>
								</div>

								<div class="tab-content clearfix ui-tabs-panel ui-widget-content ui-corner-bottom" id="tabs-2" aria-labelledby="ui-id-2" role="tabpanel" aria-hidden="true" style="display: none;">
									
									<div class="col_full nobottommargin ">

										<div id="job-apply" class="heading-block highlight-me">
											<span>Message To Lab Equipments, Customer Support Team.</span>
										</div>

										<div class="">
											<form action="<?=base_url()?>index.php/Index/customer_support_submit" onsubmit="return validateMyForm_1();" method="post" enctype="multipart/form-data">

												<div class="form-process"></div>

												<div class="col_half">
													<label> Name <small>*</small></label>
													<input type="text"  name="name"  class="sm-form-control required"  />
												</div>

												<div class="col_half col_last">
													<label> Company <small>*</small></label>
													<input type="text" name="company" class="sm-form-control required"  />
												</div>

												<div class="col_half">
													<label> Phone  <small>*</small></label>
													<input type="text" name="phone"  class="sm-form-control required"  />
												</div>

												<div class="col_half col_last">
													<label>Email <small>*</small></label>
													<input type="email" name="email"  class="sm-form-control required"  />
												</div>
												<input type="text" name="type" value="Lab Equipments" style="display: none;">

												<div class="col_full">
													<label> Products <small>*</small></label>
													<select name="products" class="sm-form-control required">
													<option selected disabled value="">-- Select Lab Equipments Products --</option>

													<?php foreach($equipments as $equipment){ 
												 	$this->db->select("*")->from('products')->where(array('product_type_id' =>$equipment->id));
				                                   $pro_2 = $this->db->get();
				                                   $products_2 =$pro_2->result();		
				                                   foreach($products_2 as $product_2){ ?>

				                                      <option value="<?=$product_2->name?>"><?=$product_2->name?></option>

													 <?php } } ?>

													</select>
												</div>

												<div class="col_full">
													<label>Yeras of Purchase</label>
													<input type="text" name="purchase_year" class="sm-form-control "  />
												</div>

												<div class="col_full"> 
													<label>In Subscription</label>
													<select name="subscription" class="sm-form-control">
                                                     <option value="Yes"> Yes</option>
                                                     <option value="No"> No </option>
													</select>
											    </div>

												<div class="col_full">
													<label > Message <small>*</small></label>
													<textarea name="message"  rows="6" tabindex="11" class="sm-form-control required"  ></textarea>
												</div>

												<div class="col_full">
													<button class="button button-3d button-large btn-block nomargin" type="submit"> Send Message</button>
												</div>

											</form>

										</div>

									</div>
								</div>

							</div>

						</div>


                    </div>














			</div>

		</section><!-- #content end -->




<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".services").addClass("current");
	 });
</script>

</body>

</html>