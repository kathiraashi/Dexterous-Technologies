<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

 </head>
<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>

		<section id="slider" class="slider-parallax swiper_wrapper full-screen clearfix">

			<div class="slider-parallax-inner">

				<div class="swiper-container swiper-parent">
					<div class="swiper-wrapper">

						<?php foreach ($sliders as $slider){?>

						<div class="swiper-slide dark" style="background-image: url('<?=base_url()?>assets/admin/images/<?=$slider->image?>');">
							<div class="container clearfix">
								<div class="slider-caption slider-caption-center">
									<h2 data-caption-animate="fadeInUp"><?=$slider->title?></h2>
									<p data-caption-animate="fadeInUp" data-caption-delay="200"><?=$slider->text?></p>
								</div>
							</div>
						</div>
							
						<?php } ?>



<!-- 						<div class="swiper-slide dark" style="background-image: url('<?=base_url()?>assets/images/1.jpg');">
							<div class="container clearfix">
								<div class="slider-caption slider-caption-center">
									<h2 data-caption-animate="fadeInUp">Welcome to Nihas</h2>
									<p data-caption-animate="fadeInUp" data-caption-delay="200">Create just what you need for your Perfect Website. Choose from a wide range of Elements &amp; simply put them on our Nihas.</p>
								</div>
							</div>
						</div>

						<div class="swiper-slide dark" style="background-image: url('<?=base_url()?>assets/images/1.jpg');">
							<div class="container clearfix">
								<div class="slider-caption slider-caption-center">
									<h2 data-caption-animate="fadeInUp">Welcome to Nihas</h2>
									<p data-caption-animate="fadeInUp" data-caption-delay="200">Create just what you need for your Perfect Website. Choose from a wide range of Elements &amp; simply put them on our Nihas.</p>
								</div>
							</div>
						</div>

						<div class="swiper-slide" style="background-image: url('<?=base_url()?>assets/images/3.jpg'); background-position: center top;">
							<div class="container clearfix">
								<div class="slider-caption">
									<h2 data-caption-animate="fadeInUp">Great Performance</h2>
									<p data-caption-animate="fadeInUp" data-caption-delay="200">You'll be surprised to see the Final Results of your Creation &amp; would crave for more.</p>
								</div>
							</div>
						</div>
 -->
					</div>
					<div id="slider-arrow-left"><i class="fa fa-arrow-left"></i></div>
					<div id="slider-arrow-right"><i class="fa fa-arrow-right"></i></div>
					<div id="slide-number"><div id="slide-number-current"></div><span>/</span><div id="slide-number-total"></div></div>
				</div>

			</div>

		</section>

		<!-- Content
		============================================= -->
		<section id="content">

			<div class="content-wrap" style="padding-bottom:0px">

			<div class="section header-stick" style="background-color: #ffffff;">
					<div class="container clearfix">
						<div class="row">

							<div class="col-md-9">
								<div class="heading-block bottommargin-sm">
									<h3>We specialize in Robust Software Solutions</h3>
								</div>

								<p class="nobottommargin">Lasting change, stakeholders development Angelina Jolie world problem solving progressive. Courageous; social entrepreneurship change; accelerate resolve pursue these aspirations asylum.</p>
							</div>

							<div class="col-md-3">
								<a href="<?=base_url()?>index.php/Index/services" class="button button-3d button-dark button-large btn-block center" style="margin-top: 30px;">Check our Services</a>
							</div>

						</div>
					</div>
				</div>
	    </div>
                 


                 <div class="section header-stick">
                 <div class="container clearfix">
						<div class="row">

							<div class="col-md-5">
								<div class="nobottommargin">
									<a href="http://vimeo.com/101373765" data-lightbox="iframe">
										<img src="<?=base_url()?>assets/images/111.jpg" alt="Image">
										<span class="i-overlay" style="background-color: transparent;"><img src="<?=base_url()?>assets/images/play.png" alt="Play"></span>
									</a>
					            </div>
							</div>
                         <?php foreach ($about_us as $about) { ?>
							<div class="col-md-7">
								<div class="nobottommargin col_last" >

									<div class="heading-block">
										<h2>ABOUT <span class="color">NIHAS TECHNOLOGIES</span></h2>
									</div>

									<p style="text-align: justify;"><?=$about->about?></p>

									
								</div>
							</div>

							<?php } ?>

						</div>
					</div>

					</div>




				<div class="section header-stick" style="background-color: #ffffff;">
				<div class="container clearfix">

				  <div class="heading-block center">
						<h4>OUR PRODUCTS</h4>
											</div>

					<div class="col_one_third">
						<div class="feature-box fbox-rounded fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="fa fa-desktop i-alt"></i></a>
							</div>
							<h3>3D CAD</h3>
							<p style="text-align: justify;">SOLIDWORKS 3D design software can help you design better products faster. When you have an idea for a great product, you’ll have the tools to design it in less time, and at lower cost. </p>
						</div>
					</div>

					<div class="col_one_third">
						<div class="feature-box fbox-rounded fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="fa fa-eye i-alt"></i></a>
							</div>
							<h3>SIMULATION</h3>
							<p style="text-align: justify;">SOLIDWORKS Simulation analysis software help you to ensure whether your product — in its designing stage itself — can withstand various levels of real life pressures and forces associated with it.</p>
						</div>
					</div>

					<div class="col_one_third col_last">
						<div class="feature-box fbox-rounded fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="fa fa-flask i-alt"></i></a>
							</div>
							<h3>INSPECTION</h3>
							<p style="text-align: justify;">Intuitive and easy to use, SOLIDWORKS Inspection enables you to create inspection reports and ballooned drawings in just minutes, for time savings of up to 90 percent.</p>
						</div>
					</div>

					<div class="clear"></div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-rounded fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="fa fa-sliders i-alt"></i></a>
							</div>
							<h3>PDM</h3>
							<p style="text-align: justify;">SOLIDWORKS product data management (PDM) solutions help you get your design data under control and substantially improve the way your teams manage and collaborate on product development.</p>
						</div>
					</div>

					<div class="col_one_third nobottommargin">
						<div class="feature-box fbox-rounded fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="fa fa-tint i-alt"></i></a>
							</div>
							<h3>SOLIDWORKS MBD</h3>
							<p style="text-align: justify;">SOLIDWORKS MBD helps define, organize, and publish 3D Product Manufacturing Information (PMI) including 3D model data in industry-standard file formats.</p>
						</div>
					</div>

					<div class="col_one_third nobottommargin col_last">
						<div class="feature-box fbox-rounded fbox-effect">
							<div class="fbox-icon">
								<a href="#"><i class="fa fa-text-width i-alt"></i></a>
							</div>
							<h3>SOLIDWORKS COMPOSER</h3>
							<p style="text-align: justify;">Clearly explain and present your product or process using 2D and 3D graphical content that you can quickly create with SOLIDWORKS® Composer™ software.</p>
						</div>
					</div>

				</div>
				</div>



				


			 <div class="section topmargin-sm footer-stick ">

              <div class="heading-block center">
					<h4>Events</h4>
				</div>

				<div class="container clearfix">

					<div id="posts" class="events small-thumbs">

					<?php foreach ($events as $old_event ) { ?>

						<div class="entry clearfix" style="border-bottom: none;background-color: #ffffff;">
							<div class="entry-image" style="width: 50%;">
								<a href="#">
									<img src="<?=base_url()?>assets/admin/images/<?=$old_event->image?>" alt="Inventore voluptates velit totam ipsa tenetur">
									<div class="entry-date"><?=$old_event->event_start_date?></div>
								</a>
							</div>
							<div class="entry-c">
								<div class="entry-title">
									<h2><a href="#"><?=$old_event->event_name?></a></h2>
								</div>
								<div class="entry-content" style="margin-top: 10px;">
									<div style="height: 200px;overflow: hidden;">
										<p style=" margin: 0px;"> <?=$old_event->event_detailes?> </p>
									</div>
									
									<?php if ($old_event->status == "0") { ?>
									  <a data-toggle="modal" data-target="#eventModal" data-id="<?=$old_event->id?>" data-name="<?=$old_event->event_name?>"  class="btn btn-success reg_get">Register Now</a>
									<?php } ?> 
								   <a href="<?=base_url()?>index.php/Index/events_view/<?=$old_event->id?>" class="btn btn-primary">View More</a>
								</div>
							</div>
						</div>

						<?php } ?>


					</div>

				</div>



                  <div class="modal fade" id="eventModal" tabindex="-1" role="dialog" aria-labelledby="contactFormModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" style="color: gray;" data-dismiss="modal" aria-hidden="true">&times;</button>
										<h4 class="modal-title model_head"> Registration</h4>
									</div>
									<div class="modal-body">

										<div class="">
											
											<form class="nobottommargin" id="quot_form"  action="<?=base_url()?>index.php/Index/event_register" onsubmit="return validateMyForm_1();" method="post">

												<div class="form-process"></div>

												<div class="col_half">
													<label> Name <small>*</small></label>
													<input type="text"  name="name"  class="sm-form-control required" required  />
												</div>

												<div class="col_half col_last">
													<label >Designation </label>
													<input type="text" name="profesion" value="" class=" sm-form-control" required/>
												</div>

												<div class="clear"></div>

                                                <div class="col_half ">
													<label>Company</label><small>*</small>
													<input type="text" name="company" value="" class=" sm-form-control"  required/>
												</div>

												<div class="col_half col_last">
													<label>Email</label><small>*</small>
													<input type="email" name="email" value="" class="required sm-form-control" required />
												</div>

												<div class="clear"></div>
												<input type="hidden" name="event_id" value="" id="event_id" />
												<input type="hidden" name="event_name" value="" id="event_name" />

												<div class="col_half">
													<label>Phone </label><small>*</small>
													<input type="text" name="phone" value="" class="required sm-form-control" required />
												</div>

												<div class="col_half col_last">
													<label> No Of Attendees <small>*</small></label>
													<input type="number" name="participates" value="" class="required sm-form-control" required />
												</div>

												<div class="col_full">
												   <div class="g-recaptcha" data-sitekey="6LfeJzQUAAAAAB0p0RrF5xgR-taXUU-D7xMBl-zd"></div>
                                                </div>


												<div class="col_full">
													<center><button class="button button-3d nomargin" type="submit" value="submit">Send Message</button></center>
												</div>

											</form>

										</div>


									</div>
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->





             </div>


             <div class="container clearfix">

					<div class="clear"></div>

					<div class="heading-block center" style="margin-top: 60px;">
						<h4>Our Clients</h4>
					</div>
                    
                    <style type="text/css">
                    	.owl-stage-outer{
                    		height: 150px;
                    	}
                    </style>

					<div id="oc-clients" class="section nobgcolor notopmargin owl-carousel owl-carousel-full image-carousel footer-stick carousel-widget" data-margin="80" data-loop="true" data-nav="false" data-autoplay="5000" data-pagi="false" data-items-xxs="2" data-items-xs="3" data-items-sm="4" data-items-md="5" data-items-lg="6">
                    <?php foreach ($about_clients_logo as $logo ) { ?>

					<div class="oc-item" style="height: 100%">
					  <img src="<?=base_url()?>assets/images/clients/<?=$logo->image?>" alt="Clients" style="vertical-align: middle;">
					</div>
                    
                    <?php } ?>


				</div>

			 </div>


        

     <div class="section parallax" style="background-image: url('<?=base_url()?>assets/images/333.jpg'); padding: 50px 0;" data-stellar-background-ratio="0.3">
					<div class="heading-block center nobottomborder nobottommargin">
						<h2>"Everything is designed, but some things are designed well."</h2>
					</div>
				</div>



		</section><!-- #content end -->

<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>
<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".home").addClass("current");
	 });
</script>


<script type="text/javascript">
   function validateMyForm_1(){

       if($('input[name=name]').val() == ""){
              $('input[name=name]').addClass('red')
              return false;
        }else if($('input[name=email]').val() == ""){
              $('input[name=email]').addClass('red')
              return false;
        }else if($('input[name=phone]').val() == ""){
              $('input[name=phone]').addClass('red')
              return false;
        }else if($('input[name=participates]').val() == ""){
              $('input[name=participates]').addClass('red')
              return false;
        }else{

              return true;
      }
 }

 $('input').keyup(function(){
 	$(this).removeClass('red');
 })
</script>


  <script type="text/javascript">
 	$(document).ready(function(){
	 	$(".reg_get").click(function(){
	 		var id = $(this).attr('data-id');
	 		var name = $(this).attr('data-name');
	 		$('#event_id').val(id);
	 		$('#event_name').val(name);
            $('.model_head').html("<span style='color:#1B8FC8'>"+name +" </span> <small>Registration </small>")
	 		
	 	});
     $(".style-msg button.close").click(function(){
     	 window.location.href='<?=base_url()?>index.php/Index/index';
     });

	 	
	 });
 </script>



<script>
$(document).ready(function() {
    var showChar = 200;
    var ellipsestext = " Read More..."
    $('.more_contant').each(function() {
        var content = $(this).html();
        var text =$(this).attr('data-text');
        var name =$(this).attr('data-name');
        if(content.length > showChar) {
            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);
            var html = c + '<span class="moreellipses" data-name="'+ name +'" data-text="'+ text +'" >' + ellipsestext+ ' </span>';
            $(this).html(html);
        }
    });
  });
</script>
</body>

</html>