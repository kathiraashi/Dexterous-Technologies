<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>


  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Brochures</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Brochures</li>
				</ol>
			</div>

		</section><!-- #page-title end -->



		<!-- Content
		============================================= -->
		<section id="content">
		  <div class="content-wrap">
            <div class="container clearfix" style="margin-top: -59px;">
             
             <div class="row">
             	<?php foreach ($brochures as $brochur) { ?>
             	<div class="col-sm-4" style="margin: 10px 0px">
             	   <div class="row" style="background-color: #f1f1f1;margin: 0px 10px;">
             	   	 <div class="col-sm-12" style="background-image: url(<?=base_url()?>assets/admin/images/<?=$brochur->image?>);background-size: 100% 100%;height: 140px;">
             	   	 	<h4 style="color:#ffffff"><?=$brochur->name?></h4>
             	   	 	<a href="<?=base_url()?>assets/admin/files/<?=$brochur->pdf?>" download class="btn btn-primary btn-sm" style="position: absolute;bottom: 5px;right: 10px; font-size: 20px;"> <i class="fa fa-download" aria-hidden="true"></i></a>
             	   	 </div>
             	   </div>
             	</div>
             	<?php } ?>
             </div>

            </div>
		  </div>
		</section><!-- #content end -->

<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".resources").addClass("current");
	 });
</script>

</body>

</html>