<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">
  <title>Admin Nihas Technologies</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- fullCalendar 2.2.5-->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.min.css">
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.print.css" media="print">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/iCheck/flat/blue.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   <!-- daterange picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datepicker/datepicker3.css">
    <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.css">

  <style type="text/css">

  .add_pro a{
    background-color:#3C8DBC !important;
    color: #ffffff !important; 
    width: 80% !important;
    margin-left: 10% !important;
    height: 30px !important;
    margin-top: 5px !important;
    margin-bottom: 5px !important;
    line-height: 10px !important;
    border-radius: 5px !important;
  }
.modal {
    display: none; /* Hidden by default */
    position: absolute; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}
.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
.agenda_table thead th{
 text-align: center;
 padding: 0px 3px;
 height: 40px;
 border-bottom: 1px solid block;
}
.agenda_table tbody tr{
  padding: 0px 10px;
}
.agenda_table tbody td{
 text-align: center;
 padding: 0px 3px;
}
</style>

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php $this->load->view('admin/menus.php')  ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

 <?php if (isset($msg)){ ?>
        <div class="alert <?php echo $type; ?> alert-dismissible msg" style="position: absolute;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close msg_close"  style="position: absolute;right: 0px">&times;</button>
                <h4><i class="icon fa <?php echo $icon; ?>"></i><?php echo $msg; ?></h4>
                
        </div>
<?php } ?>


      <div class="alert alert-warning alert-dismissible erorr" style="position: fixed;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close erorr_close"  style="position: absolute;right: 0px">&times;</button>
                <h4 class="erorr_text"></h4>
                
        </div>




    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        About Us
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">About Us</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">

      
      <?php foreach ($about_us as $about) { ?>

        <div class="col-md-12">
          <div class="box box-primary form_html">
          <form id="form_1" action="<?=base_url()?>index.php/Admin/about_us_update/<?=$about->id?>" onsubmit="return validateMyForm_1();"  method="post" enctype="multipart/form-data">
            <div class="box-header with-border">
              <h3 class="box-title vid_name">About Us Detailes</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

            <div class="row">
            <div class="form-group col-sm-12">
              <label>About Nihas Technologies</label>
                 <textarea id="about" name="about" class="form-control" placeholder=" About Nihas Technologies" style="height: 130px;"><?=$about->about?></textarea>
            </div>
            </div>

            <div class="box-header with-border">
              <h3 class="box-title vid_name">Why Choose Us</h3>
            </div>
            

            <div class="row" style="margin-top: 15px;">
            <div class="form-group col-sm-12" >
              <label>Our Company's Values</label>
                 <textarea id="why_choose_1" name="why_choose_1" class="form-control" placeholder=" Our Company's Values" style="height: 130px"><?=$about->why_choose_1?></textarea>
            </div>
            </div>
            

            <div class="row">
            <div class="form-group col-sm-12">
              <label>How to get Support?</label>
                 <textarea id="why_choose_2" name="why_choose_2" class="form-control" placeholder=" How to get Support?" style="height: 130px"><?=$about->why_choose_2?></textarea>
            </div>
            </div>


            <div class="row"> 
            <div class="form-group col-sm-12">
              <label>Where can you find us?</label>
                 <textarea id="why_choose_3" name="why_choose_3" class="form-control" placeholder=" Where can you find us?" style="height: 130px"><?=$about->why_choose_3?></textarea>
            </div>
            </div>
 

            <div class="row">
            <div class="form-group col-sm-12">
              <label>Why you choose our Company?</label>
                 <textarea id="why_choose_4" name="why_choose_4" class="form-control" placeholder=" Why you choose our Company?" style="height: 130px"><?=$about->why_choose_4?></textarea>
            </div>
            </div>

            <div class="box-header with-border">
              <h3 class="box-title vid_name">Our Mission</h3>
            </div>
            
            <div class="row" style="margin-top: 15px;">
            <div class="form-group col-sm-12">
                 <textarea id="mission" name="mission" class="form-control" placeholder="Our Mission" style="height: 130px"><?=$about->mission?></textarea>
            </div>
            </div>

     
            <div class="box-header with-border">
              <h3 class="box-title vid_name">Our Vission</h3>
            </div>
            

            <div class="row" style="margin-top: 15px;">
            <div class="form-group col-sm-12">
                 <textarea id="vission" name="vission" class="form-control" placeholder="Our Vission" style="height: 130px"><?=$about->vission?></textarea>
            </div>
            </div>

            <div class="box-header with-border">
              <h3 class="box-title vid_name">Quality Policy</h3>
            </div>
            

            <div class="row" style="margin-top: 15px;">
            <div class="form-group col-sm-12">
                 <textarea id="policy" name="policy" class="form-control" placeholder="Quality Policy" style="height: 130px"><?=$about->policy?></textarea>
            </div>
            </div>









            <div class="box-header with-border">
              <h3 class="box-title vid_name">What Clients Say?</h3>
            </div>

          <div class="row"  style="margin:15px;">
            <div class="col-sm-6">
                <a class="btn-sm btn-primary" id="remove_client_say" style="cursor: pointer;"> Remove Last one </a>
            </div>

            <div class="col-sm-6 pull-right">
                <a class="btn-sm btn-primary  pull-right" id="add_client_say" style="cursor: pointer;" > Add More </a>
            </div>
          </div>
            

            <div class="client_say">
            <?php foreach ($about_client_say as $client_say) { ?>
            <div class="row" style="margin-top: 15px;">
              <div class="col-sm-4">
                <div class="form-group">
                <label>Client Name</label>
                   <input type="text" class="form-control client_name"  name="client_name[]" placeholder="Enter Name" value="<?=$client_say->name?>" >
                </div>
                <div class="form-group">
                <label>Client Company Name</label>
                   <input type="text" class="form-control company_name" name="company_name[]" placeholder="Enter Company Name" value="<?=$client_say->company?>" >
                </div>
              </div>
              <div class="col-sm-5">
                <div class="form-group">
                   <textarea name="client_say_text[]" class="form-control client_say_text" placeholder="Client Was Said" style="height: 135px"><?=$client_say->client_said?></textarea>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="form-group col-sm-6" style="padding-bottom: 30px;">
                   <div class="btn btn-default btn-file" style="position: absolute;">
                     <i class="fa fa-paperclip img_ty"></i>
                     <input type="text" name="client_image_empty[]" id="empty_oldcliimg<?=$client_say->id?>" style="display:none;" value="<?=$client_say->image?>"> 
                     <input type="file" class="client_say_img" name="client_image[]" id="oldcliimg<?=$client_say->id?>" accept="image/*" >
                   </div> 
                   <img src="<?=base_url()?>assets/images/testimonials/<?=$client_say->image?>" id="client_oldcliimg<?=$client_say->id?>" style="max-width: 100%; max-height: 100px;margin-top: 40px;">
                </div>
              </div>
            </div>
            <?php } ?>
            </div>
















            <div class="box-header with-border">
              <h3 class="box-title vid_name">Our Clients <small> (image height : 150px )</small></h3>
            </div>

          <div class="row"  style="margin:15px;">
            <div class="col-sm-6">
                <a class="btn-sm btn-primary" id="remove_client_logo" style="cursor: pointer;"> Remove Last one </a>
            </div>

            <div class="col-sm-6 pull-right">
                <a class="btn-sm btn-primary  pull-right" id="add_client_logo" style="cursor: pointer;" > Add More </a>
            </div>
          </div>
            

            <div class="client_logo row">
            <?php foreach ($about_clients_logo as $client_logo) { ?>

              <div class="col-sm-3">
               <div class="form-group col-sm-6" style="padding-bottom: 30px; height: 120px;">
                 <div class="btn btn-default btn-file" style="position: absolute;">
                   <i class="fa fa-paperclip img_ty"></i> 
                   <input type="text" name="logo_img_empty[]" id="empty-img<?=$client_logo->id?>" value="<?=$client_logo->image?>" style="display:none;">
                   <input type="file" class="client_logo_img" name="logo_img[]" id="img<?=$client_logo->id?>" accept="image/*">
                 </div> 
                 <img src="<?=base_url()?>assets/images/clients/<?=$client_logo->image?>" id="preview-img<?=$client_logo->id?>" style="max-width: 100%; max-height: 100px;margin-top: 40px;" />
               </div>
              </div>     

              <?php } ?>
            </div>

            


            <div class="box-header with-border">
              <h3 class="box-title vid_name">Our Achievements</h3>
            </div>

            <div class="row" style="margin-top: 15px;">
              <div class="col-sm-3">
                 <div class="form-group">
                   <label>No Of Client Served</label>
                    <input type="number" class="form-control" id="client_served" name="client_served" placeholder="No Of Client Served" value="<?=$about->client_served?>">
                 </div>
              </div>
              <div class="col-sm-3">
                <div class="form-group">
                   <label>No Of Projects</label>
                    <input type="number" class="form-control" id="no_of_projects" name="no_of_projects" placeholder="No Of Projects" value="<?=$about->no_of_projects?>">
                 </div>
              </div>
              <div class="col-sm-3">
                <div class="form-group">
                   <label>No Of Awards</label>
                    <input type="number" class="form-control" id="awards" name="awards" placeholder="No Of Awards" value="<?=$about->awards?>">
                 </div>
              </div>
              <div class="col-sm-3">
                <div class="form-group">
                   <label>Cups Of Coffee</label>
                    <input type="number" class="form-control" id="cup_of_coffee" name="cup_of_coffee" placeholder="Cups Of Coffee" value="<?=$about->cup_of_coffee?>">
                 </div>
              </div>
            </div>





            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <div class="pull-right">
                <button type="submit" class="btn btn-primary value"> Update </button>
              </div>
            </div>
            <!-- /.box-footer -->
            </form>
          </div>
          <!-- /. box -->


         </div>  <!-- /.col -md 12 -->

         <?php } ?>
      </div> <!-- /.row -->
    </section><!-- /.content -->
  </div> <!-- content-wrapper close-->


  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="<?=base_url()?>assets/admin/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url()?>assets/admin/bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?=base_url()?>assets/admin/plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?=base_url()?>assets/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?=base_url()?>assets/admin/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?=base_url()?>assets/admin/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?=base_url()?>assets/admin/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>assets/admin/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>assets/admin/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>assets/admin/dist/js/demo.js"></script>



<script>
  $(".erorr_close").click(function(){
      $('.erorr').hide();
  });

  $(".msg_close").click(function(){
      $('.msg').hide();
      window.location.href='<?=base_url()?>index.php/Admin/about_us';
  });

</script>


<script>
   $(document).ready(function () {
      $(".client_say input[type='file']").change(function(){
        readURL(this);
      });
      function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
              emptyId = '#empty_'+$(input).attr('id');
                imgId = '#client_'+$(input).attr('id');
                $(imgId).attr('src', e.target.result);
                $(emptyId).val('');
            }

            reader.readAsDataURL(input.files[0]);
        }
      }
     });



    $(document).ready(function () {
      $(".client_logo input[type='file']").change(function(){
        readURL(this);
      });
      function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                emptyId = '#empty-'+$(input).attr('id');
                imgId = '#preview-'+$(input).attr('id');
                $(emptyId).val('');
                $(imgId).attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
      }

    });



</script>





<script>
 $('.erorr').hide();


   function validateMyForm_1(){


       if($('#form_1').find('#about').val() == ""){
              $('.erorr').show();
              $('.erorr_text').text("Enter About Nihas Technologies");
               $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#why_choose_1').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Our Company's Values");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#why_choose_2').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter How to get Support?");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#why_choose_3').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Where can you find us?");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#why_choose_4').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Why you choose our Company?");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#mission').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Our Mission");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#vission').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Vission");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#policy').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Our Quality Policy");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#client_served').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter No Of Client Served");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#no_of_projects').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter No Of Projects");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#awards').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter No Of Awards");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#cup_of_coffee').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Cups Of Coffee");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else{
              
              var i=1; 
              var j=1;
              var k=1;
              var l=1;
              var m=1;
                  $("#form_1 .client_name").each(function() {
                      if($(this).val() == "" ) { i=0; } 
                    });
                  $("#form_1 .company_name").each(function() {
                      if($(this).val() == "" ) { j=0; } 
                    });
                  $("#form_1 .client_say_text").each(function() {
                      if($(this).val() == "" ) { k=0; } 
                    });
                  $("#form_1 .client_img_new").each(function() {
                      if($(this).val() == "" ) { l=0; } 
                    });
                  $("#form_1 .logo_img_new").each(function() {
                      if($(this).val() == "" ) { m=0; } 
                    });

                  if(i==0){ 
                         $('.erorr').show();
                         $('.erorr_text').text("Enter All Client Names In What Clients Say?");
                         $('.erorr').delay(3000).fadeOut('fast');
                         return false; 
                   }
                  if(j==0){ 
                         $('.erorr').show();
                         $('.erorr_text').text("Enter All Company Names In What Clients Say?");
                         $('.erorr').delay(3000).fadeOut('fast');
                         return false; 
                   }
                  if(k==0){ 
                         $('.erorr').show();
                         $('.erorr_text').text("Enter All Client Was Said In What Clients Say?");
                         $('.erorr').delay(3000).fadeOut('fast');
                         return false; 
                   }
                  if(l==0){ 
                         $('.erorr').show();
                         $('.erorr_text').text("Upload All Client Image In What Clients Say?");
                         $('.erorr').delay(3000).fadeOut('fast');
                         return false; 
                   }
                  if(m==0){ 
                         $('.erorr').show();
                         $('.erorr_text').text("Upload All Client Logos In Our Clients");
                         $('.erorr').delay(3000).fadeOut('fast');
                         return false; 
                   }

      }
 }
</script>

<script type="text/javascript">

    say ='<div class="row" style="margin-top: 15px;">\
              <div class="col-sm-4">\
                <div class="form-group">\
                 <label>Client Name</label>\
                   <input type="text" class="form-control client_name" name="client_name[]" placeholder="Enter Name" value="" >\
                </div>\
                <div class="form-group">\
                <label>Client Company Name</label>\
                   <input type="text" class="form-control company_name"  name="company_name[]" placeholder="Enter Company Name" value="">\
                </div>\
              </div>\
              <div class="col-sm-5">\
                <div class="form-group">\
                   <textarea name="client_say_text[]" class="form-control client_say_text" placeholder="Client Was Said" style="height: 135px"></textarea>\
                </div>\
              </div>\
              <div class="col-sm-3">\
                <div class="form-group col-sm-6" style="padding-bottom: 30px;">\
                   <div class="btn btn-default btn-file" style="position: absolute;">\
                     <i class="fa fa-paperclip img_ty"></i>\
                     <input type="text" name="client_image_empty[]" value="" style="display: none;">\
                     <input type="file" accept="image/*" class="client_img_new" name="client_image[]" id="newcliimg" value="">\
                   </div>\
                   <img src="" id="client_newcliimg" style="max-width: 100%; max-height: 100px;margin-top: 40px;">\
                </div>\
              </div>\
            </div>';
   u=1;
    $("#add_client_say").click(function(){
      u=u+1;

          say1 = say.replace('id="newcliimg"','id="newcliimg'+u+'"');
          say_new = say1.replace('id="client_newcliimg"','id="client_newcliimg'+u+'"');

           $('.client_say').append(say_new);


      $(".client_say input[type='file']").change(function(){
        readURL(this);
      });
      function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                imgId = '#client_'+$(input).attr('id');
                $(imgId).attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
      }




    });

    $("#remove_client_say").click(function(){

      if ( $('.client_say .row').length > 1 ) {
          $(".client_say .row" ).last().remove();
        }
    });
 
</script>


<script type="text/javascript">



    logo = '<div class="col-sm-3">\
                <div class="form-group col-sm-6" style="padding-bottom: 30px;">\
                   <div class="btn btn-default btn-file" style="position: absolute;">\
                     <i class="fa fa-paperclip img_ty"></i>\
                     <input type="text" name="logo_img_empty[]" value="" style="display: none;">\
                    <input type="file" accept="image/*" class="logo_img_new" name="logo_img[]" id="newimg">\
                   </div>\
                   <img src="" id="preview-newimg" style="max-width: 100%; max-height: 100px;margin-top: 40px;" />\
                </div>\
              </div>';
     i=1;
    $("#add_client_logo").click(function(){
      i=i+1;
          logo1 = logo.replace('id="newimg"','id="newimg'+i+'"');
          log_new = logo1.replace('id="preview-newimg"','id="preview-newimg'+i+'"');
           $('.client_logo').append(log_new);



      $(".client_logo input[type='file']").change(function(){
        readURL(this);
      });
      function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();

            reader.onload = function (e) {
                imgId = '#preview-'+$(input).attr('id');
                $(imgId).attr('src', e.target.result);
            }

            reader.readAsDataURL(input.files[0]);
        }
      }



    });


    $("#remove_client_logo").click(function(){
      if ( $('.client_logo .col-sm-3').length > 1 ) {
          $(".client_logo .col-sm-3" ).last().remove();
        }
    });
 
</script>




</body>
</html>
