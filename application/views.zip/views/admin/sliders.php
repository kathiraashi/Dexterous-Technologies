<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">
  <title>Admin Nihas Technologies</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- fullCalendar 2.2.5-->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.min.css">
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.print.css" media="print">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/iCheck/flat/blue.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   <!-- daterange picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datepicker/datepicker3.css">
    <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.css">

  <style type="text/css">

  .add_pro a{
    background-color:#3C8DBC !important;
    color: #ffffff !important; 
    width: 80% !important;
    margin-left: 10% !important;
    height: 30px !important;
    margin-top: 5px !important;
    margin-bottom: 5px !important;
    line-height: 10px !important;
    border-radius: 5px !important;
  }
.modal {
    display: none; /* Hidden by default */
    position: absolute; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}
.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
.agenda_table thead th{
 text-align: center;
 padding: 0px 3px;
 height: 40px;
 border-bottom: 1px solid block;
}
.agenda_table tbody tr{
  padding: 0px 10px;
}
.agenda_table tbody td{
 text-align: center;
 padding: 0px 3px;
}
</style>

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php $this->load->view('admin/menus.php')  ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

 <?php if (isset($msg)){ ?>
        <div class="alert <?php echo $type; ?> alert-dismissible msg" style="position: absolute;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close msg_close"  style="position: absolute;right: 0px">&times;</button>
                <h4><i class="icon fa <?php echo $icon; ?>"></i><?php echo $msg; ?></h4>
                
        </div>
<?php } ?>


      <div class="alert alert-warning alert-dismissible erorr" style="position: fixed;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close erorr_close"  style="position: absolute;right: 0px">&times;</button>
                <h4 class="erorr_text"></h4>
                
        </div>




    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Sliders
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Sliders</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">



        <div class="col-md-3">
          <a href="#" id="myBtn" class="btn btn-primary btn-block margin-bottom add_vid">Add  New Slider </a>

          <div class="box box-solid">
           <div class="box-header with-border">
              <h3 class="box-title">
                List Of Sliders
              </h3>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">


                <?php  foreach($sliders as $slider){ ?>
                  <li><a href="#" onclick="popup_vid_det(<?=$slider->id ?>)"><i class="fa fa-circle-o"></i> <?=$slider->title ?> </a></li>
                  <?php } ?> 

              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->






        <div class="col-md-9">
          <div class="box box-primary form_html">
          <form id="form_1" action="<?=base_url()?>index.php/Admin/sliders_submit" onsubmit="return validateMyForm_1();"  method="post" enctype="multipart/form-data">
            <div class="box-header with-border">
              <h3 class="box-title vid_name"> Add New Slider</h3>
               <a class="btn btn-primary pull-right del_vid" href=""  onclick="return confirm(' you want to delete?');" > Delete This Slider </a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

              <div class="form-group">
                <label>Slider Title</label>
                <input class="form-control" id="title" name="title" placeholder="Enter Slider Title" >
              </div>

             <div class="row">
               <div class="form-group col-sm-12">
                <label>Slider Description</label>
                      <textarea id="slider_text" name="slider_text" class="form-control" placeholder="Enter Slider Description" style="height: 170px"></textarea>
                </div> 
            </div>


            <div class="form-group" style="padding-bottom: 30px;">
                 <div class="btn btn-default btn-file" style="position: absolute;">
                   <i class="fa fa-paperclip img_ty"> &nbsp; Add Image</i> 
                   <input type="file" name="image" id="img_file" value="">
                 </div> 
                 <img src="" id="img_on" style="max-width: 100%; max-height: 300px;margin-top: 40px;">
            </div>


            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <div class="pull-right">
                <button type="submit" class="btn btn-primary value"> Submit </button>
              </div>
            </div>
            <!-- /.box-footer -->
            </form>
          </div>
          <!-- /. box -->


         </div>  <!-- /.col -md 9 -->
      </div> <!-- /.row -->
    </section><!-- /.content -->
  </div> <!-- content-wrapper close-->


  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="<?=base_url()?>assets/admin/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url()?>assets/admin/bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?=base_url()?>assets/admin/plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?=base_url()?>assets/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?=base_url()?>assets/admin/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?=base_url()?>assets/admin/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?=base_url()?>assets/admin/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>assets/admin/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>assets/admin/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>assets/admin/dist/js/demo.js"></script>



<script>
  $(".erorr_close").click(function(){
      $('.erorr').hide();
  });

  $(".msg_close").click(function(){
      $('.msg').hide();
      window.location.href='<?=base_url()?>index.php/Admin/sliders';
  });


  $("#img_file").change(function(){
      readURL(this);
      $("#img_on").show();
  });

    function readURL(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $('#img_on').attr('src', e.target.result);
            }
          reader.readAsDataURL(input.files[0]);
         }
      }

</script>



<script>
 $(".add_vid").hide();
 $(".del_vid").hide();
 $("#img_on").hide();
function popup_vid_det(id){
   var delete_url= "<?=base_url()?>index.php/Admin/delete_sliders/";
    var formurl= "<?=base_url()?>index.php/Admin/sliders_update/";
    var img_url = "<?=base_url()?>assets/admin/images/"
       formURL = formurl+id;
       delete_URL = delete_url+id;
       $( "#form_1").attr('action',formURL);
       $(".add_vid").show();
       $( ".del_vid").attr('href',delete_URL);
       $( ".del_vid").show();
       $("#img_on").show();
       $(".value").text('Update');

     $.ajax({
          url: "<?=base_url()?>index.php/Admin/sliders_get",
          type:"POST",
          data: {id:id},
          success: function(html){
             var result = $.parseJSON(html);
            $("#title").val(result['data'][0]['title']);
            $(".vid_name").text(result['data'][0]['title']+" Detailes");
            $("#slider_text").text(result['data'][0]['text']);
            $(".img_ty").text('Update Image');
            var img_name = result['data'][0]['image'];
            var img_on = img_url+img_name;
            $("#img_on").attr("src", img_on );

          }  
    });





    }


    form_html = $(".form_html").html();
    $(".add_vid").click(function(){
         $('.form_html').html(form_html);

         $("#img_file").change(function(){
      readURL(this);
      $("#img_on").show();
  });

    function readURL(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $('#img_on').attr('src', e.target.result);
            }
          reader.readAsDataURL(input.files[0]);
         }
      }
      
    });

</script>

<script>
 $('.erorr').hide();


   function validateMyForm_1(){


      if($('#form_1').find('input[type=file]').val() == "") { 
               if ($('#form_1').attr('action')=='<?=base_url()?>index.php/Admin/sliders_submit') {
                  $('.erorr').show();
                  $('.erorr_text').text("Add Slider Image");
                  $('.erorr').delay(3000).fadeOut('fast');
                  return false;
                }
       }else{
              return true;
      }
 }
</script>

</body>
</html>
