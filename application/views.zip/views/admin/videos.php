<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">
  <title>Admin Nihas Technologies</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- fullCalendar 2.2.5-->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.min.css">
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.print.css" media="print">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/iCheck/flat/blue.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   <!-- daterange picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datepicker/datepicker3.css">
    <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.css">

  <style type="text/css">

  .add_pro a{
    background-color:#3C8DBC !important;
    color: #ffffff !important; 
    width: 80% !important;
    margin-left: 10% !important;
    height: 30px !important;
    margin-top: 5px !important;
    margin-bottom: 5px !important;
    line-height: 10px !important;
    border-radius: 5px !important;
  }
.modal {
    display: none; /* Hidden by default */
    position: absolute; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}
.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
.agenda_table thead th{
 text-align: center;
 padding: 0px 3px;
 height: 40px;
 border-bottom: 1px solid block;
}
.agenda_table tbody tr{
  padding: 0px 10px;
}
.agenda_table tbody td{
 text-align: center;
 padding: 0px 3px;
}
</style>

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php $this->load->view('admin/menus.php')  ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

 <?php if (isset($msg)){ ?>
        <div class="alert <?php echo $type; ?> alert-dismissible msg" style="position: absolute;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close msg_close"  style="position: absolute;right: 0px">&times;</button>
                <h4><i class="icon fa <?php echo $icon; ?>"></i><?php echo $msg; ?></h4>
                
        </div>
<?php } ?>


      <div class="alert alert-warning alert-dismissible erorr" style="position: fixed;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close erorr_close"  style="position: absolute;right: 0px">&times;</button>
                <h4 class="erorr_text"></h4>
                
        </div>




    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Videos
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Videos</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">



        <div class="col-md-3">
          <a href="#" id="myBtn" class="btn btn-primary btn-block margin-bottom add_vid">Add  New Videos</a>

          <div class="box box-solid">
           <div class="box-header with-border">
              <h3 class="box-title">
                List Of Videos
              </h3>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">


                <?php  foreach($videos as $videos){ ?>
                  <li><a href="#" onclick="popup_vid_det(<?=$videos->id ?>)"><i class="fa fa-circle-o"></i> <?=$videos->topic ?> </a></li>
                  <?php } ?> 

              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->






        <div class="col-md-9">
          <div class="box box-primary form_html">
          <form id="form_1" action="<?=base_url()?>index.php/Admin/videos_submit" onsubmit="return validateMyForm_1();"  method="post" enctype="multipart/form-data">
            <div class="box-header with-border">
              <h3 class="box-title vid_name"> Add New Videos</h3>
               <a class="btn btn-primary pull-right del_vid" href=""  onclick="return confirm(' you want to delete?');" > Delete This Video </a>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

              <div class="form-group">
                <input class="form-control" id="video_topic" name="video_topic" placeholder="Enter Video Topic Name" >
              </div>

             <div class="row">
               <div class="form-group col-sm-12">
                      <textarea id="video_description" name="video_description" class="form-control" placeholder="Enter Video Details" style="height: 170px"></textarea>
                </div> 
            </div>


            <div class="form-group">
                <input class="form-control" id="video_link" name="video_link" placeholder="Enter Video Link" >
            </div>
             

                  
                 <center style="max-width: 700px;">
                      <iframe width="100%"  height="300" id="iframe" src="" frameborder="0" allowfullscreen></iframe>
                 </center>


            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <div class="pull-right">
                <button type="submit" class="btn btn-primary value"> Submit </button>
              </div>
            </div>
            <!-- /.box-footer -->
            </form>
          </div>
          <!-- /. box -->


         </div>  <!-- /.col -md 9 -->
      </div> <!-- /.row -->
    </section><!-- /.content -->
  </div> <!-- content-wrapper close-->


  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="<?=base_url()?>assets/admin/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url()?>assets/admin/bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?=base_url()?>assets/admin/plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?=base_url()?>assets/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?=base_url()?>assets/admin/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?=base_url()?>assets/admin/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?=base_url()?>assets/admin/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>assets/admin/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>assets/admin/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>assets/admin/dist/js/demo.js"></script>



<script>
  $(".erorr_close").click(function(){
      $('.erorr').hide();
  });

  $(".msg_close").click(function(){
      $('.msg').hide();
      window.location.href='<?=base_url()?>index.php/Admin/videos';
  });

</script>


<script>
  $('#video_link').change(function(){
      var link = $(this).val();
      link = link.replace("www.youtube.com/watch?v=", "www.youtube.com/embed/");
      $("#iframe").attr('src',link);

  });

</script>


<script>
 $(".add_vid").hide();
 $(".del_vid").hide();
function popup_vid_det(id){
   var delete_url= "<?=base_url()?>index.php/Admin/delete_videos/";
    var formurl= "<?=base_url()?>index.php/Admin/video_update/";
       formURL = formurl+id;
       delete_URL = delete_url+id;
       $( "#form_1").attr('action',formURL);
       $(".add_vid").show();
       $( ".del_vid").attr('href',delete_URL);
       $( ".del_vid").show();
       $(".value").text('Update');

     $.ajax({
          url: "<?=base_url()?>index.php/Admin/videos_get",
          type:"POST",
          data: {id:id},
          success: function(html){
             var result = $.parseJSON(html);
            $("#video_topic").val(result['data'][0]['topic']);
            $(".vid_name").text(result['data'][0]['topic']+" Detailes");
            $("#video_description").text(result['data'][0]['description']);
            $("#video_link").val(result['data'][0]['link']);

            var value = result['data'][0]['link'];
            value = value.replace("www.youtube.com/watch?v=", "www.youtube.com/embed/");
            $("#iframe").attr('src',value);

          }  
    });





    }


    form_html = $(".form_html").html();
    $(".add_vid").click(function(){
         $('.form_html').html(form_html);
    });

</script>

<script>
 $('.erorr').hide();


   function validateMyForm_1(){


       if($('#form_1').find('#video_topic').val() == ""){
              $('.erorr').show();
              $('.erorr_text').text("Enter Video Topic");
               $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#video_link').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Video Link");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else{
              return true;
      }
 }
</script>

</body>
</html>
