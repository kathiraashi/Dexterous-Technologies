  <header class="main-header">

    <!-- Logo -->
    <a href="<?=base_url()?>index.php/Admin" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini">A <b> N</b></span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg">Admin <b> Nihas</b></span>
    </a>

    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">

          <li class="dropdown user user-menu">
            <a href="<?=base_url()?>index.php/Admin/logout">
              <span class="hidden-xs">Sign Out</span>
            </a>
          </li>
        </ul>
      </div>

    </nav>
  </header>









      <!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu">


        <li class="treeview">
          <a href="#">
            <i class="fa fa-tags"></i> <span>PRODUCTS</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
             <li><a href="<?=base_url()?>index.php/Admin/product_types"><i class="fa fa-circle-o " style="color: lightgreen"></i> <span>PRODUCT TYPE</span></a></li>
            <li class="treeview">
              <a href="#"><i class="fa fa-circle-o"></i> PRODUCT LIST
                <span class="pull-right-container">
                  <i class="fa fa-angle-left pull-right"></i>
                </span>
              </a>
              <ul class="treeview-menu">
                <?php  $this->db->select("*")->from('product_type');  $pro_query = $this->db->get();
                   $product_types =$pro_query->result(); foreach($product_types as $product_type){ ?>
                  <li><a href="<?=base_url()?>index.php/Admin/products/<?=$product_type->id?>"><i class="fa fa-circle-o "></i> <?=$product_type->name ?> </a>
                 </li>
                <?php } ?>
             </ul>
            </li>
            <li><a href="<?=base_url()?>index.php/Admin/product_request"><i class="fa fa-circle-o " style="color: yellow"></i> <span>PRODUCT REQUESTS</span></a></li>
          </ul>
        </li>


        <li class="treeview">
          <a href="#">
            <i class="fa fa-pie-chart"></i><span> RESOURCES </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url()?>index.php/Admin/white_papers"><i class="fa fa-circle-o " style="color: pink"></i> <span>WHITE PAPERS</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/case_studies"><i class="fa fa-circle-o " style="color: pink"></i> <span>CASE STUDIES</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/videos"><i class="fa fa-circle-o text-red"></i> <span>VIDEOS</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/brochures"><i class="fa fa-circle-o " style="color: white"></i> <span>BROCHURES</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/draft_sight"><i class="fa fa-circle-o " style="color: green"></i> <span>DRAFT SIGHT</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/edrawing"><i class="fa fa-circle-o " style="color: orange"></i> <span>eDRAWING</span></a></li>
          </ul>
        </li>






        <li class="treeview">
          <a href="#">
            <i class="fa fa-calendar"></i><span> EVENTS </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url()?>index.php/Admin/events"><i class="fa fa-circle-o text-aqua"></i> <span>ALL EVENTS</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/event_registers"><i class="fa fa-circle-o " style="color: red"></i> <span>EVENT REGISTERS</span></a></li>
          </ul>
        </li>







        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i><span> CAREER </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url()?>index.php/Admin/career"><i class="fa fa-circle-o" style="color: #09d261"></i> <span>CAREER</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/job_applications"><i class="fa fa-circle-o" style="color:white"></i> <span>JOB APPLICATIONS</span></a></li>
          </ul>
        </li>


        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i><span> EMAIL </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url()?>index.php/Admin/mail_details"><i class="fa fa-circle-o"  style="color:orange"></i> <span> LIST OF EMAILS </span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/email_templates"><i class="fa fa-circle-o"  style="color:orange"></i> <span> EMAIL TEMPLATES</span></a></li>
          </ul>
        </li>




        <li class="treeview">
          <a href="#">
            <i class="fa fa-envelope"></i><span>CUSTOMER SUPPORT <br> & SERVICES </span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?=base_url()?>index.php/Admin/customer_supports"><i class="fa fa-circle-o"  style="color:orange"></i> <span> CUSTOMER SUPPORT</span></a></li>
            <li><a href="<?=base_url()?>index.php/Admin/services"><i class="fa fa-circle-o"  style="color:red"></i> <span> SERVICES </span></a></li>
          </ul>
        </li>




        <li><a href="<?=base_url()?>index.php/Admin/industries"><i class="fa fa-circle-o " style="color: lightgreen"></i> <span>INDUSTRIES</span></a></li>
        

        <li><a href="<?=base_url()?>index.php/Admin/contact"><i class="fa fa-circle-o"  style="color:green"></i> <span>CONTACT</span></a></li>


        <li><a href="<?=base_url()?>index.php/Admin/about_us"><i class="fa fa-circle-o"  style="color:pink"></i> <span>ABOUT US</span></a></li>


        <li><a href="<?=base_url()?>index.php/Admin/sliders"><i class="fa fa-circle-o"  style="color:pink"></i> <span>SLIDER</span></a></li>

        

        


      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>