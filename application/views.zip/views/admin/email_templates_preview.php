<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">
  <title>Admin Nihas Technologies</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

</head>

<body >

    <?php  foreach($email_templates as $email_template){ ?>
   <div style="background-color: #ECF0F5">
   <table width="550" border="0" align="center" cellpadding="0" cellspacing="0" style="background-color: #ffffff">
     <tbody>
       <tr>
        <td align="center" valign="top" style="border-top:1px solid #656565;border-bottom:1px solid #656565;border-left:1px solid #656565;border-right:1px solid #656565">
         <table width="550" border="0" align="center" cellpadding="0" cellspacing="0">
           <tbody>
            <tr>
              <td align="" valign="top" style="padding-top:25px">
                <table width="200" border="0" align="" cellpadding="0" cellspacing="0">
                  <tbody>
                    <tr>
                     <td align="center" valign="top">
                       <img src="http://nihastechnologies.com/assets/images/logo.jpg" style="display:block;width: 100px;" border="0">
                     </td>
                    </tr>
                  </tbody>
                </table>
              </td>
            </tr>
            <tr>
             <td align="center" valign="top" style="padding-top:15px;padding-left:25px;padding-right:25px">
               <table width="400" border="0" align="center" cellpadding="0" cellspacing="0">
                <tbody>
                  <tr>
                    <td align="center" valign="top" style="font-family:Calibri;font-size:18px;line-height:30px;color:#323232;text-align:center;font-style:italic"><?=$email_template->title ?></td>
                  </tr>
                  <tr>
                    <td align="center" valign="top" style="font-family:Calibri;">
                      <?=$email_template->message ?>
                    </td>
                   </tr>
        
          
          </tbody></table></td>
      </tr>
      
      <tr>
        <td align="center" valign="top" style="padding-top:25px"><table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
          <tbody><tr>
            <td align="center" valign="top" style="font-family:Calibri;font-size:11px;color:#323232;text-align:left"><img src="https://ci3.googleusercontent.com/proxy/NzfY_X35zvMXCTAglV1_qeCP5LvK_ORQI7ezs1OEfEavC_QqLXNc2gXi1NY7ZE5iEClsc1XCDe529OzhOQOzaIs5YEFrQ5EuScoJWRWuWyoQdz3FBySkx2f4oZAhEXEy=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/masthead.jpg" class="m_1012140956702391395responsive-image CToWUd" style="display:block" border="0"></td>
          </tr>
        </tbody></table></td>
      </tr>
      <tr>
        <td align="center" valign="top" style="padding-left:60px;padding-right:60px;padding-top:15px"><table width="145" border="0" align="center" cellpadding="0" cellspacing="0" class="m_1012140956702391395customwidth">
          <tbody><tr>
            <td align="left" valign="middle"><a href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=7&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D7%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNGzYokjI_ipEpKB_FKKj-FJnDL26g"><img src="https://ci6.googleusercontent.com/proxy/YY2XXsmFoaucvuXG3Jt0koM5_MiCCID7SEYcMi4Hv8gsjyU1I2gBj5mBEEHp9E-wXLkdZnww5ZYog4vGnCr_N9acC7IWluCNNocrJOzcwgzH5EGHTg_AqqN8_eUjYKXk=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/facebook.png" width="24" height="23" border="0" class="CToWUd"></a></td>
            <td align="left" valign="middle"><a href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=8&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D8%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNEZUJUkmw7yR2JzZznuGAoookrShw"><img src="https://ci4.googleusercontent.com/proxy/x8-KqMUumZx2NuA1T7L4ZlG1ZoNvgVPkdnJqjGbuPBqSr3p780txLJWnaBwJs3oFak4Zy2I6zbXfXQ0lBhk8ZEVNidSnPwe9mSnSA4pPKKlHukQe1XNtt6-8kn1NFwQ=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/twitter.png" width="24" height="24" border="0" class="CToWUd"></a></td>
            <td align="left" valign="middle"><a href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=9&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D9%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNFx0aN_R5sRn3CSB9AJ1hxqxXp85w"><img src="https://ci5.googleusercontent.com/proxy/yzfBf3085de7oUM3kbNQVo43JClprDi8e3tOnA_iU4Z21mrRHrGghbKfX3pVZdfjiulUqSosTON-taJqAauJy8qkSLYRR2JbkwCfqmsEmXIY8h9LOBvbT3-1aiNxbe4D=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/linkedin.png" width="24" height="24" border="0" class="CToWUd"></a></td>
            <td align="left" valign="middle"><a href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=10&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D10%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNH079cUTaAdFWWI7SjAmmUCjtKNSw"><img src="https://ci5.googleusercontent.com/proxy/Ao7J3bfH-ZyBCWr8WvNqUKu7dJQhVmA7UsJJveii2kx2WYWFco7V1zNnMvX12FZqedH_YY4DM0odaV2Vusr1e8dQfKUDh-5TSyTJS6987AW34CmdG5lfyb84a_lPOMg=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/youtube.png" width="24" height="24" border="0" class="CToWUd"></a></td>
            <td align="left" valign="middle"><a href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=11&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D11%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNEmrTIQOCrk0qkKOajs9UP2aL6ROg"><img src="https://ci5.googleusercontent.com/proxy/iLeK3EmtZT7ajycuf5rIhZT9XAd5FbytFQnxzZSSeY0YvXc2no4wRAW3bzrSu-Imp3txjkfIHOfNZW42kZIvM1CCOBzrBX37F91FVBwtAbZiDgyIz0uejPwa8CAkXOdx3g=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/instagram.png" width="24" height="24" border="0" class="CToWUd"></a></td>
          </tr>
          </tbody></table></td>
      </tr>
      <tr>
        <td align="center" valign="top" style="padding-left:25px;padding-right:25px;padding-top:4px"><table width="210" border="0" align="center" cellpadding="0" cellspacing="0" class="m_1012140956702391395customwidth"> 
          <tbody><tr>
            <td width="106" align="left" valign="middle" style="border-right:1px solid #656565"><a href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=12&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D12%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNGjS97Fp7OvcT9IRRO4syDDlbrTew"><img src="https://ci3.googleusercontent.com/proxy/sQoh6NhricjBGT7kTn223pj0FkgU714QFOeAjbG5it0efe5C_j7jhm9kqInb0JVSgkcCjNRQPQ_Nhn0a3Tcse20ke22BwYMc1JxYvyE66KzcmGGil5XYLUckhhmrdRcP=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/besecure.png" alt="Be Secure Online" width="99" height="12" border="0" class="CToWUd"></a></td>
            <td width="104" align="right" valign="middle" style="font-family:Calibri;font-size:12px;color:#323232"><a href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=13&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D13%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNHdaxrypN_0pGZG-MRMsmD6LmFIUw"><img src="https://ci6.googleusercontent.com/proxy/ohKuU9JEwQp7kUkLu-gH2sKfht-xf-_iMVy9CLNN9v3COdKUYy7aTzVLRSYisQbEEtBOGh-nnwEXBgatIwoZR7nlvmoiPrP2cPYuNJtBxkYoK65fXCqd9dBQN1E=s0-d-e1-ft#http://campaign.axisbank.com/2017/Sept/Aadhaar_Seeding_Mailer/axis.png" width="99" height="12" border="0" class="CToWUd"></a></td>
          </tr>
        </tbody></table></td>
      </tr>
      <tr>
        <td align="left" valign="top" style="padding-left:5px;padding-right:5px;padding-top:15px;padding-bottom:10px"><table width="500" border="0" align="center" cellpadding="0" cellspacing="0">
          <tbody><tr>
            <td align="center" valign="top" style="font-family:Calibri;font-size:11px;color:#323232;padding-bottom:8px"><em>This e-mail is confidential. It may also be legally privileged. If you are not the addressee, you may not copy, forward, disclose 
              or use any part of it. Internet communications cannot be guaranteed to be timely, secure, error or virus-free. The sender 
              does not accept liability for any errors or omissions. We maintain strict security standards and procedures to prevent unauthorised access to information about you. <a style="font-family:Calibri;font-size:11px;color:#323232;text-decoration:underline" href="http://content.axisbank.in/emessageIRS/servlet/IRSL?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=14&amp;e=2&amp;x=2458115.0" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSL?v%3D5%26a%3D10411%26r%3D206035%26m%3D2400500%26l%3D14%26e%3D2%26x%3D2458115.0&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNFgO76_Lu7E9oqGqlodneqzMY-8fw"><strong>Know more &gt;&gt;</strong></a></em></td>
          </tr>
          <tr>
            <td align="center" valign="top" style="font-family:Calibri;font-size:11px;color:#323232;padding-bottom:8px"><em>Copyright Axis Bank Ltd. All rights reserved. Terms &amp; Conditions apply.</em></td>
          </tr>
          <tr>
            <td align="center" valign="top" style="font-family:Calibri;font-size:11px;color:#323232;padding-bottom:8px"><em>Please do  not share Internet Banking details, such as, user ID/password or your Credit/Debit Card number/CVV/OTP with anyone, either over the phone or through email.</em></td>
          </tr>
        </tbody></table></td>
      </tr>
    </tbody></table></td>
  </tr>
</tbody></table>
<table align="center">
<tbody>
<tr>
<td>
<p style="font-family:Arial,Helvetica,sans-serif;font-size:13px;color:#656565;line-height:50px"><em>If you do not wish to receive such emails in future, please
<a id="m_1012140956702391395ClickHere" value="Unsubscribe" class="m_1012140956702391395droppable" href="http://content.axisbank.in/emessageIRS/servlet/IRSLP?e=t83C54D524163B71214A08CB315736A734BC30A98946AC0BCC9ACE56B9D5C9CCD6DAECC42B7FF02A20BDA922D11424D4287128EE9C1288D987430F804C2FB522ED6FB32D81413EFA7EE16934BD04D1C24D4D92876CCC82BBEDD001FC266F94E92471891289E839790841218DFBAA3511FC348DE6D7503F6C80F22BAD79E01C2EE" target="_blank" data-saferedirecturl="https://www.google.com/url?hl=en&amp;q=http://content.axisbank.in/emessageIRS/servlet/IRSLP?e%3Dt83C54D524163B71214A08CB315736A734BC30A98946AC0BCC9ACE56B9D5C9CCD6DAECC42B7FF02A20BDA922D11424D4287128EE9C1288D987430F804C2FB522ED6FB32D81413EFA7EE16934BD04D1C24D4D92876CCC82BBEDD001FC266F94E92471891289E839790841218DFBAA3511FC348DE6D7503F6C80F22BAD79E01C2EE&amp;source=gmail&amp;ust=1507388743332000&amp;usg=AFQjCNEN89q4KhUyUv_bXO1D2k1k-xdWMw"><span id="m_1012140956702391395ClickHere" style="display:inline-block" value="Unsubscribe" class="m_1012140956702391395droppable">unsubscribe here</span></a></em></p>
</td>
</tr>
</tbody><tbody>
</tbody></table>

<img width="1" height="1" src="https://ci4.googleusercontent.com/proxy/sh1MVgKxXlU60SmcA0dfBFVtaxKz54Brloql2io1TMUBpasz33b6uI4ysSopUSelDQ66jU3-_01w4v_oufvkU_51h713GBnYgGcnrc-aGvswxjZhIwlX13LinwoCiIXnQ0I0DgyJF-HO58mlqmNmLDY=s0-d-e1-ft#http://content.axisbank.in/emessageIRS/servlet/IRSO?v=5&amp;a=10411&amp;r=206035&amp;m=2400500&amp;l=-1&amp;e=2" class="CToWUd">

<img width="1" height="1" src="https://ci6.googleusercontent.com/proxy/VE_pSZCXOdqBGCzShYeNQ9-bASC5EIO0syatdM9B8LxGgMnPbKHAts2chuqgcyA7exvTwSOMgywHeY_uz0MIMREPZZ9xwj6VcVRCUVpsXenOJXeowNXyyjJGtsyRrRs=s0-d-e1-ft#http://miq-p4-qa-em.unicaondemand.com/C250R708A.gif?pvci=1776_3653_206035" class="CToWUd"></div>

   <?php } ?>

</body>
</html>
