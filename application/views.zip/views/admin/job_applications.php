<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">
  <title>Admin Nihas Technologies</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- fullCalendar 2.2.5-->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.min.css">
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.print.css" media="print">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/iCheck/flat/blue.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   <!-- daterange picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datepicker/datepicker3.css">
    <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.css">
    <!-- DataTables -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datatables/dataTables.bootstrap.css">

  <style type="text/css">

.modal {
    display: none; /* Hidden by default */
    position: absolute; /* Stay in place */
    z-index: 1000; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    right: 0;
    top: 0;
    max-width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    max-width:500px;
    font-size: 18px;
}
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}
.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
  
</style>

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php $this->load->view('admin/menus.php')  ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

 <?php if (isset($msg)){ ?>
        <div class="alert <?php echo $type; ?> alert-dismissible msg" style="position: absolute;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close msg_close"  style="position: absolute;right: 0px">&times;</button>
                <h4><i class="icon fa <?php echo $icon; ?>"></i><?php echo $msg; ?></h4>
                
        </div>
<?php } ?>




    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Job Application
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Job Application</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">


        <div class="col-md-12">
          <div class="box box-primary form_html">
            <div class="box-header">
              <h3 class="box-title">Job Application List</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th style="width:10px">S.no</th>
                  <th>Name</th>
                  <th>Gender & Age</th>
                  <th>Email & Phone</th>
                  <th>Job Position</th>
                  <th>Experience</th>
                  <th style="width: 180px">Commends</th>
                  <th>Resume</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($jobs as $job) { ?>
                <tr>
                  <td></td>
                  <td><?=$job->fname?> <?=$job->lname?></td>
                  <td><small>Gender : </small><?=$job->gender?> <br>
                      <small>Age : </small> <?=$job->age?></td>
                  <td><small>email : </small><?=$job->email?> <br>
                      <small>Phone : </small> <?=$job->phone?></td>
                  <td><?=$job->position?></td>
                  <td><?=$job->experience?></td>
                  <td class="more_contant" data-text="<?=$job->commend?>" data-name="<?=$job->fname?> <?=$job->lname?>"> <?=$job->commend?> </td>
                  <td><a href="<?=base_url()?>assets/admin/resume/<?=$job->resume?>" target="blanck"><?=$job->resume?></a></td>
                </tr>
               <?php  } ?>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /. box -->




        
         </div>  <!-- /.col -md 12 -->
      </div> <!-- /.row -->
    </section><!-- /.content -->

            <!-- Model Popup Start -->
          <div id="myModal" class="modal">
            <div class="modal-content">
             <span class="close">&times;</span>
                 <h3 style="margin-left: 10px" id="Popup_heading"> </h3><hr style="margin: 0px">
                    <div   style="margin: 20px;"> 
                      <div class="box-body">
                        <div class="row">
                            <div class="col-md-12" id="popup_commends">
                              
                            </div> 
                       </div>
                     </div>
                  </div>
              </div>
           </div><!-- Model Popup End -->

  </div> <!-- content-wrapper close-->


  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="<?=base_url()?>assets/admin/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url()?>assets/admin/bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?=base_url()?>assets/admin/plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?=base_url()?>assets/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?=base_url()?>assets/admin/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?=base_url()?>assets/admin/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- DataTables -->
<script src="<?=base_url()?>assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?=base_url()?>assets/admin/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>assets/admin/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>assets/admin/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>assets/admin/dist/js/demo.js"></script>

<script>
$(document).ready(function() {
    var t = $('#example1').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );
</script>


<script>

</script>



<script>
$(document).ready(function() {
    var showChar = 50;
    var ellipsestext = " Read More..."
    $('.more_contant').each(function() {
        var content = $(this).html();
        var text =$(this).attr('data-text');
        var name =$(this).attr('data-name');
        if(content.length > showChar) {
            var c = content.substr(0, showChar);
            var h = content.substr(showChar, content.length - showChar);
            var html = c + '<span class="moreellipses"><a href="#myModal" id="show_popup" data-name="'+ name +'" data-text="'+ text +'" >' + ellipsestext+ ' </a></span>';
            $(this).html(html);
        }
    });

    var modal = document.getElementById('myModal');
    var btn = document.getElementById("show_popup");
    var span = document.getElementsByClassName("close")[0];
    btn.onclick = function() {
       var text =$(this).attr('data-text');
       var name =$(this).attr('data-name');
       $('#popup_commends').html(text);
       $('#Popup_heading').html(name+" Commends");
        modal.style.display = "block";
    }
    span.onclick = function() {
        modal.style.display = "none";
    }
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }

});


</script>


</body>
</html>
