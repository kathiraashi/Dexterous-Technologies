<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">
  <title>Admin Nihas Technologies</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- fullCalendar 2.2.5-->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.min.css">
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.print.css" media="print">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/iCheck/flat/blue.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
     <!-- Select2 -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/select2/select2.min.css">
   <!-- daterange picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datepicker/datepicker3.css">
    <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.css">
    <!-- DataTables -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datatables/dataTables.bootstrap.css">

  <style type="text/css">

.modal {
    display: none; /* Hidden by default */
    position: absolute; /* Stay in place */
    z-index: 1000; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    right: 0;
    top: 0;
    max-width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    max-width:500px;
    font-size: 18px;
}
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}
.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
.alert{
  padding: 8px 15px;
}
.alert h4{
  margin: 0px;
  padding-right: 20px;
}
  
</style>

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php $this->load->view('admin/menus.php')  ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

 <?php if (isset($msg)){ ?>
        <div class="alert <?php echo $type; ?> alert-dismissible msg" style="position: absolute;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close msg_close" style="position: absolute;right: 0px">&times;</button>
                <h4><i class="icon fa <?php echo $icon; ?>"></i><?php echo $msg; ?></h4>
                
        </div>
<?php } ?>


      <div class="alert alert-warning alert-dismissible erorr" style="position: fixed;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close erorr_close"  style="position: absolute;right: 0px">&times;</button>
                <h4 class="erorr_text"></h4>
                
        </div>






    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Product Types 
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"> Product Types  </li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">


        <div class="col-md-12">
          <div class="box box-primary form_html">
            <div class="box-header row">
              <h3 class="box- col-sm-6" style=" margin: 0px">Product Type List</h3>
              <h3 class="box-title col-sm-6">
                  <a href="#myModal" onclick="category_add()" class="btn btn-primary pull-right ">add New Product Type</a>
              </h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table id="example1" class="table table-bordered table-striped">
                <thead>
                <tr>
                  <th style="width:10px">S.no</th>
                  <th>Name</th>
                  <th>Category</th>
                  <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($product_types as $category) { ?>
                <tr>
                  <td></td>
                  <td><?=$category->name?></td>
                  <td><?=$category->category?></td>
                  <td>
                    <a href="#myModal" onclick="category_update(<?=$category->id?>)"  class="btn-sm btn-primary"  style="padding: 12px 10px 5px 10px;">
                      <i class="fa fa-edit" style="font-size: 22px;"></i>
                    </a>
                    &emsp;
                    <a href="<?=base_url()?>index.php/Admin/delete_pro_category/<?=$category->id?>"  onclick="return confirm(' you want to delete?');"  class="btn-sm btn-primary"  style="padding: 12px 10px 5px 10px;">
                      <i class="fa fa-trash-o" style="font-size: 22px;"></i>
                    </a>
                  </td>
                </tr>
               <?php  } ?>
                </tbody>
              </table>
            </div>
          </div>
          <!-- /. box -->




        
         </div>  <!-- /.col -md 12 -->
      </div> <!-- /.row -->
    </section><!-- /.content -->

            <!-- Model Popup Start -->
          <div id="myModal" class="modal">
          <form id="form_1" action="<?=base_url()?>index.php/Admin/add_product_types" onsubmit="return validateMyForm_1();"  method="post" enctype="multipart/form-data">
            <div class="modal-content" style="padding: 0px;">
              <div class="modal-header">
                  <span class="my_close close">&times;</span>
                <h4 class="modal-title title_cat"> Add New Product Type</h4>
              </div>
              <div class="modal-body">
                 <div class="form-group">
                  <label style="font-size: 15px;">Type Name </label>
                  <input class="form-control" id="name" name="name" placeholder="Enter Product Types Name" >
                </div>
                <style type="text/css">
                  .select2-container--default .select2-selection--single{
                    height: 40px;
                  }
                  .select2-container--default .select2-selection--single .select2-selection__rendered{
                    line-height: 32px;
                  }
                  .select2-container--default .select2-selection--single .select2-selection__arrow{
                    height: 40px;
                  }
                </style>
                <div class="form-group">
                  <label style="font-size: 15px;">Category Type </label>
                  <select class="form-control select2" name="category" style="width: 100%; height: 40px !important;">
                    <option value="1" id="category_id_1">Lab Equipments</option>
                    <option value="2" id="category_id_2">Software Solutions</option>
                  </select>
                </div>

              </div>
              <div class="modal-footer">
                <button type="submit" class="btn btn-primary value">Submit</button>
              </div>
            </div>
            </form>
           </div><!-- Model Popup End -->

  </div> <!-- content-wrapper close-->


  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="<?=base_url()?>assets/admin/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url()?>assets/admin/bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?=base_url()?>assets/admin/plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?=base_url()?>assets/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?=base_url()?>assets/admin/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?=base_url()?>assets/admin/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- DataTables -->
<script src="<?=base_url()?>assets/admin/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/datatables/dataTables.bootstrap.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?=base_url()?>assets/admin/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>assets/admin/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>assets/admin/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>assets/admin/dist/js/demo.js"></script>

<script>
$(document).ready(function() {
    var t = $('#example1').DataTable( {
        "columnDefs": [ {
            "searchable": false,
            "orderable": false,
            "targets": 0
        } ],
        "order": [[ 1, 'asc' ]]
    } );
 
    t.on( 'order.dt search.dt', function () {
        t.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
            cell.innerHTML = i+1;
        } );
    } ).draw();
} );
</script>


<script>

  $(".erorr_close").click(function(){
      $('.erorr').hide();
  });

  $(".msg_close").click(function(){
      $('.msg').hide();
      window.location.href='<?=base_url()?>index.php/Admin/product_types';
  });




$('.erorr').hide();
   function validateMyForm_1(){

       if($('#form_1').find('#name').val() == ""){
              $('.erorr').show();
              $('.erorr_text').text("Enter Product Type Name");
               $('.erorr').delay(3000).fadeOut('fast');
              return false;
         }else{
              return true;
         }
   }

</script>

<script>
  $(function () {
     $(".select2").select2();
  });
</script>


<script>

    var modal = document.getElementById('myModal');
    var btn = document.getElementById("show_popup");
    var btn1 = document.getElementById("show_popup1");
    var span = document.getElementsByClassName("my_close")[0];

    function category_add(){
       modal.style.display = "block";
        var formurl= "<?=base_url()?>index.php/Admin/add_product_types";
        $( "#form_1").attr('action',formURL);
        $(".value").text('Submit');
        $(".title_cat").text('Add New Categories');
        $("#name").val("");
        $("#category_id_1").removeAttr("selected","selected");
        $("#category_id_2").removeAttr("selected","selected");
         $(function () {  $(".select2").select2(); });
    }
    function category_update(id){
        modal.style.display = "block";
        var formurl= "<?=base_url()?>index.php/Admin/product_types_update/";
        formURL = formurl+id;
        $( "#form_1").attr('action',formURL);
        $(".title_cat").text('Update Product Name');
        $(".value").text('Update');
            $.ajax({
              url: "<?=base_url()?>index.php/Admin/product_types_get",
              type:"POST",
              data: {id:id},
              success: function(html){
                 var result = $.parseJSON(html);
                 $("#name").val(result['data'][0]['name']);
                 if (result['data'][0]['category_id'] == "1") {
                  $("#category_id_1").attr("selected","selected");
                  $("#category_id_2").removeAttr("selected","selected");
                   $(function () { $(".select2").select2(); });
                 }
                 if (result['data'][0]['category_id'] == "2") {
                  $("#category_id_2").attr("selected","selected");
                  $("#category_id_1").removeAttr("selected","selected");
                   $(function () {  $(".select2").select2(); });
                 }
               }
             });
    }

    span.onclick = function() {
        modal.style.display = "none";
    }
    window.onclick = function(event) {
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }




</script>


</body>
</html>
