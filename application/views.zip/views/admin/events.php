<!DOCTYPE html>
<html>

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="shortcut icon" href="<?=base_url()?>assets/images/favicon.ico">
  <title>Admin Nihas Technologies</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <!-- Bootstrap 3.3.6 -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/bootstrap/css/bootstrap.min.css">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <!-- fullCalendar 2.2.5-->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.min.css">
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/fullcalendar/fullcalendar.print.css" media="print">
  <!-- Theme style -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/AdminLTE.css">
  <!-- AdminLTE Skins. Choose a skin from the css/skins
       folder instead of downloading all of them to reduce the load. -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/dist/css/skins/_all-skins.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/iCheck/flat/blue.css">
  <!-- bootstrap wysihtml5 - text editor -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/bootstrap-wysihtml5/bootstrap3-wysihtml5.min.css">
   <!-- daterange picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.css">
  <!-- bootstrap datepicker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/datepicker/datepicker3.css">
    <!-- Bootstrap time Picker -->
  <link rel="stylesheet" href="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.css">

  <style type="text/css">

  .add_pro a{
    background-color:#3C8DBC !important;
    color: #ffffff !important; 
    width: 80% !important;
    margin-left: 10% !important;
    height: 30px !important;
    margin-top: 5px !important;
    margin-bottom: 5px !important;
    line-height: 10px !important;
    border-radius: 5px !important;
  }
.modal {
    display: none; /* Hidden by default */
    position: absolute; /* Stay in place */
    z-index: 1; /* Sit on top */
    padding-top: 100px; /* Location of the box */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgb(0,0,0); /* Fallback color */
    background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
}
.modal-content {
    background-color: #fefefe;
    margin: auto;
    padding: 20px;
    border: 1px solid #888;
    width: 80%;
}
.close {
    color: #aaaaaa;
    float: right;
    font-size: 28px;
    font-weight: bold;
}
.close:hover,
.close:focus {
    color: #000;
    text-decoration: none;
    cursor: pointer;
}
.agenda_table thead th{
 text-align: center;
 padding: 0px 3px;
 height: 40px;
 border-bottom: 1px solid block;
}
.agenda_table tbody tr{
  padding: 0px 10px;
}
.agenda_table tbody td{
 text-align: center;
 padding: 0px 3px;
}
</style>

</head>

<body class="hold-transition skin-blue sidebar-mini">
<div class="wrapper">

<?php $this->load->view('admin/menus.php')  ?>


  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

 <?php if (isset($msg)){ ?>
        <div class="alert <?php echo $type; ?> alert-dismissible msg" style="position: absolute;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close msg_close" style="position: absolute;right: 0px">&times;</button>
                <h4><i class="icon fa <?php echo $icon; ?>"></i><?php echo $msg; ?></h4>
                
        </div>
<?php } ?>


      <div class="alert alert-warning alert-dismissible erorr" style="position: fixed;z-index: 100;right: 5px;top: 55px">
                <button type="button" class="close erorr_close"  style="position: absolute;right: 0px">&times;</button>
                <h4 class="erorr_text"></h4>
                
        </div>




    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Events
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active">Events</li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">



        <div class="col-md-3">
          <a href="#" id="myBtn" class="btn btn-primary btn-block margin-bottom add_eve">Add  New Events</a>

          <div class="box box-solid">
           <div class="box-header with-border">
              <h3 class="box-title">
                List Of Events
              </h3>
            </div>
            <div class="box-body no-padding">
              <ul class="nav nav-pills nav-stacked">


                <?php  foreach($events as $event){ ?>
                  <li><a href="#" onclick="popup_eve_det(<?=$event->id ?>)"><i class="fa fa-circle-o"></i> <?=$event->event_name ?> </a></li>
                  <?php } ?> 

              </ul>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /. box -->
        </div>
        <!-- /.col -->






        <div class="col-md-9">
          <div class="box box-primary form_html">
          <form id="form_1" action="<?=base_url()?>index.php/Admin/event_submit" onsubmit="return validateMyForm_1();"  method="post" enctype="multipart/form-data">
            <div class="box-header with-border">
              <h3 class="box-title eve_name"> Add New Event</h3>
              <span style="float: right;">
              <a href="" class="btn btn-primary uncom_eve" onclick="return confirm('Are you Completed This Event ?');"> Event Completed </a>
              <a class="com_eve" style="color: #F56D17"> <b>  This Event Completed &emsp; </b></a>
              <a class="btn btn-primary del_eve" href=""  onclick="return confirm(' you want to delete?');" > Delete This Event </a>
              </span>
            </div>
            <!-- /.box-header -->
            <div class="box-body">

              <div class="form-group">
                <label>Event Name:</label>
                <input class="form-control" id="event_name" name="event_name" placeholder="Event Name" >
              </div>

              <div class="row">

               <div class="form-group col-sm-12 editor_html">
                <label>Event Details:</label>
                    <textarea id="event_text" name="event_text" class="form-control area" placeholder="Enter Event Detailes" style="width:100%;height:200px;"></textarea>
              </div>
            </div>

             <div class="row">
               <div class="form-group col-sm-6">
                <label>Event Address:</label>
                      <textarea id="event_address" name="event_address" class="form-control" placeholder="Enter Event Address" style="height: 170px"></textarea>
                </div>
                <div class="form-group col-sm-6" style="padding-bottom: 30px;">
                 <div class="btn btn-default btn-file" style="position: absolute;">
                   <i class="fa fa-paperclip img_ty"> &nbsp; Add Image</i> 
                   <input type="file" name="image" id="img_file" value="">
                 </div> 
                 <img src="" id="img_on" style="max-width: 100%; max-height: 300px;margin-top: 40px;">
                </div>
               </div>

               <div class="row">
                <div class="col-sm-6">
                <label>Event Start Date and Time:</label>
                <div class="row">
                 <div class="form-group col-sm-6">
                  <div class="input-group date">
                    <input type="text" class="form-control pull-right datepicker" name="event_start_date" id="event_start_date" placeholder=" Event Start Date">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                   </div>
                 </div>
                 <div class="bootstrap-timepicker col-sm-6" >
                 <div class="form-group">
                  <div class="input-group">
                    <input type="text" class="form-control timepicker" name="event_start_time" id="event_start_time" placeholder=" Event Start Time">
                    <div class="input-group-addon">
                      <i class="fa fa-clock-o"></i>
                    </div>
                  </div>
                 </div>
                </div>
                </div>
                </div>
                <div class="col-sm-6">
                <label>Event End Date and Time:</label>
                <div class="row">
                <div class="form-group col-sm-6">
                  <div class="input-group date"> 
                    <input type="text" class="form-control pull-right datepicker" name="event_end_date" id="event_end_date" placeholder=" Event End Date">
                    <div class="input-group-addon">
                      <i class="fa fa-calendar"></i>
                    </div>
                  </div>
                </div>
                <div class="bootstrap-timepicker col-sm-6" >
                <div class="form-group">
                  <div class="input-group">
                    <input type="text" class="form-control timepicker" name="event_end_time" id="event_end_time" placeholder=" Event End Time">
                    <div class="input-group-addon">
                      <i class="fa fa-clock-o"></i>
                    </div>
                  </div>
                </div>
                </div>
                </div>
              </div>
            </div>



            <div class="form-group">
              <label>Event Location:</label>
                <input class="form-control" id="event_location" name="event_location" placeholder="Event Location Iframe" >
            </div>
          
           <div class="box-header with-border">
              <h3 class="box-title"> Event Inclusion Details</h3>
            </div>

          <div class="row"  style="margin:10px;">
            <div class="col-sm-6">
                <a class="btn-sm btn-primary" id="remove_inc" style="cursor: pointer;"> Remove Last Inclusion </a>
            </div>

            <div class="col-sm-6 pull-right">
                <a class="btn-sm btn-primary  pull-right" id="add_inc" style="cursor: pointer;" > Add More Inclusion</a>
            </div>
          </div>
          <div class="inclusions_more">
          <div class="row">
            <div class="form-group col-sm-12">
                <input class="form-control event_inclusions" name="event_inclusions[]" placeholder="Event inclusions Details">
            </div>
          </div>
          </div>
          
          <div class="box-header with-border">
              <h3 class="box-title">  Event Agenda Details</h3>
            </div>

            <div class="row" style="margin: 10px;">
              <div class="col-sm-6">
                  <a class="btn-sm btn-primary" id="remove_agenda" style="cursor: pointer;"> Remove Last Agenda </a>
              </div>

              <div class="col-sm-6 pull-right">
                  <a class="btn-sm btn-primary  pull-right" id="add_agenda" style="cursor: pointer;" > Add More Agenda </a>
              </div>
            </div>


          <div class="agenda_more">
           <div class="row">
           
           <div class="col-sm-12">
           <table class="agenda_table" >
             <thead>
               <th style="width: 40%">Agenda Name</th>
               <th>Start Date</th>
               <th>Start Time</th>
               <th>End Date</th>
               <th>End Time</th>
             </thead>
             <tbody class="tbody">
             <tr class="tr">
               <td>
                  <div class="form-group">
                    <input class="form-control agenda_name" name="agenda_name[]" placeholder="Enter Agenda Name" >
                  </div>
               </td>
               <td>
                  <div class="form-group">
                     <div class="input-group date"> 
                       <input type="text" class="form-control pull-right datepicker agenda_start_date" name="agenda_start_date[]"  placeholder="Agenda Start" >
                     </div>
                  </div>
               </td>
               <td>
                 <div class="bootstrap-timepicker" >
                  <div class="form-group">
                    <div class="input-group">
                      <input type="text" class="form-control timepicker agenda_start_time" name="agenda_start_time[]" placeholder=" Agenda Start Time" >
                    </div>
                  </div>
                  </div> 
               </td>
               <td>
                  <div class="form-group">
                     <div class="input-group date"> 
                       <input type="text" class="form-control pull-right datepicker agenda_end_date" name="agenda_end_date[]" placeholder="Agenda End" >
                     </div>
                  </div>
               </td>
               <td>
                 <div class="bootstrap-timepicker" >
                  <div class="form-group">
                    <div class="input-group">
                      <input type="text" class="form-control timepicker agenda_end_time" name="agenda_end_time[]" placeholder=" Agenda End Time" >
                    </div>
                  </div>
                  </div> 
               </td>
             </tr>
             </tbody>
           </table>
           </div>


           </div>
          </div>



            </div>
            <!-- /.box-body -->
            <div class="box-footer">
              <div class="pull-right">
                <button type="submit" class="btn btn-primary value"> Submit </button>
              </div>
            </div>
            <!-- /.box-footer -->
            </form>
          </div>
          <!-- /. box -->


         </div>  <!-- /.col -md 9 -->
      </div> <!-- /.row -->
    </section><!-- /.content -->
  </div> <!-- content-wrapper close-->


  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>

</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<script src="<?=base_url()?>assets/admin/plugins/jQuery/jquery-2.2.3.min.js"></script>
<!-- Bootstrap 3.3.6 -->
<script src="<?=base_url()?>assets/admin/bootstrap/js/bootstrap.min.js"></script>
<!-- Select2 -->
<script src="<?=base_url()?>assets/admin/plugins/select2/select2.full.min.js"></script>
<!-- InputMask -->
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.date.extensions.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/input-mask/jquery.inputmask.extensions.js"></script>
<!-- date-range-picker -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>
<script src="<?=base_url()?>assets/admin/plugins/daterangepicker/daterangepicker.js"></script>
<!-- bootstrap datepicker -->
<script src="<?=base_url()?>assets/admin/plugins/datepicker/bootstrap-datepicker.js"></script>
<!-- bootstrap color picker -->
<script src="<?=base_url()?>assets/admin/plugins/colorpicker/bootstrap-colorpicker.min.js"></script>
<!-- bootstrap time picker -->
<script src="<?=base_url()?>assets/admin/plugins/timepicker/bootstrap-timepicker.min.js"></script>
<!-- SlimScroll 1.3.0 -->
<script src="<?=base_url()?>assets/admin/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<!-- iCheck 1.0.1 -->
<script src="<?=base_url()?>assets/admin/plugins/iCheck/icheck.min.js"></script>
<!-- FastClick -->
<script src="<?=base_url()?>assets/admin/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url()?>assets/admin/dist/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="<?=base_url()?>assets/admin/dist/js/demo.js"></script>
<!-- Page script -->
<script>
  $(function () {
    //Initialize Select2 Elements
    $(".select2").select2();

    //Datemask dd/mm/yyyy
    $("#datemask").inputmask("dd/mm/yyyy", {"placeholder": "dd/mm/yyyy"});
    //Datemask2 mm/dd/yyyy
    $("#datemask2").inputmask("mm/dd/yyyy", {"placeholder": "mm/dd/yyyy"});
    //Money Euro
    $("[data-mask]").inputmask();

    //Date range picker
    $('#reservation').daterangepicker();
    //Date range picker with time picker
    $('#reservationtime').daterangepicker({timePicker: true, timePickerIncrement: 30, format: 'MM/DD/YYYY h:mm A'});
    //Date range as a button
    $('#daterange-btn').daterangepicker(
        {
          ranges: {
            'Today': [moment(), moment()],
            'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
            'Last 7 Days': [moment().subtract(6, 'days'), moment()],
            'Last 30 Days': [moment().subtract(29, 'days'), moment()],
            'This Month': [moment().startOf('month'), moment().endOf('month')],
            'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
          },
          startDate: moment().subtract(29, 'days'),
          endDate: moment()
        },
        function (start, end) {
          $('#daterange-btn span').html(start.format('MMMM D, YYYY') + ' - ' + end.format('MMMM D, YYYY'));
        }
    );

    //Date picker
    $('.datepicker').datepicker({
      autoclose: true,
      format: 'dd/mm/yyyy'
    });


    //iCheck for checkbox and radio inputs
    $('input[type="checkbox"].minimal, input[type="radio"].minimal').iCheck({
      checkboxClass: 'icheckbox_minimal-blue',
      radioClass: 'iradio_minimal-blue'
    });
    //Red color scheme for iCheck
    $('input[type="checkbox"].minimal-red, input[type="radio"].minimal-red').iCheck({
      checkboxClass: 'icheckbox_minimal-red',
      radioClass: 'iradio_minimal-red'
    });
    //Flat red color scheme for iCheck
    $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
      checkboxClass: 'icheckbox_flat-green',
      radioClass: 'iradio_flat-green'
    });

    //Colorpicker
    $(".my-colorpicker1").colorpicker();
    //color picker with addon
    $(".my-colorpicker2").colorpicker();

    //Timepicker

    $(".timepicker").timepicker({
      showInputs: false,
      minuteStep: 1
    });
  });
</script>

<script>
  var modal = document.getElementById('myModal');
  var btn = document.getElementById("myBtn");
  var span = document.getElementsByClassName("close")[0];
  btn.onclick = function() {
      modal.style.display = "block";
  }
  span.onclick = function() {
      modal.style.display = "none";
  }
  window.onclick = function(event) {
      if (event.target == modal) {
          modal.style.display = "none";
      }
  }
</script>

<script>
  $(".erorr_close").click(function(){
      $('.erorr').hide();
  });

  $(".msg_close").click(function(){
      $('.msg').hide();
      window.location.href='<?=base_url()?>index.php/Admin/events';
  });

  $("#img_file").change(function(){
      readURL(this);
      $("#img_on").show();
  });

    function readURL(input) {
      if (input.files && input.files[0]) {
          var reader = new FileReader();
          reader.onload = function (e) {
              $('#img_on').attr('src', e.target.result);
            }
          reader.readAsDataURL(input.files[0]);
         }
      }
</script>



<script>
 $(".add_eve").hide();
 $("#img_on").hide();
$(".del_eve").hide();
$(".uncom_eve").hide();
$(".com_eve").hide();
var edit = $(".editor_html").html();
function popup_eve_det(id){
    var formurl= "<?=base_url()?>index.php/Admin/event_update/";
    var delete_url= "<?=base_url()?>index.php/Admin/delete_event/";
    var complete_url= "<?=base_url()?>index.php/Admin/complete_event/";
    var img_url = "<?=base_url()?>assets/admin/images/"
       formURL = formurl+id;
       delete_URL = delete_url+id;
       complete_URL = complete_url+id;
       $( "#form_1").attr('action',formURL);
       $(".add_eve").show();
       $( ".del_eve").attr('href',delete_URL);
       $( ".uncom_eve").attr('href',complete_URL);
       $( ".del_eve").show();
       $("#img_on").show();
       $("#remove_agenda").show();
       $("#remove_inc").show();
       $(".value").text('Update');
       $(".editor_html").html("");
       $(".uncom_eve").hide();
$(".com_eve").hide();

     $.ajax({
          url: "<?=base_url()?>index.php/Admin/events_get",
          type:"POST",
          data: {id:id},
          success: function(html){
             var result = $.parseJSON(html);
            $("#event_name").val(result['data'][0]['event_name']);
            $(".eve_name").text(result['data'][0]['event_name']+" Detailes");
            $("#event_start_date").val(result['data'][0]['event_start_date']);
            $("#event_start_time").val(result['data'][0]['event_start_time']);
            $("#event_end_date").val(result['data'][0]['event_end_date']);
            $("#event_end_time").val(result['data'][0]['event_end_time']);
            $("#event_address").val(result['data'][0]['address']);
            $("#event_location").val(result['data'][0]['event_location']);
            $(".img_ty").text('Update Image');
            var img_name = result['data'][0]['image'];
            var img_on = img_url+img_name;
            $("#img_on").attr("src", img_on );

            var status = result['data'][0]['status'];
            if (status != "3") {
              $(".uncom_eve").show();
            }else{
               $(".com_eve").show();
            }

            $(".editor_html").html(edit);
            $("#event_text").text(result['data'][0]['event_detailes']);

            tinyMCE.init( {
                   selector: ".area",
              theme: "modern",
              plugins: [
                "advlist autolink lists image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
              ],
              toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent ",
              toolbar2: "print preview media | forecolor backcolor emoticons",
            });


          }  
    });





   $.ajax({
      type: "POST",
      url: "<?=base_url()?>index.php/Admin/events_inclusions_get",
      data: {id:id},
      success: function(result){
        results= $.parseJSON(result);  
          $(".inclusions_more").html("" );
           $.each(results['data'], function(key,valueObj){
              $(".inclusions_more").append('<div class="row">\
                                             <div class="form-group col-sm-12">\
                                               <input class="form-control event_inclusions" name="event_inclusions[]" placeholder="Event inclusions Details" value="'+valueObj['inclusions']+'">\
                                             </div>\
                                            </div>\
                                          ');
                       });
                  }
    });


    $.ajax({
      type: "POST",
      url: "<?=base_url()?>index.php/Admin/events_agenda_get",
      data: {id:id},
      success: function(result){
        results= $.parseJSON(result); 
          $(".tbody").html("");
           $.each(results['data'], function(key,valueObj){
                  $(".tbody").append('<tr class="tr">\
                        <td>\
                          <div class="form-group">\
                            <input class="form-control agenda_name"  name="agenda_name[]" value="'+valueObj["agenda_name"]+'" placeholder="Enter Agenda Name">\
                          </div>\
                         </td>\
                         <td>\
                           <div class="form-group">\
                             <div class="input-group date">\
                               <input type="text" class="form-control pull-right datepicker agenda_start_date" name="agenda_start_date[]"  value="'+valueObj["agenda_start_date"]+'" placeholder="Agenda Start" required="required">\
                             </div>\
                           </div>\
                        </td>\
                        <td>\
                         <div class="bootstrap-timepicker">\
                          <div class="form-group">\
                            <div class="input-group">\
                              <input type="text" class="form-control timepicker agenda_start_time" name="agenda_start_time[]" value="'+valueObj['agenda_start_time']+'" placeholder=" Agenda Start Time" required="required">\
                            </div>\
                          </div>\
                         </div>\
                        </td>\
                        <td>\
                         <div class="form-group">\
                           <div class="input-group date">\
                              <input type="text" class="form-control pull-right datepicker agenda_end_date" name="agenda_end_date[]" value="'+valueObj['agenda_end_date']+'" placeholder="Agenda End" required="required">\
                           </div>\
                         </div>\
                        </td>\
                        <td>\
                         <div class="bootstrap-timepicker">\
                          <div class="form-group">\
                            <div class="input-group">\
                              <input type="text" class="form-control timepicker agenda_end_time" name="agenda_end_time[]" value="'+valueObj['agenda_end_time']+'" placeholder=" Agenda End Time" required="required">\
                            </div>\
                          </div>\
                         </div>\
                        </td>\
                      </tr>');

                    $(".timepicker").timepicker({
                        showInputs: false,
                        minuteStep: 1
                      });
                    $('.datepicker').datepicker({
                        autoclose: true,
                        format: 'dd/mm/yyyy'
                    });
            });
          }
        });
    }




    form_html = $(".form_html").html();
    $(".add_eve").click(function(){
            window.location.href='<?=base_url()?>index.php/Admin/events';
    });



    function add_eve(id){
      var formurl= "<?=base_url()?>index.php/index/product_submit/";
       formURL = formurl+id;
       $( "#form_1").attr('action',formURL);
        $("#product_name").val('');
        $(".pro_name").text('Add Product');
        $("#product_text").text('');
         $("#product_img").val('');
         $(".add_pro").hide();

         $("#img_on").hide()
         $(".value").text('Submit');
         $(".img_ty").text('Add Image');
  }
</script>

<script>
 $('.erorr').hide();


   function validateMyForm_1(){


       if($('#form_1').find('#event_name').val() == ""){
              $('.erorr').show();
              $('.erorr_text').text("Enter Event Name");
               $('.erorr').delay(3000).fadeOut('fast');
              return false;
       // }else if($('#form_1').find('#event_text').val() == "") { 
       //        $('.erorr').show();
       //        $('.erorr_text').text("Enter Event Detailes");
       //        $('.erorr').delay(3000).fadeOut('fast');
       //        return false;
       }else if($('#form_1').find('input[type=file]').val() == "" && $('#form_1').attr('action')=='<?=base_url()?>index.php/Admin/event_submit') { 
                  $('.erorr').show();
                  $('.erorr_text').text("Add Event Image");
                  $('.erorr').delay(3000).fadeOut('fast');
                  return false;
       }else if($('#form_1').find('#event_address').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Event Address");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#event_start_date').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Event Start Date");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#event_start_time').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Event Start Time");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#event_end_date').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Event End Date");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#event_end_time').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Enter Event End Time");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else if($('#form_1').find('#event_location').val() == "") { 
              $('.erorr').show();
              $('.erorr_text').text("Add Event Location In Iframe Format");
              $('.erorr').delay(3000).fadeOut('fast');
              return false;
       }else{

              if ($('#form_1').find('#event_location').val().indexOf('<iframe') == -1){
                 $('.erorr').show();
                  $('.erorr_text').text("Enter Valid Event Location in Iframe Format");
                  $('.erorr').delay(3000).fadeOut('fast');
               return false;
              }

          var i=1; 
          var j=1;
          var k=1;
          var l=1;
          var m=1;
              $("#form_1 .event_inclusions").each(function() {
                  if($(this).val() == "" ) { i=0; } 
                });
              $("#form_1 .agenda_name").each(function() {
                  if($(this).val() == "" ) { j=0; } 
                });
              $("#form_1 .agenda_start_date").each(function() {
                  if($(this).val() == "" ) { k=0; } 
                });
              $("#form_1 .agenda_start_time").each(function() {
                  if($(this).val() == "" ) { l=0; } 
                });
              $("#form_1 .agenda_end_date").each(function() {
                  if($(this).val() == "" ) { m=0; } 
                });
              $("#form_1 .agenda_end_time").each(function() {
                  if($(this).val() == "" ) { n=0; } 
                });
              if(i==0){ 
                     $('.erorr').show();
                     $('.erorr_text').text("Enter All Event Inclusion Detailes");
                     $('.erorr').delay(3000).fadeOut('fast');
                     return false; 
               }
              if(j==0){ 
                     $('.erorr').show();
                     $('.erorr_text').text("Enter All Agenda Name");
                     $('.erorr').delay(3000).fadeOut('fast');
                     return false; 
               }
              if(k==0){ 
                     $('.erorr').show();
                     $('.erorr_text').text("Enter All Agenda Start Date");
                     $('.erorr').delay(3000).fadeOut('fast');
                     return false; 
               }
              if(l==0){ 
                     $('.erorr').show();
                     $('.erorr_text').text("Enter All Agenda Start Time");
                     $('.erorr').delay(3000).fadeOut('fast');
                     return false; 
               }
              if(m==0){ 
                     $('.erorr').show();
                     $('.erorr_text').text("Enter All Agenda End Date");
                     $('.erorr').delay(3000).fadeOut('fast');
                     return false; 
               }
               if(n==0){ 
                     $('.erorr').show();
                     $('.erorr_text').text("Enter All Agenda End Time");
                     $('.erorr').delay(3000).fadeOut('fast');
                     return false; 
               }


      }
 }
</script>

<script type="text/javascript">

 $("#remove_agenda").hide();

    row_new = $(".agenda_more .tbody").html();
     i=0;
    $("#add_agenda").click(function(){
      $("#remove_agenda").show();
      i++; 
       if (i <= 15) {
           $('.agenda_more .tbody').append(row_new);
         }
          $(".timepicker").timepicker({
            showInputs: false,
            minuteStep: 1
          });
          $('.datepicker').datepicker({
              autoclose: true,
              format: 'dd/mm/yyyy'
          });

    });

    $("#remove_agenda").click(function(){
      if ($('.agenda_more .tbody .tr').length == 2) {
        $("#remove_agenda").hide();
      }
      if ( $('.agenda_more .tbody .tr').length > 1 ) {
          $(".agenda_more .tbody .tr" ).last().remove();
        }
    });
 
</script>

<script>
   $("#remove_inc").hide();
    row_inc = $(".inclusions_more").html();
    i=0;
    $("#add_inc").click(function(){
      $("#remove_inc").show();
      i++; 
       if (i <= 15) {
           $('.inclusions_more').append(row_inc.replace('display:none','display:block').replace('display:block','display:none'));
         }
    });

    $("#remove_inc").click(function(){
      if ($('.inclusions_more .row').length == 2) {
        $("#remove_inc").hide();
      }
      if ( $('.inclusions_more .row').length > 1 ) {
          $(".inclusions_more .row" ).last().remove();
        }
    });
 
</script>


<script src="<?=base_url()?>/assets/tinymce/js/tinymce/tinymce.min.js"></script>

<script type="text/javascript">
         tinyMCE.init( {
                   selector: ".area",
              theme: "modern",
              plugins: [
                "advlist autolink lists image charmap print preview hr anchor pagebreak",
                "searchreplace wordcount visualblocks visualchars code fullscreen",
                "insertdatetime nonbreaking save table contextmenu directionality",
                "emoticons template paste textcolor colorpicker textpattern"
              ],
              toolbar1: "insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent ",
              toolbar2: "print preview media | forecolor backcolor emoticons",
            });
</script>


</body>
</html>
