<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>


  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix" >
				<h2 style="margin-bottom: 0px;">About Us</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">About</li>
				</ol>
			</div>

		</section><!-- #page-title end -->



		<!-- Content
		============================================= -->

		<?php foreach ($about_us as $about) { ?>

		<section id="content">

			<div class="content-wrap">

				<div class="section header-stick">
				<div class="container clearfix">

					<div class="row">

					<div class="col-sm-6 ">
							<div class="heading-block" style="margin-bottom: 30px;">
								<h3>ABOUT <span class="color">NIHAS TECHNOLOGIES</span></h3>
							</div>

							<div class="row clearfix">

								<div class="col-md-12">
									<p style="text-align: justify;">
									<?=$about->about?>
									</p>
								</div>

							</div>

					</div>



						<div class="col-sm-6 bottommargin">

						<div class="heading-block" style="margin-bottom: 30px;">
								<h3>WHY CHOOSE US</h3>
							</div>

							<div class="accordion accordion-border clearfix nobottommargin">

								<div class="acctitle"><i class="acc-closed fa fa-chevron-circle-down"></i><i class="acc-open fa fa-times-circle-o"></i>Our Company's Values</div>
								<div class="acc_content clearfix"><?=$about->why_choose_1?></div>

								<div class="acctitle"><i class="acc-closed fa fa-chevron-circle-down"></i><i class="acc-open fa fa-times-circle-o"></i>How to get Support?</div>
								<div class="acc_content clearfix"><?=$about->why_choose_2?></div>

								<div class="acctitle"><i class="acc-closed fa fa-chevron-circle-down"></i><i class="acc-open fa fa-times-circle-o"></i>Where can you find us?</div>
								<div class="acc_content clearfix"><?=$about->why_choose_3?></div>

								<div class="acctitle"><i class="acc-closed fa fa-chevron-circle-down"></i><i class="acc-open fa fa-times-circle-o"></i>Why you choose our Company?</div>
								<div class="acc_content clearfix"><?=$about->why_choose_4?></div>

							</div>

						</div>


						

					</div>

				</div>
				</div>

				<div class="container clearfix">

					<div class="col_one_third">

						<div class="heading-block fancy-title nobottomborder title-bottom-border">
							<h4>Our <span>Mission</span>.</h4>
						</div>

						<p><?=$about->mission?></p>

					</div>

					<div class="col_one_third">

						<div class="heading-block fancy-title nobottomborder title-bottom-border">
							<h4>Our <span>Vission</span>.</h4>
						</div>

						<p><?=$about->vission?></p>

					</div>

					<div class="col_one_third col_last">

						<div class="heading-block fancy-title nobottomborder title-bottom-border">
							<h4>Quality <span>Policy</span>.</h4>
						</div>

						<p><?=$about->policy?></p>

					</div>

				</div>

				<div class="section topmargin-sm footer-stick">

					<h4 class="uppercase center">What <span>Clients</span> say?</h4>

					<div class="fslider testimonial testimonial-full" data-animation="fade" data-arrows="false">
						<div class="flexslider">
							<div class="slider-wrap">

							 <?php foreach ($about_client_say as $client_say ) { ?>

								<div class="slide">
									<div class="testi-image">
										<img src="<?=base_url()?>assets/images/testimonials/<?=$client_say->image?>" alt="Customer Testimonails">
									</div>
									<div class="testi-content">
										<p><?=$client_say->client_said?></p>
										<div class="testi-meta">
											<?=$client_say->name?>
											<span><?=$client_say->company?></span>
										</div>
									</div>
								</div>

								<?php } ?>
							</div>
						</div>
					</div>

				</div>

			</div>

		<div class="content-wrap">
             <div class="container clearfix">

					<div class="clear"></div>

					<div class="heading-block center">
						<h4>Our Clients</h4>
					</div>


					<div id="oc-clients" class="section nobgcolor notopmargin owl-carousel owl-carousel-full image-carousel footer-stick carousel-widget" data-margin="80" data-loop="true" data-nav="false" data-autoplay="5000" data-pagi="false" data-items-xxs="2" data-items-xs="3" data-items-sm="4" data-items-md="5" data-items-lg="6">
                    <?php foreach ($about_clients_logo as $logo ) { ?>

					<div class="oc-item" style="height: 100%">
					  <img src="<?=base_url()?>assets/images/clients/<?=$logo->image?>" alt="Clients" style="vertical-align: middle;">
					</div>
                    
                    <?php } ?>


				</div>


				

				</div>
		    </div> 	

       



         <div class="section topmargin-sm footer-stick">


       <div class="clear"></div>

					<div class="heading-block center">
						<h4>Our Achievements</h4>
					</div>

		    <div class="col_one_fourth center" data-animate="bounceIn">
						<i class="i-plain i-xlarge divcenter nobottommargin fa fa-users" style="color: #878b8e;"></i>
						<div class="counter counter-large"><span data-from="0" data-to="<?=$about->client_served?>" data-refresh-interval="2" data-speed="1000"></span>+</div>
						<h5>Clients Served</h5>
					</div>

					<div class="col_one_fourth center" data-animate="bounceIn" data-delay="200">
						<i class="i-plain i-xlarge divcenter nobottommargin fa fa-suitcase" style="color: #878b8e;"></i>
						<div class="counter counter-large" ><span data-from="0" data-to="<?=$about->no_of_projects?>" data-refresh-interval="2" data-speed="1000"></span>+</div>
						<h5>No. of Projects</h5>
					</div>

					<div class="col_one_fourth center" data-animate="bounceIn" data-delay="400">
						<i class="i-plain i-xlarge divcenter nobottommargin fa fa-trophy" style="color: #878b8e;"></i>
						<div class="counter counter-large" ><span data-from="0" data-to="<?=$about->awards?>" data-refresh-interval="2" data-speed="1000"></span>+</div>
						<h5>No. of Awards</h5>
					</div>

					<div class="col_one_fourth center col_last" data-animate="bounceIn" data-delay="600">
						<i class="i-plain i-xlarge divcenter nobottommargin fa fa-coffee" style="color: #878b8e;"></i>
						<div class="counter counter-large"><span data-from="0" data-to="<?=$about->cup_of_coffee?>" data-refresh-interval="2" data-speed="1000"></span>+</div>
						<h5>Cups of Coffee</h5>
					</div>
             </div>



		</section><!-- #content end -->

		<?php } ?>

<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".about").addClass("current");
	 });
</script>

</body>

</html>