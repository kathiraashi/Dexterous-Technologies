<!DOCTYPE html>
 <html lang="en-US" prefix="og: http://ogp.me/ns#" xmlns="http://www.w3.org/1999/xhtml">
 
  <?php include 'header_links.php'; ?>

 </head>

<body class="stretched">

	<!-- Document Wrapper
	============================================= -->
	<div id="wrapper" class="clearfix">

  <?php include 'header.php'; ?>


  		<!-- Page Title
		============================================= -->
		<section id="page-title" style="padding-top: 15px;padding-bottom: 5px;">

			<div class="container clearfix">
				<h2 style="margin-bottom: 0px;">Events View</h2>
				<ol class="breadcrumb">
					<li><a href="<?=base_url()?>">Home</a></li>
					<li class="active">Events View</li>
				</ol>
			</div>

		</section><!-- #page-title end -->

	<?php if (isset($msg)){ ?>
	    <div class="style-msg successmsg">
			<div class="sb-msg"><i class="fa fa-check"></i> <?php echo $msg; ?> </div>
			<button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
			</div>
       <?php } ?>




		<!-- Content
		============================================= -->
		<section id="content">
 
		<?php foreach ($events as $event ) { ?>

			<div class="content-wrap" style="padding-top: 20px;">

				<div class="container clearfix">
					<center> <h2> <?=$event->event_name ?> </h2> </center>		

					<div class="single-event">

						<div class="col_three_fourth">
							<div class="entry-image nobottommargin">
								<a href="#"><img src="<?=base_url()?>assets/admin/images/<?=$event->image?>" alt="Event Single"></a>
								<div class="entry-overlay">
									<span class="hidden-xs"></span><div id="event-countdown" class="countdown"> <?=$event->event_name ?></div>
								</div>
							</div>
						</div>

						<div class="col_one_fourth col_last">
							<div class="panel panel-default events-meta">
								<div class="panel-heading">
									<h3 class="panel-title">Event Info:</h3>
								</div>
								<div class="panel-body">
									<ul class="iconlist nobottommargin">
										<li><i class="fa fa-calendar"></i> &nbsp; &nbsp;<?=$event->event_start_date?> &nbsp; to  &nbsp;<?=$event->event_end_date?></li>
										<li><i class="fa fa-clock-o"></i> &nbsp; &nbsp; <?=$event->event_start_time?></li>
										<li><i class="fa fa-map-marker"></i> &nbsp; &nbsp; <?=$event->address?></li>
									</ul>
								</div>
							</div>
						<!-- <a data-toggle="modal" data-target="#eventModal" data-id="<?=$event->id?>" data-name="<?=$event->event_name?>"  class="btn btn-success btn-block btn-lg reg_get">Register Now</a> -->
						  </div>

						<div class="clear"></div>

						<div class="col_three_fifth">

							<h3>Details</h3>

							<p><?=$event->event_detailes?></p>

						   <div class=" nobottommargin ">

							<h4>Agenda</h4>

							<div class="table-responsive">
								<table class="table table-striped">
									<thead>
										<tr>
											<th>Timings</th>
											<th>Events</th>
										</tr>
									</thead>
									<tbody>
									<?php foreach ($events_agenda as $agenda ) { ?>
										<tr>
											<td><span class="label label-danger"><?=$agenda->agenda_start_date?>&nbsp; - &nbsp;<?=$agenda->agenda_start_time?> &nbsp; &nbsp;  to   &nbsp; &nbsp; <?=$agenda->agenda_end_date?> &nbsp;-  &nbsp;<?=$agenda->agenda_end_time?></span>
											</td>
											<td><?=$agenda->agenda_name?></td>
										</tr>
									<?php } ?>
								
									</tbody>
								</table>
							</div>

						</div>

						</div>

						<div class="col_two_fifth col_last">

							<h4>Location</h4>
							
							<section id="event-location" class="gmap"> <?=$event->event_location?> </section>

						</div>

						<div class="clear"></div>
						</div>

						<div class=" col_three_fifth nobottommargin">
                              <h4>Inclusions</h4>
								<ul class="iconlist nobottommargin">
								<?php foreach ($events_inclusions as $inclusions) { ?>
								<li><i class="fa fa-check"></i> &nbsp; &nbsp; <?=$inclusions->inclusions?></li>
								<?php } ?>
									
								</ul>

							</div>



					</div>

				</div>
			<?php } ?>

    
<!--                   <div class="modal fade" id="eventModal" tabindex="-1" role="dialog" aria-labelledby="contactFormModalLabel" aria-hidden="true">
							<div class="modal-dialog">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" style="color: gray;" data-dismiss="modal" aria-hidden="true">&times;</button>
										<h4 class="modal-title model_head"> Registration</h4>
									</div>
									<div class="modal-body">

										<div class="">
											
											<form class="nobottommargin" id="quot_form"  action="<?=base_url()?>index.php/Index/event_register" onsubmit="return validateMyForm_1();" method="post">

												<div class="form-process"></div>

												<div class="col_half">
													<label> Name <small>*</small></label>
													<input type="text"  name="name"  class="sm-form-control required"  required />
												</div>

												<div class="col_half col_last">
													<label >Designation </label>
													<input type="text" name="profesion" value="" class=" sm-form-control" />
												</div>

												<div class="clear"></div>

												<div class="col_half ">
													<label>Company</label><small>*</small>
													<input type="text" name="company" value="" class=" sm-form-control"  />
												</div>

												<div class="col_half col_last">
													<label>Email</label><small>*</small>
													<input type="email" name="email" value="" class="required sm-form-control" required />
												</div>


												<div class="clear"></div>
												<input type="hidden" name="event_id" value="" id="event_id" />
												<input type="hidden" name="event_name" value="" id="event_name" />
 
												<div class="col_half">
													<label>Phone </label><small>*</small>
													<input type="text" name="phone" value="" class="required sm-form-control" required />
												</div>

												<div class="col_half col_last">
													<label> No Of Attendees <small>*</small></label>
													<input type="number" name="participates" value="" class="required sm-form-control" required />
												</div>


												<div class="col_full">
													<center><button class="button button-3d nomargin" type="submit" value="submit">Send Message</button></center>
												</div>

											</form>

										</div>


									</div>
								</div><!-- /.modal-content -->
							</div><!-- /.modal-dialog -->
						</div><!-- /.modal -->


 -->


               



		</section><!-- #content end -->

		<?php include 'footer.php'; ?>

	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="fa fa-arrow-up"></div>

		<!-- External JavaScripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/jquery.js"></script>

	<!-- Footer Scripts
	============================================= -->
	<script type="text/javascript" src="<?=base_url()?>assets/custom_js/functions.js"></script>


<script>jQuery(document).ready(function(e){e("#primary-menu > ul li").find('.new-badge').children("div").append('<span class="label label-danger" style="display:inline-block;margin-left:8px;position:relative;top:-1px;text-transform:none;">New</span>')});</script>

<script type="text/javascript">
	 $(document).ready(function(){
	 	$("#primary-menu ul li").removeClass('current');

        $(".events").addClass("current");
	 });
</script>

<script type="text/javascript">
   function validateMyForm_1(){

       if($('input[name=name]').val() == ""){
              $('input[name=name]').addClass('red')
              return false;
        }else if($('input[name=email]').val() == ""){
              $('input[name=email]').addClass('red')
              return false;
        }else if($('input[name=phone]').val() == ""){
              $('input[name=phone]').addClass('red')
              return false;
        }else if($('input[name=participates]').val() == ""){
              $('input[name=participates]').addClass('red')
              return false;
        }else{

              return true;
      }
 }

 $('input').keyup(function(){
 	$(this).removeClass('red');
 })
</script>


  <script type="text/javascript">
 	$(document).ready(function(){
	 	$(".reg_get").click(function(){
	 		var id = $(this).attr('data-id');
	 		var name = $(this).attr('data-name');
	 		$('#event_id').val(id);
	 		$('#event_name').val(name);
            $('.model_head').html("<span style='color:#1B8FC8'>"+name +" </span> <small>Registration </small>")
	 		
	 	});
     $(".style-msg button.close").click(function(){
     	 window.location.href='<?=base_url()?>index.php/Index/events';
     });

	 	
	 });
 </script>

 

</body>

</html>