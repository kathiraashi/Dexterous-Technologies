<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Index extends CI_Controller {

		public function __construct(){
          parent::__construct();
          $this->load->library('curl'); 
		      $this->load->library('session');
          $this->load->model('login_model'); 
          $this->load->model('common_model'); 	

    }

	public function index()
	{
      $this->db->select("*")-> from('events')->order_by("events.status asc")->limit(3);
      $query1 = $this->db->get();
      $data['events'] =$query1->result();
      
      $data['sliders'] = $this->common_model->select('*','sliders');

      $data['about_us'] = $this->common_model->select('*','about_us');

     $data['about_clients_logo']= $this->common_model->select('*','about_clients_logo');
     
		$this->load->view('index',$data);
	}
  public function about()
  { 

    $data['about_us'] = $this->common_model->select('*','about_us');
    $data['about_client_say'] = $this->common_model->select('*','about_client_say');
    $data['about_clients_logo']= $this->common_model->select('*','about_clients_logo');

    $this->load->view('about',$data);
  }
  public function career()
  { 
    $this->db->select("*")-> from('career')->order_by("career.id desc");
      $query1 = $this->db->get();
      $data['careers'] =$query1->result();
    $this->load->view('career',$data);
  }

   public function job()
    { 
          extract($_REQUEST);  

                $target_dir = "././assets/admin/resume/";
                $resume_name= "resume_".date("h-i-s").basename($_FILES["resume"]["name"]);
                $target_file = $target_dir .$resume_name;     
            if (move_uploaded_file($_FILES["resume"]["tmp_name"], $target_file)) {
               $values=array(
                       'fname'=>$fname,
                       'lname'=>$lname,
                       'age'=> $age,
                       'gender'=>$gender,
                       'email'=>$email,
                       'phone'=>$phone,
                       'position'=> $position,
                       'experience'=>$experience,
                       'commend'=>$commend,
                       'resume'=>$resume_name,
                       'create_date'=>date('Y-m-d H:i:s')
                       );
                $result = $this->common_model->insert('jobs',$values);

                $this->db->select("*")-> from('career')->order_by("career.id desc");
                  $query1 = $this->db->get();
                  $data['careers'] =$query1->result();
                  $data['msg'] ="Your Application Send Successfully ";
                $this->load->view('career',$data);
                  } 
    }




  public function events()
  {

      $this->db->select("*")-> from('events')->order_by("events.id desc");
      $query1 = $this->db->get();

      $data['events'] =$query1->result();

      $data['new_events'] = $this->common_model->select('*','events',array('status' => "0"));
      $data['old_events'] = $this->common_model->select('*','events',array('status' => "3"));

    $this->load->view('events',$data  );
  }

  

    public function events_view($id)
  {

     $data['events'] = $this->common_model->select('*','events',array('id' => $id));
     $data['events_inclusions'] = $this->common_model->select('*','events_inclusions',array('events_id' => $id));
     $data['events_agenda'] = $this->common_model->select('*','events_agenda',array('events_id' => $id));

    $this->load->view('events_view',$data);
  }


  public function event_register()
    { 

      $recaptchaResponse = trim($this->input->post('g-recaptcha-response'));
      $userIp=$this->input->ip_address();
      $secret='6LfeJzQUAAAAAKkruN-Ont8HUoT_j4IBDCo0PiYi';

      $url="https://www.google.com/recaptcha/api/siteverify?secret=".$secret."&response=".$recaptchaResponse."&remoteip=".$userIp;

      $response = $this->curl->simple_get($url);

      $status= json_decode($response, true);

      if($status['success']){   

          extract($_REQUEST);  
               $values=array(
                       'event_id'=>$event_id,
                       'event_name'=>$event_name,
                       'name'=>$name,
                       'profesion'=>$profesion,
                       'company'=>$company,
                       'email'=>$email,
                       'phone'=>$phone,
                       'participates'=>$participates,
                       'create_date'=>date('Y-m-d H:i:s')
                       );
                $result = $this->common_model->insert('events_register',$values);

                $data['msg'] ="Successfully Registerd Your Detailes";
          }
          else {
              
               $data['msg'] ="Registration Failed Contact Our Admin ";

          } 


                

                $this->db->select("*")-> from('events')->order_by("events.id desc");
                $query1 = $this->db->get();
                $data['events'] =$query1->result();
                
      $data['new_events'] = $this->common_model->select('*','events',array('status' => "0"));
      $data['old_events'] = $this->common_model->select('*','events',array('status' => "3"));
                $this->load->view('events',$data);




    }






  public function products($id)
  {

    $data['products']=$this->common_model->select('*','products',array('product_type_id' => $id));
    $data['product_type_id'] = $id;

    $this->load->view('products',$data);
  }

    public function product_request()
    { 
          extract($_REQUEST);  
               $values=array(
                       'type'=>$type,
                       'product_name'=>$product_name,
                       'name'=>$name,
                       'designation'=>$designation,
                       'company'=>$company,
                       'email'=>$email,
                       'phone'=>$phone,
                       'address'=> $address,
                       'message'=>$message,
                       'create_date'=>date('Y-m-d H:i:s')
                       );
                $result = $this->common_model->insert('product_request',$values);

                $data['msg'] ="Your Message Send Successfully ";

         $data['pro']=$this->common_model->select('*','products',array('id' => $product_id));
         $product_type=$data['pro'][0]->product_type_id;

         $data['product_type_id'] = $product_type;

         $data['products']=$this->common_model->select('*','products',array('product_type_id' => $product_type));

                $this->load->view('products',$data);

    }

  public function services()
  {
    $data['services'] = $this->common_model->select('*','services'); 

    $this->load->view('services',$data);
  }

    public function support()
  {
    $data['softwars'] = $this->common_model->select('*','product_type',array('category_id' => "2"));
    $data['equipments'] = $this->common_model->select('*','product_type',array('category_id' => "1"));  

    $this->load->view('support',$data);
  }



  public function customer_support_submit()
    { 
          extract($_REQUEST);  
               $values=array(
                       'name'=>$name,
                       'company'=>$company,
                       'type'=>$type,
                       'email'=>$email,
                       'phone'=>$phone,
                       'products'=>$products,
                       'purchase_year'=>$purchase_year,
                       'subscription'=>$subscription,
                       'message'=>$message,
                       'create_date'=>date('Y-m-d H:i:s')
                       );
                $result = $this->common_model->insert('customer_support',$values);


                $data['msg'] ="Your Message Send Successfully ";
                 $data['softwars'] = $this->common_model->select('*','product_type',array('category_id' => "2"));
                 $data['equipments'] = $this->common_model->select('*','product_type',array('category_id' => "1"));  


                $this->load->view('support',$data);

    }


    public function industries($id)
  {

    $data['industries']=$this->common_model->select('*','industries',array('id' => $id));
    $data['industry_products']=$this->common_model->select('*','industry_products',array('industry_id' => $id));


    $this->load->view('industries',$data);
  }

  public function go_product($pro_id)
  {

    $data['pro_type_id']=$this->common_model->select('*','products',array('id' => $pro_id));
    $id = $data['pro_type_id'][0]->product_type_id;
    $data['products']=$this->common_model->select('*','products',array('product_type_id' => $id));
    $data['product_type_id'] = $id;

    $this->load->view('products',$data);
  }

public function case_studies()
  {

    $data['case_studies']=$this->common_model->select('*','case_studies');

    $this->load->view('case_studies',$data);
  }

  public function brochures()
  {

    $data['brochures']=$this->common_model->select('*','brochures');

    $this->load->view('brochures',$data);
  }

    public function white_papers()
  {

    $data['white_papers']=$this->common_model->select('*','white_papers');

    $this->load->view('white_papers',$data);
  }

    public function draft_sight()
  {

    $data['draft_sight']=$this->common_model->select('*','draft_sight');

    $this->load->view('draft_sight',$data);
  }

 public function edrawing()
  {
    $data['edrawing']=$this->common_model->select('*','edrawing');
    $data['edrawing_points']=$this->common_model->select('*','edrawing_points');
    $this->load->view('edrawing',$data);
  }

  public function videos()
  {

    $this->load->view('videos');
  }
   public function contact()
  {

    $this->load->view('contact');
  }

  public function contact_submit()
    { 
          extract($_REQUEST);  
               $values=array(
                       'name'=>$name,
                       'email'=>$email,
                       'phone'=>$phone,
                       'subject'=> $subject,
                       'message'=>$message,
                       'create_date'=>date('Y-m-d H:i:s')
                       );
                $result = $this->common_model->insert('contact',$values);

                $data['msg'] ="Your Message Send Successfully ";
                $this->load->view('contact',$data);

    }


	







}
