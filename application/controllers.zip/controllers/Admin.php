<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

		public function __construct(){
          parent::__construct();
		      $this->load->library('session');
          $this->load->model('login_model'); 
          $this->load->model('common_model'); 	
				

        if($this->session->userdata('user_id') =="") {
         echo "<script>window.location.href='".base_url()."index.php/Login'</script>";
      }

    }

	public function index()
	{
		redirect('Login');
	}

	public function dashboard($msg=null)
	{

    if ($msg != "") {
        if ($msg == "1") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Product Category Successfully Added";
        }
        if ($msg == "fail") {
           $data['icon'] = "fa-warning";
           $data['type'] = "alert-warning";
           $data['msg'] = "New Product Add Failed ";
        }
       }

		$this->load->view('admin/dashboard');
	}










public function product_types($msg=null) {
      $session_data = $this->session->all_userdata();

       $data['product_types'] = $this->common_model->select('*','product_type');

        if ($msg != "" && $msg == "Success") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "New Product Type Successfully Added";
        }

        if ($msg != "" && $msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Product Type Successfully Updated";
        }

        if ($msg != "" && $msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Product Type Successfully Deleted";
        }


    $this->load->view('admin/product_types',$data);
  }
 public function add_product_types() {
      $session_data = $this->session->all_userdata();
      extract($_REQUEST);

      if ($category == "1") {
         $category_name = "Lab Equipments";
       } 
       if ($category == "2") {
         $category_name = "Software Solutions";
       } 

     $values=array(
                 'name'=> $name,
                 'category_id'=> $category,
                 'category'=> $category_name
               );
      $result = $this->common_model->insert('product_type',$values);

       $msg = "Success";
       redirect(base_url()."index.php/Admin/product_types/".$msg);
  }


   public function product_types_get() {
          $data=$this->common_model->select('*','product_type',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
      }
  

   public function product_types_update($id) {
      $session_data = $this->session->all_userdata();
      extract($_REQUEST); 
      $where = array('id' => $id);

      if ($category == "1") {
         $category_name = "Lab Equipments";
       } 
       if ($category == "2") {
         $category_name = "Software Solutions";
       } 

      $values=array(
                 'name'=> $name,
                 'category_id'=> $category,
                 'category'=> $category_name
               );
       $result = $this->common_model->update('product_type',$values,$where);

       $msg = "Update";
       redirect(base_url()."index.php/Admin/product_types/".$msg);
  }





	public function products($id,$msg=null)
    {

      $data['select_product_types'] = $this->common_model->select('*','product_type',array('id' => $id));
	    $data['products'] = $this->common_model->select('*','products',array('product_type_id' => $id));
       $data['product_type_name'] =   $data['select_product_types'][0]->name;
       $data['product_type_id'] =   $data['select_product_types'][0]->id;

       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Product Successfully Added";
        }
        if ($msg == "Update") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " Product Detailes Successfully Updated";
        }
        if ($msg == "fail") {
           $data['icon'] = "fa-warning";
           $data['type'] = "alert-warning";
           $data['msg'] = "New Product Add Failed ";
        }
      if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Product Detailes Successfully Deleted";
        }

       }

		$this->load->view('admin/products',$data);
	}


	 public function product_view() {
         	$data=$this->common_model->select('*','products',array('id'=>$_POST['id']));
         	$result=array();
         	$result['data']= $data;
         	echo json_encode($result);
        }

        
  public function product_update($id)
    {
          extract($_REQUEST);  

          if ($_FILES["image"]["name"] != "") {

                $target_dir = "././assets/admin/images/";
                $image_name= "product_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;
  
               if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                 $values=array('name'=>$product_name,'image'=>$image_name,'description'=> $product_text);
                 $result = $this->common_model->update('products',$values,array('id' => $id));
                } 
             }
             else{
                $values=array('name'=>$product_name,'description'=> $product_text);
                 $result = $this->common_model->update('products',$values,array('id' => $id));
             }

              $data['products'] = $this->common_model->select('*','products',array('id' => $id));
              $product_type_id =   $data['products'][0]->product_type_id;
                $msg = "Update";
               redirect(base_url()."index.php/Admin/products/".$product_type_id."/".$msg);



	}


   public function product_submit($id)
    {
          extract($_REQUEST);  

                $target_dir = "././assets/admin/images/";
                $image_name= "product_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;     
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
               $values=array('name'=>$product_name,'product_type_id'=>$id,'image'=>$image_name,'description'=> $product_text);
               $result = $this->common_model->insert('products',$values);
                 $msg = "Success";
                 redirect(base_url()."index.php/Admin/products/".$id."/".$msg);

                  }   
  }
 
  public function product_cat_submit(){
      
      extract($_REQUEST);  

      $values=array('name'=>$category_name);

       $result = $this->common_model->insert('product_type',$values);

       $msg_type = "1";
       redirect(base_url()."index.php/Admin/dashboard/".$msg_type);
  }

 public function industries($msg=null)
    {
       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Industries Detailes Successfully Added";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Industries Detailes Successfully Updated ";
        }
        if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Industries Detailes Successfully Deleted ";
        }
       }

       $data['industries'] = $this->common_model->select('*','industries');

       $data['products'] = $this->common_model->select('*','products');

    $this->load->view('admin/industries',$data);
  }


  public function add_industry(){

       $data['products'] = $this->common_model->select('*','products');

    $this->load->view('admin/add_industry',$data);
  }

   public function add_industry_submit()
    {
          extract($_REQUEST);  
                $target_dir = "././assets/admin/images/";
                $image_name= "industry_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;  

            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {

               $values=array( 
                            'name'=>$industry_name,
                            'image'=>$image_name,
                            'description'=> $industry_text,
                            'create_date'=>date('Y-m-d H:i:s')
                            );

               $result = $this->common_model->insert('industries',$values);

            foreach($products as $key => $product ){ 

         $data['products'] = $this->common_model->select('*','products',array('id'=>$products[$key]));
         $product_name = $data['products'][0]->name;

                  $value1=array(
                              'industry_id' => $result,
                              'product_id'=>$products[$key],
                              'product_name'=>$product_name,
                              'create_date'=>date('Y-m-d H:i:s')
                              );

                  $result1 = $this->common_model->insert('industry_products',$value1);
              }

       $count = $this->common_model->count_rows('*','industry_products',array('industry_id'=>$result));

        $where = array('id' => $result);
        $value2 = array('no_of_products' => $count);
        $result1 = $this->common_model->update('industries',$value2,$where);

                 $msg = "Success";
                 redirect(base_url()."index.php/Admin/industries/".$msg);

                  }   
  }


  public function edit_industry($id){

      $data['products'] = $this->common_model->select('*','products');

      $data['industries'] = $this->common_model->select('*','industries',array('id' =>$id ));

      $data['industry_products'] = $this->common_model->select('*','industry_products',array('industry_id' =>$id ));

    $this->load->view('admin/edit_industry',$data);
  }



   public function update_industry_submit($id)
    {
          extract($_REQUEST);  

          if ($_FILES["image"]["name"] != "") {
                $target_dir = "././assets/admin/images/";
                $image_name= "industry_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;  
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)){
               $image = $image_name;
              }
          }else{
              $image = $old_image;
          }

               $where = array('id' => $id);
               $values=array( 
                            'name'=>$industry_name,
                            'image'=>$image,
                            'description'=> $industry_text,
                            'create_date'=>date('Y-m-d H:i:s')
                            );

               $result = $this->common_model->update('industries',$values,$where);

          $this->common_model->delete_rows('industry_products',array('industry_id'=> $id));

            foreach($products as $key => $product ){ 

           $data['products'] = $this->common_model->select('*','products',array('id'=>$products[$key]));
           $product_name = $data['products'][0]->name;

                  $value1=array(
                              'industry_id' => $id,
                              'product_id'=>$products[$key],
                              'product_name'=>$product_name,
                              'create_date'=>date('Y-m-d H:i:s')
                              );

                  $result1 = $this->common_model->insert('industry_products',$value1);
              }

         $count = $this->common_model->count_rows('*','industry_products',array('industry_id'=>$id));

         $where1 = array('id' => $id);
         $value2 = array('no_of_products' => $count);
         $result2 = $this->common_model->update('industries',$value2,$where1);

                 $msg = "Update";
                 redirect(base_url()."index.php/Admin/industries/".$msg);

             
  }

  public function delete_industry($id)
    {
      $this->common_model->delete_rows('industries',array('id'=> $id));
      $this->common_model->delete_rows('industry_products',array('industry_id'=> $id));
        $msg = "Delete";
     redirect(base_url()."index.php/Admin/industries/".$msg);
    }



 public function case_studies($msg=null)
    {
       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Case Studies Detailes Successfully Added";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Case Studies Detailes Successfully Updated ";
        }
        if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Case Studies Detailes Successfully Deleted ";
        }
       }

       $data['case_studies'] = $this->common_model->select('*','case_studies');

    $this->load->view('admin/case_studies',$data);
  }



   public function add_case_studies()
    {
          extract($_REQUEST); 

                $target_dir = "././assets/admin/images/";
                $target_dir_file = "././assets/admin/files/";
                $file_name = "case_studies_".date("h-i-s").basename($_FILES["pdf"]["name"]);
                $image_name= "case_studies_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir_file .$file_name;
                $target_image = $target_dir .$image_name;   

           move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);

           move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
                
               $values=array( 
                            'name'=>$name,
                            'image'=>$image_name,
                            'pdf'=> $file_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->insert('case_studies',$values);

               $msg = "Success";
     redirect(base_url()."index.php/Admin/case_studies/".$msg);
    
}

public function case_studies_get()
    {
          $data=$this->common_model->select('*','case_studies',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }


  public function update_case_studies($id)
    {
          extract($_REQUEST); 

          if ($_FILES["pdf"]["name"] != "") {
                $target_dir_file = "././assets/admin/files/";
                $file_name = "case_studies_".date("h-i-s").basename($_FILES["pdf"]["name"]);
                $target_file = $target_dir_file .$file_name;
                move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);
            }else{
              $file_name = $old_pdf;
            }
            if ($_FILES["image"]["name"] != "") {
                $target_dir = "././assets/admin/images/";
                $image_name= "case_studies_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_image = $target_dir .$image_name;   
                move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
            }else{
              $image_name = $old_img;
            }
              $where = array('id' => $id );
               $values=array( 
                            'name'=>$name,
                            'image'=>$image_name,
                            'pdf'=> $file_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->update('case_studies',$values,$where);

               $msg = "Update";
     redirect(base_url()."index.php/Admin/case_studies/".$msg);
    
}

  public function delete_case_studies($id)
    {
      $this->common_model->delete_rows('case_studies',array('id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/case_studies/".$msg);
    }




 public function brochures($msg=null)
    {
       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Brochur Successfully Added";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Brochur Detailes Successfully Updated ";
        }
        if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Brochur Detailes Successfully Deleted ";
        }
       }

       $data['brochures'] = $this->common_model->select('*','brochures');

    $this->load->view('admin/brochures',$data);
  }



   public function add_brochures()
    {
          extract($_REQUEST); 

                $target_dir = "././assets/admin/images/";
                $target_dir_file = "././assets/admin/files/";
                $file_name = "brochures_".date("h-i-s").basename($_FILES["pdf"]["name"]);
                $image_name= "brochures_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir_file .$file_name;
                $target_image = $target_dir .$image_name;   

           move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);

           move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
                
               $values=array( 
                            'name'=>$name,
                            'image'=>$image_name,
                            'pdf'=> $file_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->insert('brochures',$values);

               $msg = "Success";
     redirect(base_url()."index.php/Admin/brochures/".$msg);
    
}

public function brochures_get()
    {
          $data=$this->common_model->select('*','brochures',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }


  public function update_brochures($id)
    {
          extract($_REQUEST); 

          if ($_FILES["pdf"]["name"] != "") {
                $target_dir_file = "././assets/admin/files/";
                $file_name = "brochures_".date("h-i-s").basename($_FILES["pdf"]["name"]);
                $target_file = $target_dir_file .$file_name;
                move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);
            }else{
              $file_name = $old_pdf;
            }
            if ($_FILES["image"]["name"] != "") {
                $target_dir = "././assets/admin/images/";
                $image_name= "brochures_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_image = $target_dir .$image_name;   
                move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
            }else{
              $image_name = $old_img;
            }
              $where = array('id' => $id );
               $values=array( 
                            'name'=>$name,
                            'image'=>$image_name,
                            'pdf'=> $file_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->update('brochures',$values,$where);

               $msg = "Update";
     redirect(base_url()."index.php/Admin/brochures/".$msg);
    
}

  public function delete_brochures($id)
    {
      $this->common_model->delete_rows('brochures',array('id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/brochures/".$msg);
    }



 public function draft_sight($msg=null)
    {
       if ($msg != "") {
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Draft Sight Detailes Successfully Updated ";
        }
       }

       $data['draft_sight'] = $this->common_model->select('*','draft_sight');

    $this->load->view('admin/draft_sight',$data);
  }


   public function update_draft_sight($id)
    {
          extract($_REQUEST); 


          if ($_FILES["pdf"]["name"] != "") {
                $target_dir_file = "././assets/admin/files/";
                $file_name = "draft_sight_".date("h-i-s").basename($_FILES["pdf"]["name"]);
                $target_file = $target_dir_file .$file_name;
                move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);
            }else{
              $file_name = $old_pdf;
            }
            if ($_FILES["image"]["name"] != "") {
                $target_dir = "././assets/admin/images/";
                $image_name= "draft_sight_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_image = $target_dir .$image_name;   
                move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
            }else{
              $image_name = $old_img;
            }
            $where = array('id' => $id );

               $values=array( 
                            'description'=>$description,
                            'image'=>$image_name,
                            'pdf'=> $file_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->update('draft_sight',$values,$where);

               $msg = "Update";
     redirect(base_url()."index.php/Admin/draft_sight/".$msg);
    
}



 public function services($msg=null)
    {
       if ($msg != "") {
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Services Detailes Successfully Updated ";
        }
       }

       $data['services'] = $this->common_model->select('*','services');

    $this->load->view('admin/services',$data);
  }



   public function update_services($id)
    {
          extract($_REQUEST); 


            if ($_FILES["image"]["name"] != "") {
                $target_dir = "././assets/admin/images/";
                $image_name= "services_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_image = $target_dir .$image_name;   
                move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
            }else{
              $image_name = $old_img;
            }
            $where = array('id' => $id );

               $values=array( 
                            'description'=>$description,
                            'header'=>$header,
                            'image'=>$image_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->update('services',$values,$where);

               $msg = "Update";
     redirect(base_url()."index.php/Admin/services/".$msg);
    
}


  public function customer_supports()
    {
        $this->db->select("*")-> from('customer_support')->order_by("customer_support.id desc");
      $query1 = $this->db->get();
      $data['customer_support'] =$query1->result();
    $this->load->view('admin/customer_supports',$data);
  }



 public function edrawing($msg=null)
    {
       if ($msg != "") {
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "eDrawing Detailes Successfully Updated ";
        }
       }

   $data['edrawing'] = $this->common_model->select('*','edrawing');
   $data['edrawing_points'] = $this->common_model->select('*','edrawing_points');

    $this->load->view('admin/edrawing',$data);
  }

 public function update_edrawing($id)
  {
    extract($_REQUEST);

   $where = array('id' => $id );
               $values=array( 
                            'main_text'=> $main_text,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->update('edrawing',$values,$where);

    $this->common_model->delete_rows('edrawing_points',array('edrawing_id'=> $id));

             foreach($benefits as $key => $benefit ){ 

                $value1=array(
                            'edrawing_id' => $id,
                            'points'=>$benefits[$key],
                            'create_date'=>date('Y-m-d H:i:s')
                            );
                $result1 = $this->common_model->insert('edrawing_points',$value1);
              }

               $msg = "Update";
     redirect(base_url()."index.php/Admin/edrawing/".$msg);
}



public function events($msg=null)
    {

        $this->db->select("*")-> from('events')->order_by("events.id desc");
      $query1 = $this->db->get();
      $data['events'] =$query1->result();


       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Event Successfully Created";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Event Successfully Updated ";
        }
         if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Event Successfully Deleted ";
        }
          if ($msg == "Completed") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Event Successfully Completed ";
        }
       }

    $this->load->view('admin/events',$data);
  }



   public function event_submit()
    {
          extract($_REQUEST);  
                $target_dir = "././assets/admin/images/";
                $image_name= "event_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;  

            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {

               $values=array( 
                            'event_name'=>$event_name,
                            'image'=>$image_name,
                            'event_detailes'=> $event_text,
                            'event_start_date'=>$event_start_date,
                            'event_start_time'=>$event_start_time,
                            'event_end_date'=>$event_end_date,
                            'event_end_time'=>$event_end_time,
                            'address'=>$event_address,
                            'event_location'=>$event_location,
                            'status' => '0',
                            'create_date'=>date('Y-m-d H:i:s')
                            );

               $result = $this->common_model->insert('events',$values);

            foreach($event_inclusions as $key => $inclusions ){ 

                  $value1=array(
                              'events_id' => $result,
                              'inclusions'=>$event_inclusions[$key],
                              'create_date'=>date('Y-m-d H:i:s')
                              );

                  $result1 = $this->common_model->insert('events_inclusions',$value1);
              }

            foreach($agenda_name as $key1 => $agenda ){  

                  $value2=array(
                               'events_id' => $result,
                               'agenda_name'=>$agenda_name[$key1],
                               'agenda_start_date'=>$agenda_start_date[$key1],
                               'agenda_start_time '=>$agenda_start_time [$key1],
                               'agenda_end_date '=>$agenda_end_date[$key1],
                               'agenda_end_time '=>$agenda_end_time[$key1],
                               'create_date'=>date('Y-m-d H:i:s'));

                  $result2 = $this->common_model->insert('events_agenda',$value2);
              }



                 $msg = "Success";
                 redirect(base_url()."index.php/Admin/events/".$msg);

                  }   
  }


public function events_get()
    {
          $data=$this->common_model->select('*','events',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }
  public function events_inclusions_get()
    {
          $data=$this->common_model->select('*','events_inclusions',array('events_id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }
  
    public function events_agenda_get()
    {
          $data=$this->common_model->select('*','events_agenda',array('events_id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }

   public function event_update($id){

      extract($_REQUEST);

       $where = array('events.id' => $id); 

      if ($_FILES["image"]["name"] == "") {

             $values=array( 
                            'event_name'=>$event_name,
                            'event_detailes'=> $event_text,
                            'event_start_date'=>$event_start_date,
                            'event_start_time'=>$event_start_time,
                            'event_end_date'=>$event_end_date,
                            'event_end_time'=>$event_end_time,
                            'address'=>$event_address,
                            'event_location'=>$event_location,
                            'status' => '0',
                            'create_date'=>date('Y-m-d H:i:s')
                            );

               $result = $this->common_model->update('events',$values,$where);

      }else{
                $target_dir = "././assets/admin/images/";
                $image_name= "event_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;  

            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {

               $values=array( 
                            'event_name'=>$event_name,
                            'image'=>$image_name,
                            'event_detailes'=> $event_text,
                            'event_start_date'=>$event_start_date,
                            'event_start_time'=>$event_start_time,
                            'event_end_date'=>$event_end_date,
                            'event_end_time'=>$event_end_time,
                            'address'=>$event_address,
                            'event_location'=>$event_location,
                            'status' => '0',
                            'create_date'=>date('Y-m-d H:i:s')
                            );

               $result = $this->common_model->update('events',$values,$where);
           }
         }
           $this->common_model->delete_rows('events_inclusions',array('events_id'=> $id));
           
            foreach($event_inclusions as $key => $inclusions ){ 

                  $value1=array(
                              'events_id'=> $id,
                              'inclusions'=>$event_inclusions[$key],
                              'create_date'=>date('Y-m-d H:i:s')
                              );

                  $result1 = $this->common_model->insert('events_inclusions',$value1);
              }

            $this->common_model->delete_rows('events_agenda',array('events_id'=> $id));

            foreach($agenda_name as $key1 => $agenda ){  

                  $value2=array(
                               'events_id'=> $id,
                               'agenda_name'=>$agenda_name[$key1],
                               'agenda_start_date'=>$agenda_start_date[$key1],
                               'agenda_start_time '=>$agenda_start_time [$key1],
                               'agenda_end_date '=>$agenda_end_date[$key1],
                               'agenda_end_time '=>$agenda_end_time[$key1],
                               'create_date'=>date('Y-m-d H:i:s'));

                  $result2 = $this->common_model->insert('events_agenda',$value2);
              }



                 $msg = "Update";
                 redirect(base_url()."index.php/Admin/events/".$msg);


   }

     public function event_registers()
    {

        $this->db->select("*")-> from('events_register')->order_by("events_register.id desc");
      $query1 = $this->db->get();
      $data['event_registers'] =$query1->result();
    $this->load->view('admin/event_register',$data);
  }






public function videos($msg=null)
    {

        $this->db->select("*")-> from('videos')->order_by("videos.id desc");
      $query1 = $this->db->get();
      $data['videos'] =$query1->result();


       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Video Link Successfully Added";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Video Successfully Updated ";
        }
         if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Video Successfully Deleted ";
        }
       }

    $this->load->view('admin/videos',$data);
  }

   public function videos_submit()
    {
          extract($_REQUEST);  

               $values=array(
                          'topic'=>$video_topic,
                          'link'=>$video_link,
                          'time'=>date('Y-m-d H:i:s'),
                          'description'=> $video_description
                     );
               $result = $this->common_model->insert('videos',$values);
                 $msg = "Success";
                 redirect(base_url()."index.php/Admin/videos/".$msg);

  }


  public function videos_get()
    {
          $data=$this->common_model->select('*','videos',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }


   public function video_update($id)
    {     
          $where = array('id' => $id);

          extract($_REQUEST);  

               $values=array('topic'=>$video_topic,'link'=>$video_link,'time'=>date('Y-m-d H:i:s'),'description'=> $video_description);
               $result = $this->common_model->update('videos',$values,$where);
                 $msg = "Update";
                 redirect(base_url()."index.php/Admin/videos/".$msg);

  }




public function sliders($msg=null)
    {
        $this->db->select("*")-> from('sliders')->order_by("sliders.id desc");
      $query1 = $this->db->get();
      $data['sliders'] =$query1->result();
       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Slider Successfully Added";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Slider Successfully Updated ";
        }
         if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Slider Successfully Deleted ";
        }
       }
    $this->load->view('admin/sliders',$data);
  }


   public function sliders_submit()
    {
      extract($_REQUEST);  
                $target_dir = "././assets/admin/images/";
                $image_name= "sliders_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;     
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {

               $values=array(
                          'title'=>$title,
                          'text'=> $slider_text,
                          'image'=>$image_name,
                          'create_date'=>date('Y-m-d H:i:s')
                     );
               $result = $this->common_model->insert('sliders',$values);
               $msg = "Success";
               redirect(base_url()."index.php/Admin/sliders/".$msg);
                }           
  }

    public function sliders_get()
    {
          $data=$this->common_model->select('*','sliders',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }

     public function sliders_update($id)
    {     
          $where = array('id' => $id);

          extract($_REQUEST);  
          if ($_FILES["image"]["name"] == "") {
              $values=array(
                          'title'=>$title,
                          'text'=> $slider_text
                     );
          }
          else{
            $target_dir = "././assets/admin/images/";
                $image_name= "sliders_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;
                move_uploaded_file($_FILES["image"]["tmp_name"], $target_file);
               $values=array(
                      'title'=>$title,
                      'text'=> $slider_text,
                      'image'=>$image_name
                 );
          }
          
               $result = $this->common_model->update('sliders',$values,$where);
                 $msg = "Update";
                 redirect(base_url()."index.php/Admin/sliders/".$msg);
  }



 public function career($msg=null)
    {

        $this->db->select("*")-> from('career')->order_by("career.id desc");
      $query1 = $this->db->get();
      $data['careers'] =$query1->result();


       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New Job Detailes Successfully Created";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Job Detailes Successfully Updated ";
        }
        if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Job Detailes Successfully Deleted ";
        }
       }

    $this->load->view('admin/career',$data);
  }

  



   public function job_submit()
    {
          extract($_REQUEST);  
               $values=array( 
                            'name'=>$job_name,
                            'description'=>$job_description,
                            'no_of_rec' => '0',
                            'create_date'=>date('Y-m-d H:i:s'));
               $result = $this->common_model->insert('career',$values);
            foreach($job_responsibilities as $key => $responsibilities ){ 
                  $value1=array(
                              'career_id' => $result,
                              'responsibilities'=>$job_responsibilities[$key],
                              'create_date'=>date('Y-m-d H:i:s'));
                  $result1 = $this->common_model->insert('career_responsibilities',$value1);
              }
            foreach($job_requirements as $key1 => $requirements ){  
                  $value2=array(
                               'career_id' => $result,
                               'requirement'=>$job_requirements[$key1],
                               'create_date'=>date('Y-m-d H:i:s'));
                  $result2 = $this->common_model->insert('career_requirement',$value2);
              }
            foreach($desired_profile as $key2 => $desired ){  
                  $value3=array(
                               'career_id' => $result,
                               'career_desired_profile'=>$desired_profile[$key2],
                               'create_date'=>date('Y-m-d H:i:s'));
                  $result3 = $this->common_model->insert('career_desired',$value3);
              }
                 $msg = "Success";
                 redirect(base_url()."index.php/Admin/career/".$msg); 
  }


  public function job_get()
    {
          $data=$this->common_model->select('*','career',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }

  public function job_responsibilities_get()
    {
          $data=$this->common_model->select('*','career_responsibilities',array('career_id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }

  public function job_requirement_get()
    {
          $data=$this->common_model->select('*','career_requirement',array('career_id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }


  public function job_desired_get()
    {
          $data=$this->common_model->select('*','career_desired',array('career_id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }


     public function job_update($id)
    {
          extract($_REQUEST);
               $where = array('career.id' => $id);   
               $values=array( 
                            'name'=>$job_name,
                            'description'=>$job_description,
                            'create_date'=>date('Y-m-d H:i:s'));
               $result = $this->common_model->update('career',$values,$where);
            foreach($job_responsibilities as $key => $responsibilities ){
                  $where1 = array('career_responsibilities.career_id' => $id); 
                  $value1=array(
                              'responsibilities'=>$job_responsibilities[$key],
                              'create_date'=>date('Y-m-d H:i:s'));
                  $result1 = $this->common_model->update('career_responsibilities',$value1,$where1);
              }
            foreach($job_requirements as $key1 => $requirements ){ 
                  $where2 = array('career_requirement.career_id' => $id);  
                  $value2=array(
                               'requirement'=>$job_requirements[$key1],
                               'create_date'=>date('Y-m-d H:i:s'));
                  $result2 = $this->common_model->update('career_requirement',$value2,$where2);
              }
            foreach($desired_profile as $key2 => $desired ){ 
                  $where3 = array('career_desired.career_id' => $id); 
                  $value3=array(
                               'career_desired_profile'=>$desired_profile[$key2],
                               'create_date'=>date('Y-m-d H:i:s'));
                  $result3 = $this->common_model->update('career_desired',$value3,$where3);
              }
                 $msg = "Update";
                 redirect(base_url()."index.php/Admin/career/".$msg); 
  }




  public function job_applications()
    {
        $this->db->select("*")-> from('jobs')->order_by("jobs.id desc");
      $query1 = $this->db->get();
      $data['jobs'] =$query1->result();
    $this->load->view('admin/job_applications',$data);
  }

  public function product_request()
    {


        $this->db->select("*")-> from('product_request')->order_by("product_request.id desc");
      $query1 = $this->db->get();
      $data['product_request'] =$query1->result();
    $this->load->view('admin/product_request',$data);
  }

  public function contact()
    {


        $this->db->select("*")-> from('contact')->order_by("contact.id desc");
      $query1 = $this->db->get();
      $data['contacts'] =$query1->result();
    $this->load->view('admin/contact',$data);
  }

  public function about_us($msg=null)
    {


      $data['about_us'] = $this->common_model->select('*','about_us');
      $data['about_client_say'] = $this->common_model->select('*','about_client_say');
        $this->db->select("*")-> from('about_clients_logo')->order_by("id desc");
      $query1 = $this->db->get();
      $data['about_clients_logo'] =$query1->result();;

       if ($msg != "") {
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "About Us Detailes Successfully Updated ";
        }
       }


    $this->load->view('admin/about_us',$data);
  }








  public function about_us_update($id){

      extract($_REQUEST);

       $where = array('about_us.id' => $id); 

               $values=array( 
                            'about'=>$about,
                            'why_choose_1'=>$why_choose_1,
                            'why_choose_2'=>$why_choose_2,
                            'why_choose_3'=>$why_choose_3,
                            'why_choose_4'=>$why_choose_4,
                            'mission'=>$mission,
                            'vission'=>$vission,
                            'policy'=>$policy,
                            'client_served' => $client_served,
                            'no_of_projects'=>$no_of_projects,
                            'awards' => $awards,
                            'cup_of_coffee'=>$cup_of_coffee,
                            'create_date'=>date('Y-m-d H:i:s')
                            );

               $result = $this->common_model->update('about_us',$values,$where);

            $this->db->empty_table('about_clients_logo');

            $target_dir = "././assets/images/clients/";

            foreach ($_FILES["logo_img"]["name"] as $key => $logo_img) {
                
               if ($_FILES["logo_img"]["name"][$key] != "") {
                  $image_name= "clients_".date("h-i-s").basename($_FILES["logo_img"]["name"][$key]); 
                  $target_file = $target_dir .$image_name;
               if (move_uploaded_file($_FILES["logo_img"]["tmp_name"][$key] , $target_file)) { 
                  $value1 =array('image'=> $image_name,'about_us_id' => $id,);
                  $result1 = $this->common_model->insert('about_clients_logo',$value1);
                 }   
               }
            }

            foreach ($logo_img_empty as $key1 => $img_empty) {
              if ($logo_img_empty[$key1] != "") {
                $value2 =array('image'=> $logo_img_empty[$key1],'about_us_id' => $id);
                $result2 = $this->common_model->insert('about_clients_logo',$value2);
              }
            }

            
           $this->db->empty_table('about_client_say');

            foreach($client_name as $key2 => $agenda ){  
                  
                      if($_FILES["client_image"]["name"][$key2] != ""){
                        $target_dir = "././assets/images/testimonials/";
                        $image_name= "testimonials_".date("h-i-s").basename($_FILES["client_image"]["name"][$key2]); 
                        $target_file = $target_dir .$image_name;
                        if (move_uploaded_file($_FILES["client_image"]["tmp_name"][$key2] , $target_file)) { 
                          $image = $image_name;
                        }
                      }else {  
                         $image = $client_image_empty[$key2];
                      }

                  $value3 = array(
                               'name'=>$client_name[$key2],
                               'company'=>$company_name[$key2],
                               'client_said '=>$client_say_text [$key2],
                               'image '=>$image,
                               'about_us_id' => $id,
                               'create_date'=>date('H:i:s'));

                  $result3 = $this->common_model->insert('about_client_say',$value3);
                }

                 $msg = "Update";
                 redirect(base_url()."index.php/Admin/about_us/".$msg);


   }






public function mail_details($msg=null) {
      $session_data = $this->session->all_userdata();

       $this->db->select("*")
        ->from('mail_details');
      $query = $this->db->get();
      $data['emails'] =$query->result();

        if ($msg != "" && $msg == "Success") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "New Email Successfully Added";
        }

        if ($msg != "" && $msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Email Detailes Successfully Updated";
        }

         if ($msg != "" && $msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Email Detailes Successfully Deleted";
        }


    $this->load->view('admin/mail_details',$data);
  }
 public function add_mail_detailes() {
      $session_data = $this->session->all_userdata();
      extract($_REQUEST); 

     $values=array(
                 'name'=> $name,
                 'company_name'=>$company_name,
                 'email'=>$email,
                 'phone'=>$phone,
                 'update_date'=>date('H:i:s')
               );
      $result = $this->common_model->insert('mail_details',$values);

       $msg = "Success";
       redirect(base_url()."index.php/Admin/mail_details/".$msg);
  }


   public function mail_detailes_get() {
          $data=$this->common_model->select('*','mail_details',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
      }
  

   public function mail_detailes_update($id) {
      $session_data = $this->session->all_userdata();
      extract($_REQUEST); 
      $where = array('id' => $id);
      $values=array(
                 'name'=> $name,
                 'company_name'=>$company_name,
                 'email'=>$email,
                 'phone'=>$phone,
                 'update_date'=>date('H:i:s')
               );
       $result = $this->common_model->update('mail_details',$values,$where);

       $msg = "Update";
       redirect(base_url()."index.php/Admin/mail_details/".$msg);
  }




public function email_templates($msg=null) {
      $session_data = $this->session->all_userdata();

       $this->db->select("*")
        ->from('email_templates');
      $query = $this->db->get();
      $data['email_templates'] =$query->result();

        if ($msg != "" && $msg == "Success") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "New Email Template Successfully Created";
        }

        if ($msg != "" && $msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Email Template Successfully Updated";
        }

         if ($msg != "" && $msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "Email Template Successfully Deleted";
        }


    $this->load->view('admin/email_templates',$data);
  }

   public function email_template_submit()
    {
          extract($_REQUEST);  
                $target_dir = "././assets/admin/images/";
                $image_name= "email_template_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;     
            if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
               $values=array('name'=>$name,'title'=>$title,'image'=>$image_name,'subject'=> $subject, 'message'=>$message);
               $result = $this->common_model->insert('email_templates',$values);
                 $msg = "Success";
                 redirect(base_url()."index.php/Admin/email_templates/".$msg);
                }   
      }

   public function email_template_view() {
          $data=$this->common_model->select('*','email_templates',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
      }

  public function preview_email_template($id) {
      $session_data = $this->session->all_userdata();
      $query =$this->common_model->select('*','email_templates',array('id'=>$id));
      $data['email_templates'] =$query;
	  $this->load->view('admin/email_templates_preview',$data);
  }

  public function preview_email_template_send($id) {
      $session_data = $this->session->all_userdata();
      $data['email_templates']=$this->common_model->select('*','email_templates',array('id'=>$id));
      $data['users']=$this->common_model->select('*','mail_details');
      

					
	  $this->load->view('admin/email_templates_preview_send',$data);
  }

  public function send_mails($id) {
      // $session_data = $this->session->all_userdata();
      // $query =$this->common_model->select('*','email_templates',array('id'=>$id));
      // $data['email_templates'] =$query;
	  // $this->load->view('admin/email_templates_preview',$data);
	  
	  
	  $context = stream_context_create(array(
		'http' => array(
		  'method'  => 'POST',
		  'header'  => "Content-type: text/html\r\n",
		  'content' => http_build_query(array('name' => 'Mani','email' => 'mani006006@gmail.com','subject' => 'Project Details','message' => '<h1>Welcome mail</h1>'))
		),
	  ));
	  $return = file_get_contents('http://inscube.in/mailgun_nihas.php', false, $context); 

  }


        public function email_template_update($id)
    {
          extract($_REQUEST);  

          if ($_FILES["image"]["name"] != "") {

                $target_dir = "././assets/admin/images/";
                $image_name= "email_template_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir .$image_name;
  
               if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
                 $values=array('name'=>$name,'title'=>$title,'image'=>$image_name,'subject'=> $subject, 'message'=>$message);
                 $result = $this->common_model->update('email_templates',$values,array('id' => $id));
                } 
             }
             else{
                 $values=array('name'=>$name,'title'=>$title,'subject'=> $subject, 'message'=>$message);
                 $result = $this->common_model->update('email_templates',$values,array('id' => $id));
             }

                $msg = "Update";
               redirect(base_url()."index.php/Admin/email_templates/".$msg);

  }

    public function delete_email_template($id)
    {
      $this->common_model->delete_rows('email_templates',array('id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/email_templates/".$msg);
    }




  public function logout()
  {
    $this->session->unset_userdata('user_id');
    redirect('Login');
  }



  public function delete_pro_category($id)
    {
      $this->common_model->delete_rows('product_type',array('id'=> $id));

      $this->common_model->delete_rows('products',array('product_type_id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/product_types/".$msg);
    }

  public function delete_product($id)
    {

    $data['products'] = $this->common_model->select('*','products',array('id'=> $id));
    $pid = $data['products'][0]->product_type_id;

      $this->common_model->delete_rows('products',array('id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/products/".$pid);
    }

  public function delete_event($id)
    {
      $this->common_model->delete_rows('events',array('id'=> $id));
      $this->common_model->delete_rows('events_agenda',array('events_id'=> $id));
      $this->common_model->delete_rows('events_inclusions',array('events_id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/events/".$msg);
    }

  public function complete_event($id)
    {

      $where = array('id' => $id);
      $values=array( 'status'=> "3" );
      $result = $this->common_model->update('events',$values,$where);

      $msg = "Completed";
      redirect(base_url()."index.php/Admin/events/".$msg);
    }


  public function delete_career($id)
    {
      $this->common_model->delete_rows('career',array('id'=> $id));
      $this->common_model->delete_rows('career_desired',array('career_id'=> $id));
      $this->common_model->delete_rows('career_requirement',array('career_id'=> $id));
      $this->common_model->delete_rows('career_responsibilities',array('career_id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/career/".$msg);
    }


  public function delete_videos($id)
    {
      $this->common_model->delete_rows('videos',array('id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/videos/".$msg);
    }


  public function delete_mail_details($id)
    {
      $this->common_model->delete_rows('mail_details',array('id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/mail_details/".$msg);
    }









 public function white_papers($msg=null)
    {
       if ($msg != "") {
        if ($msg == "Success") {
            $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = " New White Paper Successfully Added";
        }
        if ($msg == "Update") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "White Papers Detailes Successfully Updated ";
        }
        if ($msg == "Delete") {
           $data['icon'] = "fa-check";
           $data['type'] = "alert-success";
           $data['msg'] = "White Papers Detailes Successfully Deleted ";
        }
       }

       $data['white_papers'] = $this->common_model->select('*','white_papers');

    $this->load->view('admin/white_papers',$data);
  }



   public function add_white_papers()
    {
          extract($_REQUEST); 

                $target_dir = "././assets/admin/images/";
                $target_dir_file = "././assets/admin/files/";
                $file_name = "white_papers_".date("h-i-s").basename($_FILES["pdf"]["name"]);
                $image_name= "white_papers_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_file = $target_dir_file .$file_name;
                $target_image = $target_dir .$image_name;   

           move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);

           move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
                
               $values=array( 
                            'name'=>$name,
                            'image'=>$image_name,
                            'pdf'=> $file_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->insert('white_papers',$values);

               $msg = "Success";
     redirect(base_url()."index.php/Admin/white_papers/".$msg);
    
}

public function white_papers_get()
    {
          $data=$this->common_model->select('*','white_papers',array('id'=>$_POST['id']));
          $result=array();
          $result['data']= $data;
          echo json_encode($result);
  }


  public function update_white_papers($id)
    {
          extract($_REQUEST); 

          if ($_FILES["pdf"]["name"] != "") {
                $target_dir_file = "././assets/admin/files/";
                $file_name = "white_papers_".date("h-i-s").basename($_FILES["pdf"]["name"]);
                $target_file = $target_dir_file .$file_name;
                move_uploaded_file($_FILES["pdf"]["tmp_name"], $target_file);
            }else{
              $file_name = $old_pdf;
            }
            if ($_FILES["image"]["name"] != "") {
                $target_dir = "././assets/admin/images/";
                $image_name= "white_papers_".date("h-i-s").basename($_FILES["image"]["name"]);
                $target_image = $target_dir .$image_name;   
                move_uploaded_file($_FILES["image"]["tmp_name"], $target_image);
            }else{
              $image_name = $old_img;
            }
              $where = array('id' => $id );
               $values=array( 
                            'name'=>$name,
                            'image'=>$image_name,
                            'pdf'=> $file_name,
                            'create_date'=>date('Y-m-d H:i:s')
                            );
               $result = $this->common_model->update('white_papers',$values,$where);

               $msg = "Update";
     redirect(base_url()."index.php/Admin/white_papers/".$msg);
    
}

  public function delete_white_papers($id)
    {
      $this->common_model->delete_rows('white_papers',array('id'=> $id));

        $msg = "Delete";
     redirect(base_url()."index.php/Admin/white_papers/".$msg);
    }

   
   public function event_excel()
    {

      $this->db->select("*")-> from('events_register')->order_by("events_register.id asc");
      $query1 = $this->db->get();
      $data['event_registers'] =$query1->result();

      require(APPPATH .'third_party/PHPExcel-1.8/Classes/PHPExcel.php');
      require(APPPATH .'third_party/PHPExcel-1.8/Classes/PHPExcel/Writer/Excel2007.php');
      
      $objPHPExcel = new PHPExcel();

      $objPHPExcel->getProperties()->setCreator("");
      $objPHPExcel->getProperties()->setLastModifiedBy("");
      $objPHPExcel->getProperties()->setTitle("");
      $objPHPExcel->getProperties()->setDescription("");
      
      $objPHPExcel->setActiveSheetIndex(0);

      $objPHPExcel->getActiveSheet()->setCellValue('A1','S.No');
      $objPHPExcel->getActiveSheet()->setCellValue('B1','Registerd Date');
      $objPHPExcel->getActiveSheet()->setCellValue('C1','Event Name');
      $objPHPExcel->getActiveSheet()->setCellValue('D1','Name');
      $objPHPExcel->getActiveSheet()->setCellValue('E1','Profesion');
      $objPHPExcel->getActiveSheet()->setCellValue('F1','Company');
      $objPHPExcel->getActiveSheet()->setCellValue('G1','Email');
      $objPHPExcel->getActiveSheet()->setCellValue('H1','Mobile');
      $objPHPExcel->getActiveSheet()->setCellValue('I1','Participates');

      $objPHPExcel->getActiveSheet()->getStyle("A1:I1")->applyFromArray(array("font" => array("bold" => true)));
      
      $row =2;

      $i=1;
     
     foreach ($data['event_registers'] as $key => $value) {

      $objPHPExcel->getActiveSheet()->setCellValue('A'.$row,$i);
      $objPHPExcel->getActiveSheet()->setCellValue('B'.$row,$value->create_date);
      $objPHPExcel->getActiveSheet()->setCellValue('C'.$row,$value->event_name);
      $objPHPExcel->getActiveSheet()->setCellValue('D'.$row,$value->name);
      $objPHPExcel->getActiveSheet()->setCellValue('E'.$row,$value->profesion);
      $objPHPExcel->getActiveSheet()->setCellValue('F'.$row,$value->company);
      $objPHPExcel->getActiveSheet()->setCellValue('G'.$row,$value->email);
      $objPHPExcel->getActiveSheet()->setCellValue('H'.$row,$value->phone);
      $objPHPExcel->getActiveSheet()->setCellValue('I'.$row,$value->participates);
     
     $row++;
     $i++;

     }

    // $objPHPExcel->getDefaultStyle()
    // ->getAlignment()
    // ->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER_CONTINUOUS );




     $filename = "Event-Register-".date("Y-m-d").'.xlsx';

     $objPHPExcel->getActiveSheet()->setTitle("Event Registerd List");
     
     // header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
     // header('Content-Disposition: attachment;filename="'.$filename.'"');
     // header('Cache-Control; max-age=0'); 

     $writer = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
     $writer->save('php://output');

     exit;



    }













}
